#!/usr/bin/env python3
"""Read-only source-release checks. No installed server files are read."""
from __future__ import annotations

import argparse
import ast
import base64
import binascii
import io
import ipaddress
from pathlib import Path, PurePosixPath
import re
import sys
import tarfile


ALLOWED_DNS_IPS = {"1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4", "9.9.9.9"}
ALLOWED_DOMAIN_ROOTS = {
    "github.com", "githubusercontent.com", "letsencrypt.org", "eff.org",
    "accel-ppp.org", "ipify.org", "pypi.org", "pythonhosted.org",
    "ubuntu.com", "debian.org", "example.com", "example.org", "example.net",
    "readthedocs.io", "kernel.org", "wireguard.com", "nginx.org",
}
ROOT_FILES = {
    "README.md", "LICENSE", "LICENSE.md", "NOTICE", "NOTICE.md", ".gitignore",
    "install.sh", "installer.sh", "build-release.py", "requirements.txt", "pyproject.toml",
    "SHA256SUMS", "THIRD_PARTY.md",
}
EXTENSIONLESS_CONFIGS = {
    "payload/etc/logrotate.d/sstp-accel",
    "payload/etc/nginx/sites-available/sstp-manager",
    "payload/etc/letsencrypt/renewal-hooks/deploy/sstp-reload",
}
CODE_MEMBERS = {"logger.info", "logging.info", "u.online"}
SOURCE_SUFFIXES = {".py", ".sh", ".md", ".txt", ".yml", ".yaml", ".toml"}
CONFIG_SUFFIXES = {".conf", ".service", ".timer", ".in", ".example", ".sh"}
STATE_NAMES = {
    "chap-secrets", "authorized_keys", "known_hosts", "traffic.json",
    "traffic-view.json", "status-cache.json", "static-ips.json", "known-macs.json",
    "session-mac-state.json", "port-forwards.json", "network-settings.json",
    "access-networks.json", "routes.json", "provision.json", ".secret_key",
    ".admin_password", ".server_password", "credentials.txt",
}
IPV4 = re.compile(r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])")
DOMAIN = re.compile(
    r"(?<![\w.-])(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+"
    r"(?:com|net|org|io|ru|kz|se|xyz|online|site|cloud|info|biz|invalid)(?![\w.-])",
    re.IGNORECASE,
)
PRIVATE_KEY = re.compile(r"-----BEGIN " + r"(?:[A-Z0-9 ]+ )?PRIVATE KEY-----")
SSH_KEY = re.compile(r"\b(?:ssh-ed25519|ssh-rsa|ecdsa-sha2-nistp\d+)\s+[A-Za-z0-9+/]{50,}={0,3}")
WG_KEY = re.compile(r"(?im)^\s*(?:PrivateKey|PresharedKey)\s*=\s*[A-Za-z0-9+/]{43}=\s*$")
PERSONAL_PATH = re.compile(r"(?i)(?:[A-Z]:[/\\]Users[/\\][^\s/'\"<>]+|/home/[^\s/'\"<>]+/\.ssh/)")
EMAIL = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)


def allowed_path(relative: Path) -> bool:
    name = relative.as_posix()
    if name in ROOT_FILES or name in EXTENSIONLESS_CONFIGS:
        return True
    if name.startswith(".github/workflows/"):
        return relative.suffix in {".yml", ".yaml"}
    if relative.parts[0] in {"tools", "scripts", "tests", "docs"}:
        return relative.suffix in SOURCE_SUFFIXES
    if name.startswith("payload/opt/sstp-manager/"):
        return relative.suffix in {".py", ".txt"}
    if name.startswith("payload/usr/local/sbin/sstp-"):
        return relative.suffix in {"", ".py", ".sh"}
    if name.startswith("payload/etc/") or name.startswith("templates/"):
        return relative.suffix in CONFIG_SUFFIXES
    return False


def source_findings(value: str, forbidden_tokens: tuple[str, ...] = ()) -> list[str]:
    findings = []
    for label, pattern in (
        ("embedded private key", PRIVATE_KEY),
        ("embedded SSH public key", SSH_KEY),
        ("embedded tunnel secret", WG_KEY),
        ("personal workstation/home path", PERSONAL_PATH),
    ):
        if pattern.search(value):
            findings.append(label)
    for candidate in set(IPV4.findall(value)):
        try:
            address = ipaddress.ip_address(candidate)
        except ValueError:
            continue
        if address.is_global and candidate not in ALLOWED_DNS_IPS:
            findings.append("hard-coded public IPv4 address")
    for host in set(DOMAIN.findall(value)):
        host = host.lower()
        if host in CODE_MEMBERS:
            continue
        if host.endswith(".invalid"):
            continue
        if not any(host == root or host.endswith("." + root) for root in ALLOWED_DOMAIN_ROOTS):
            findings.append("unapproved hard-coded domain")
    for address in EMAIL.findall(value):
        host = address.rsplit("@", 1)[1].lower()
        if not (host.endswith(".invalid") or host in {"example.com", "example.org", "example.net"}):
            findings.append("embedded non-example email address")
    for heading in re.findall(r'<h[12]\b[^>]*class=[\"\']brand[\"\'][^>]*>(.*?)</h[12]>', value, re.I | re.S):
        if re.sub(r"\s+", " ", heading).strip().upper() != "SSTP MANAGER":
            findings.append("non-generic panel branding")
    folded = value.casefold()
    if any(token and token.casefold() in folded for token in forbidden_tokens):
        findings.append("forbidden private token")
    return sorted(set(findings))


def check_tree(root: Path, forbidden_tokens: tuple[str, ...] = (), source_only: bool = False) -> list[str]:
    findings = []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if ".git" in relative.parts:
            continue
        if path.is_symlink():
            findings.append(f"{relative}: symlinks are not release source files")
            continue
        if not path.is_file():
            continue
        if path.name in STATE_NAMES or path.suffix.lower() in {".key", ".pem", ".pub", ".p12", ".pfx", ".db", ".sqlite", ".log", ".gz", ".zip", ".pyc"}:
            findings.append(f"{relative}: state, secret, binary, or archive file")
            continue
        if not allowed_path(relative):
            findings.append(f"{relative}: path is not in the source-release allowlist")
            continue
        try:
            value = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError):
            findings.append(f"{relative}: unreadable or non-UTF-8 source")
            continue
        if "\x00" in value:
            findings.append(f"{relative}: binary bytes in source")
            continue
        for reason in source_findings(value, forbidden_tokens):
            findings.append(f"{relative}: {reason}")
        if relative.as_posix() == "install.sh" and not source_only:
            findings.extend(check_bundle(root, value, forbidden_tokens))
        first_line = value.splitlines()[0] if value else ""
        if path.suffix == ".py" or (first_line.startswith("#!") and "python" in first_line):
            try:
                ast.parse(value, filename=str(relative))
            except SyntaxError as exc:
                findings.append(f"{relative}:{exc.lineno}: Python syntax error: {exc.msg}")
    return findings


def check_bundle(root: Path, value: str, forbidden_tokens: tuple[str, ...]) -> list[str]:
    """Inspect embedded source in memory, without extracting or executing it."""
    marker = "__SSTP_PAYLOAD" + "_BASE64__"
    parts = value.split("\n" + marker + "\n")
    if len(parts) != 2:
        return ["install.sh: expected exactly one embedded-source marker"]
    encoded = "".join(parts[1].split())
    if len(encoded) > 24 * 1024 * 1024:
        return ["install.sh: embedded source exceeds release size limit"]
    try:
        archive = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error):
        return ["install.sh: invalid base64 payload"]
    expected = {
        "LICENSE", "installer.sh", "requirements.txt", "scripts/render.py", "scripts/ask_admin_password.py",
        *(path.relative_to(root).as_posix() for path in (root / "payload").rglob("*") if path.is_file()),
    }
    seen = set()
    findings = []
    try:
        with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as bundle:
            total_size = 0
            for count, member in enumerate(bundle, 1):
                relative = PurePosixPath(member.name)
                if count > 1000:
                    return ["install.sh: too many archive entries"]
                if relative.is_absolute() or ".." in relative.parts or "\\" in member.name:
                    findings.append("install.sh: unsafe archive member path")
                    continue
                if member.isdir():
                    continue
                if not member.isfile():
                    findings.append("install.sh: archive contains link or special file")
                    continue
                name = relative.as_posix()
                if name not in expected or name in seen:
                    findings.append(f"install.sh: unexpected or duplicate member {name}")
                    continue
                seen.add(name)
                total_size += member.size
                if member.size < 0 or total_size > 20 * 1024 * 1024:
                    return ["install.sh: unpacked source exceeds release size limit"]
                stream = bundle.extractfile(member)
                if stream is None:
                    findings.append(f"install.sh: unreadable member {name}")
                    continue
                content = stream.read()
                try:
                    text = content.decode("utf-8-sig")
                except UnicodeError:
                    findings.append(f"install.sh: binary member {name}")
                    continue
                for reason in source_findings(text, forbidden_tokens):
                    findings.append(f"install.sh/{name}: {reason}")
                original = root / Path(name)
                if not original.is_file() or content.replace(b"\r\n", b"\n") != original.read_bytes().replace(b"\r\n", b"\n"):
                    findings.append(f"install.sh/{name}: embedded source differs from current source tree")
    except (tarfile.TarError, OSError, EOFError):
        findings.append("install.sh: invalid compressed source archive")
    for name in sorted(expected - seen):
        findings.append(f"install.sh: missing source member {name}")
    return findings


def self_test() -> None:
    assert source_findings("https://api.ipify.org 127.0.0.1 10.77.0.1 203.0.113.10") == []
    assert source_findings("https://vpn.customer.invalid") == []
    assert "hard-coded public IPv4 address" in source_findings(str(ipaddress.ip_address(0x08080405)))
    assert "unapproved hard-coded domain" in source_findings("vpn.customer-company" + ".net")
    assert "embedded private key" in source_findings("-----BEGIN " + "OPENSSH PRIVATE KEY-----")
    assert "embedded tunnel secret" in source_findings("PrivateKey = " + "A" * 43 + "=\n")
    assert "embedded SSH public key" in source_findings("ssh-ed25519 " + "A" * 80)
    brand_class = "brand"
    assert "non-generic panel branding" in source_findings(f'<h1 class="{brand_class}">Example Company</h1>')
    assert source_findings('<h1 class="brand">SSTP MANAGER</h1>') == []
    assert "forbidden private token" in source_findings("private-label", ("private-label",))
    assert allowed_path(Path("payload/usr/local/sbin/sstp-cascade-exit"))
    assert not allowed_path(Path("server-backup.tar.gz"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--forbid-token", action="append", default=[], help="Additional private label to reject; values are never printed")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--source-only", action="store_true", help="Permit a stale generated bundle before rebuilding; source privacy checks still run")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    root = args.root.resolve()
    if not root.is_dir():
        parser.error("root must be an existing source directory")
    findings = check_tree(root, tuple(args.forbid_token), args.source_only)
    if findings:
        print("Source release check FAILED:")
        for finding in findings:
            print("- " + finding)
        return 1
    print("Source release check passed: paths, obvious secrets, deployment hosts, and Python syntax.")
    print("This is a static check; it does not prove a clean-server install or VPN connectivity.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
