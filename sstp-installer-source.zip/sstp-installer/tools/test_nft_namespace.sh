#!/usr/bin/env bash
# Real Linux nft syntax checks in a disconnected network namespace.
# Requires root/CAP_SYS_ADMIN+CAP_NET_ADMIN, iproute2, nftables, util-linux and Python.
# No package installation, host firewall modification, services, or external traffic.
set -Eeuo pipefail
umask 077

[[ $EUID == 0 ]] || { echo 'Run this namespace test as root.' >&2; exit 1; }
for executable in unshare ip nft python3 flock mktemp readlink; do
    command -v "$executable" >/dev/null || { echo "Missing test dependency: $executable" >&2; exit 1; }
done
REPO=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
[[ -f "$REPO/scripts/render.py" && -f "$REPO/payload/usr/local/sbin/sstp-nft-apply" ]] || {
    echo 'Run the test from a complete SSTP Manager source package.' >&2; exit 1;
}
PARENT_NETNS=$(readlink /proc/self/ns/net)

# The child namespace is created before any ip/nft operation. It has no uplink,
# veth connection, or physical device; the dummy WAN below cannot carry traffic.
unshare --net --fork bash -s -- "$REPO" "$PARENT_NETNS" <<'NAMESPACE_TEST'
set -Eeuo pipefail
umask 077
REPO=$1
PARENT_NETNS=$2
[[ $(readlink /proc/self/ns/net) != "$PARENT_NETNS" ]] || {
    echo 'Refusing test: network namespace isolation was not established.' >&2; exit 1;
}
WORK=$(mktemp -d /tmp/sstp-nft-test.XXXXXXXX)
cleanup() {
    if [[ "$WORK" == /tmp/sstp-nft-test.* && -d "$WORK" ]]; then
        rm -rf -- "$WORK"
    fi
}
trap cleanup EXIT
trap 'exit 130' INT TERM
mkdir -m 0700 "$WORK/tmp" "$WORK/admin"
export TMPDIR="$WORK/tmp"

# A new network namespace must have no pre-existing firewall policy.
nft -j list ruleset >"$WORK/initial-rules.json"
python3 - "$WORK/initial-rules.json" <<'PY'
import json, sys
from pathlib import Path
entries = json.loads(Path(sys.argv[1]).read_text()).get('nftables', [])
assert all(set(entry) <= {'metainfo'} for entry in entries), 'Namespace firewall is not empty'
PY
ip link set lo up
ip link add wan0 type dummy
ip address add 203.0.113.10/24 dev wan0
ip link set wan0 up
ip route add default via 203.0.113.1 dev wan0

# Rendering uses a public example address solely to satisfy its input validator.
# It performs no DNS lookup or network operation.
python3 "$REPO/scripts/render.py" "$REPO/payload" "$WORK/rendered" \
    --domain vpn.example.org --sstp-port 443 --admin-port 7444 --public-ip 8.8.8.8
python3 - "$WORK/admin" <<'PY'
import json, sys
from pathlib import Path
directory = Path(sys.argv[1])
fixtures = {
    'static-ips.json': {'alice': '10.77.0.10'},
    'port-forwards.json': [
        {'id':'0123456789abcdef','user':'alice','protocol':'tcp','public_port':18443,'target_port':443},
        {'id':'fedcba9876543210','user':'alice','protocol':'udp','public_port':18553,'target_port':53},
    ],
    'access-networks.json': [{'cidr':'10.88.0.0/24'}],
    'routes.json': [{'cidr':'10.99.0.0/24','user':'alice'}],
    'network-settings.json': {'pool_start':'10.77.0.10','pool_end':'10.77.0.249','nat_enabled':True},
    'reserved-ports.json': [22,80,443,2001,5001,7444],
}
for name, value in fixtures.items():
    (directory/name).write_text(json.dumps(value)+'\n')
PY
export SSTP_ADMIN_DIR="$WORK/admin"
export SSTP_MODE_FILE="$WORK/mode"
export SSTP_NFT_LOCK_FILE="$WORK/nft-test.lock"
export SSTP_RESERVED_PORTS_FILE="$WORK/admin/reserved-ports.json"
export SSTP_NFT_CHECK_ONLY=1 SSTP_ROUTE_SKIP=1
HELPER="$WORK/rendered/usr/local/sbin/sstp-nft-apply"

for scenario in direct direct-no-nat cascade; do
    if [[ "$scenario" == cascade ]]; then printf 'cascade\n' >"$WORK/mode"; else printf 'direct\n' >"$WORK/mode"; fi
    python3 - "$WORK/admin/network-settings.json" "$scenario" <<'PY'
import json, sys
from pathlib import Path
path = Path(sys.argv[1])
settings = json.loads(path.read_text())
settings['nat_enabled'] = sys.argv[2] != 'direct-no-nat'
path.write_text(json.dumps(settings)+'\n')
PY
    # The helper runs nft -c. CHECK_ONLY exits before persistence or route changes.
    bash "$HELPER" >"$WORK/$scenario.nft"
    python3 - "$WORK/$scenario.nft" "$scenario" <<'PY'
import sys
from pathlib import Path
text = Path(sys.argv[1]).read_text()
scenario = sys.argv[2]
required = [
    'flush table ip sstp_manager',
    'meta mark set ct mark',
    'ct state new ct mark set 0x3200',
    'tcp option maxseg size set 1280',
    'ct state established,related accept',
    'iifname "wan0" tcp dport 18443 counter dnat to 10.77.0.10:443',
    'iifname "wan0" udp dport 18553 counter dnat to 10.77.0.10:53',
    'iifname "sstp*" ip daddr 203.0.113.10 tcp dport 18443',
    'ip daddr 10.88.0.0/24 accept',
    'ip daddr 10.99.0.0/24 accept',
    'comment "admin-to-clients"',
    'comment "admin-to-clients-snat"',
    'iifname "sstp*" ip saddr 10.77.0.0/24 counter drop',
    'iifname "ppp*" ip saddr 10.77.0.0/24 counter drop',
]
for fragment in required:
    assert fragment in text, f'{scenario}: missing {fragment}'
egress = 'sstp_exit' if scenario == 'cascade' else 'wan0'
nat_rule = f'oifname "{egress}" ip saddr 10.77.0.0/24 counter masquerade'
allow_rule = f'iifname "sstp*" oifname "{egress}" ip saddr 10.77.0.0/24 counter accept'
assert (nat_rule in text) == (scenario != 'direct-no-nat'), f'{scenario}: incorrect outbound NAT'
assert (allow_rule in text) == (scenario != 'direct-no-nat'), f'{scenario}: incorrect outbound permission'
if scenario == 'cascade':
    assert 'oifname "wan0" ip saddr 10.77.0.0/24 counter masquerade' not in text
else:
    assert 'oifname "sstp_exit"' not in text
assert '__ADMIN_PORT__' not in text and '__SSTP_PORT__' not in text, 'Unrendered template'
print(f'PASS {scenario}: real nft syntax, NAT, port forwards, private routes, client isolation')
PY
done

# CHECK_ONLY may create the empty dedicated table to validate a flush command,
# but it must never install any generated chain or rule, even in this namespace.
nft -j list ruleset >"$WORK/final-rules.json"
python3 - "$WORK/final-rules.json" <<'PY'
import json, sys
from pathlib import Path
entries = json.loads(Path(sys.argv[1]).read_text()).get('nftables', [])
assert all(set(entry) <= {'metainfo','table'} for entry in entries), 'CHECK_ONLY installed a chain/rule'
tables = [entry['table'] for entry in entries if 'table' in entry]
assert len(tables) == 1 and tables[0]['family'] == 'ip' and tables[0]['name'] == 'sstp_manager'
print('PASS check-only: generated rules were not installed; namespace discarded on exit')
PY
NAMESPACE_TEST
