#!/usr/bin/env python3
"""Build a deterministic one-file installer and a publication-only source archive."""
import base64
import gzip
import hashlib
import io
from pathlib import Path
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
MARKER = '__SSTP_PAYLOAD_BASE64__'


def runtime_files():
    files = [ROOT / 'installer.sh', ROOT / 'requirements.txt', ROOT / 'scripts/render.py', ROOT / 'scripts/ask_admin_password.py']
    files += sorted(p for p in (ROOT / 'payload').rglob('*') if p.is_file())
    if any(not p.is_file() or p.is_symlink() for p in files):
        raise RuntimeError('Missing or linked runtime source')
    return files


def tar_bytes(files):
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for path in sorted(files):
            data = path.read_bytes()
            if b'\r' in data:
                raise ValueError('Source files must use LF line endings: ' + str(path.relative_to(ROOT)))
            info = tarfile.TarInfo(path.relative_to(ROOT).as_posix())
            info.mode = 0o755 if data.startswith(b'#!') else 0o644
            info.size = len(data)
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    return gzip.compress(raw.getvalue(), mtime=0)


WRAPPER = '''#!/usr/bin/env bash
# SSTP Manager self-contained installer. Source is included below as a verified archive.
set -Eeuo pipefail
umask 077
usage() { printf '%s\\n' 'SSTP Manager installer' 'sudo bash install.sh          Install on a CLEAN Ubuntu/Debian server' 'bash install.sh --check       Verify the embedded archive; make no system changes' 'bash install.sh --extract DIR Extract readable source to a NEW directory' 'bash install.sh --help        Show this message'; }
case "${1:-}" in
  --help|-h) usage; exit 0 ;;
  --check) [[ $# == 1 ]] || { usage; exit 2; } ;;
  --extract) [[ $# == 2 && -n "$2" && ! -e "$2" && ! -L "$2" ]] || { printf 'Choose a new extraction directory.\\n' >&2; exit 2; } ;;
  '') [[ $# == 0 ]] || { usage; exit 2; } ;;
  *) usage; exit 2 ;;
esac
for cmd in bash awk tail base64 sha256sum tar mktemp; do command -v "$cmd" >/dev/null || { printf 'Required command missing: %s\\n' "$cmd" >&2; exit 1; }; done
SELF=$(readlink -f -- "${BASH_SOURCE[0]}")
WORK=$(mktemp -d /tmp/sstp-release.XXXXXXXX)
cleanup() { [[ "$WORK" == /tmp/sstp-release.* && -d "$WORK" ]] && rm -rf -- "$WORK"; }
trap cleanup EXIT
LINE=$(awk '$0 == "__SSTP_PAYLOAD_BASE64__" {print NR + 1; exit}' "$SELF")
[[ -n "$LINE" ]] || { printf 'Embedded source is missing.\\n' >&2; exit 1; }
tail -n +"$LINE" "$SELF" | base64 -d >"$WORK/runtime.tar.gz"
printf '%s  %s\\n' '__CHECKSUM__' "$WORK/runtime.tar.gz" | sha256sum -c - >/dev/null
if [[ ${1:-} == --check ]]; then
  tar -tzf "$WORK/runtime.tar.gz" >/dev/null
  printf 'Embedded source: SHA-256 verified. Installation was not started.\\n'
  exit 0
fi
if [[ ${1:-} == --extract ]]; then
  mkdir -- "$2"
  tar --no-same-owner -xzf "$WORK/runtime.tar.gz" -C "$2"
  printf 'Readable installation source extracted to %s\\n' "$2"
  exit 0
fi
mkdir "$WORK/source"
tar --no-same-owner -xzf "$WORK/runtime.tar.gz" -C "$WORK/source"
bash "$WORK/source/installer.sh"
exit $?
__SSTP_PAYLOAD_BASE64__
'''


def main():
    # First scan source without a stale generated wrapper. The second scan compares
    # every embedded runtime byte with this tree before producing a public archive.
    subprocess.run([sys.executable, str(ROOT / 'tools/check_release.py'), '--source-only'], check=True, cwd=ROOT)
    blob = tar_bytes(runtime_files())
    digest = hashlib.sha256(blob).hexdigest()
    encoded = base64.b64encode(blob).decode('ascii')
    text = WRAPPER.replace('__CHECKSUM__', digest) + '\n'.join(encoded[i:i+76] for i in range(0, len(encoded), 76)) + '\n'
    (ROOT / 'install.sh').write_text(text, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, str(ROOT / 'tools/check_release.py')], check=True, cwd=ROOT)
    allowed = []
    for path in ROOT.rglob('*'):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(ROOT)
        if any(part in {'.git', '__pycache__', '.pytest_cache'} for part in rel.parts):
            continue
        if path.suffix in {'.pyc', '.pyo'}:
            continue
        allowed.append(path)
    zip_path = ROOT.parent / 'sstp-installer-source.zip'
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(allowed):
            rel = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo('sstp-installer/' + rel, (2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if path.read_bytes().startswith(b'#!') else 0o644
            info.external_attr = (0o100000 | mode) << 16
            archive.writestr(info, path.read_bytes())
    sums = []
    for path in [ROOT / 'install.sh', zip_path]:
        sums.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name)
    (ROOT.parent / 'sstp-installer-SHA256SUMS.txt').write_text('\n'.join(sums) + '\n', encoding='ascii')
    print(f'Built install.sh ({len(text):,} bytes), {zip_path.name}; runtime SHA-256 {digest}')


if __name__ == '__main__':
    main()
