#!/usr/bin/env python3
"""Print a single pasteable command for an already published install.sh."""
import argparse
import re
import shlex
from urllib.parse import unquote, urlsplit


def validate_url(value):
    """Accept only explicit public GitHub raw/release installer URLs."""
    if any(character.isspace() or ord(character) < 32 for character in value):
        raise ValueError("URL must not contain whitespace or control characters")
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as error:
        raise ValueError("malformed URL") from error
    if parsed.scheme != "https" or parsed.username is not None or parsed.password is not None:
        raise ValueError("use an HTTPS URL without credentials")
    if port is not None or parsed.query or parsed.fragment:
        raise ValueError("URL must not contain an explicit port, query or fragment")
    if "\\" in value or any(ord(character) < 32 for character in unquote(parsed.path)):
        raise ValueError("invalid URL path")
    parts = parsed.path.strip("/").split("/")
    if parts[-1:] != ["install.sh"] or any(part in {"", ".", ".."} for part in parts):
        raise ValueError("URL must point directly to install.sh")
    if not all(re.fullmatch(r"[A-Za-z0-9_.-]+", part) for part in parts[:2]):
        raise ValueError("invalid GitHub owner or repository")
    if parsed.hostname == "raw.githubusercontent.com":
        if len(parts) < 4:
            raise ValueError("raw URL requires owner/repository/ref/install.sh")
    elif parsed.hostname == "github.com":
        if len(parts) != 6 or parts[2:4] != ["releases", "download"]:
            raise ValueError("GitHub URL must be a release asset: owner/repository/releases/download/tag/install.sh")
    else:
        raise ValueError("use raw.githubusercontent.com or a github.com release-asset URL")
    return value


def validate_sha256(value):
    if value and not re.fullmatch(r"[0-9a-fA-F]{64}", value):
        raise ValueError("SHA256 must contain exactly 64 hexadecimal characters")
    return value.lower()


def wrapper_script():
    """Static shell program; untrusted URL/checksum are positional arguments."""
    return " ".join([
        "set -Eeuo pipefail; umask 077;",
        "[[ $EUID -eq 0 ]] || { printf '%s\\n' 'Run this command as root.' >&2; exit 1; };",
        "{ [[ -r /dev/tty ]] && (: </dev/tty); } 2>/dev/null || { printf '%s\\n' 'Open an interactive SSH terminal first.' >&2; exit 1; };",
        "url=$1; expected=${2:-}; download_dir=;",
        "cleanup() { result=$?; trap - EXIT; if [[ -n $download_dir && $download_dir == /tmp/sstp-download.* && -d $download_dir ]]; then rm -rf -- \"$download_dir\"; fi; exit \"$result\"; };",
        "trap cleanup EXIT; trap 'exit 130' INT; trap 'exit 143' TERM;",
        "if ! command -v curl >/dev/null 2>&1 && ! command -v wget >/dev/null 2>&1; then",
        "command -v apt-get >/dev/null 2>&1 || { printf '%s\\n' 'Install curl or wget first.' >&2; exit 1; };",
        "export DEBIAN_FRONTEND=noninteractive; apt-get update; apt-get install -y --no-install-recommends ca-certificates curl; fi;",
        "download_dir=$(mktemp -d /tmp/sstp-download.XXXXXXXX); payload=$download_dir/install.sh;",
        "printf '%s\\n' 'Downloading the complete installer...';",
        "if command -v curl >/dev/null 2>&1; then",
        "curl --fail --show-error --silent --location --proto '=https' --proto-redir '=https' --connect-timeout 15 --max-time 120 --output \"$payload\" --url \"$url\";",
        "else timeout 120 wget --https-only --timeout=15 --tries=1 --max-redirect=10 --output-document=\"$payload\" -- \"$url\"; fi;",
        "[[ -s $payload ]] || { printf '%s\\n' 'Downloaded installer is empty.' >&2; exit 1; };",
        "if [[ -n $expected ]]; then command -v sha256sum >/dev/null 2>&1 || { printf '%s\\n' 'sha256sum is required to verify this installer.' >&2; exit 1; };",
        "printf '%s  %s\\n' \"$expected\" \"$payload\" | sha256sum --check --status || { printf '%s\\n' 'Installer SHA256 mismatch; nothing was executed.' >&2; exit 1; }; fi;",
        "bash \"$payload\";",
    ])


def compact_script(with_sha256=False):
    """Short Termius launcher; still downloads a complete file before running it."""
    script = [
        'set -e; [[ $EUID -eq 0 ]] || { echo "Run as root" >&2; exit 1; }; : </dev/tty;',
        "command -v curl >/dev/null || { apt-get update; DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl; };",
        "d=$(mktemp -d /tmp/sstp-download.XXXXXXXX); cleanup() { rm -rf -- \"$d\"; }; trap cleanup EXIT;",
        'curl -fLsS --proto "=https" --proto-redir "=https" --connect-timeout 15 --max-time 120 -o "$d/install.sh" "$1";',
        "test -s \"$d/install.sh\";",
    ]
    if with_sha256:
        script.append('printf "%s  %s\\n" "$2" "$d/install.sh" | sha256sum --check --status;')
    script.append("bash \"$d/install.sh\";")
    return " ".join(script)


def make_command(url, sha256="", compact=False):
    url, sha256 = validate_url(url), validate_sha256(sha256)
    script = compact_script(bool(sha256)) if compact else wrapper_script()
    arguments = ["bash", "-c", script, "sstp-download", url]
    if sha256 or not compact:
        arguments.append(sha256)
    return shlex.join(arguments)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True, help="Actual published HTTPS raw GitHub URL or release asset ending in install.sh")
    parser.add_argument("--sha256", default="", help="Optional trusted SHA256 of that exact published install.sh")
    parser.add_argument("--compact", action="store_true", help="Short pasteable launcher using curl (automatically installed if missing)")
    arguments = parser.parse_args(argv)
    try:
        print(make_command(arguments.url, arguments.sha256, compact=arguments.compact))
    except ValueError as error:
        parser.error(str(error))


if __name__ == "__main__":
    main()
