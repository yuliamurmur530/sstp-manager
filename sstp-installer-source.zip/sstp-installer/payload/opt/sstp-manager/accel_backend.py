"""Small compatibility layer between the existing panel and Accel-PPP.

The panel historically consumed a subset of SoftEther's vpncmd output.  Keeping
that stable here limits the production migration to the VPN engine and avoids a
large, risky rewrite of the UI and traffic collector.
"""

import fcntl
import ipaddress
import json
import os
import re
import secrets
import subprocess
import tempfile
import time


ADMIN_DIR = "/opt/sstp-manager"
STATIC_IP_FILE = f"{ADMIN_DIR}/static-ips.json"
CHAP_SECRETS_FILE = "/etc/sstp-accel/chap-secrets"
CHAP_LOCK_FILE = "/run/lock/sstp-accel-chap.lock"
ACCEL_CMD = "/opt/sstp-accel/bin/accel-cmd"
ACCEL_HOST = "127.0.0.1"
ACCEL_PORT = "2001"
REALM = "VPN"
SUCCESS = "The command completed successfully."
SESSION_CACHE_SECONDS = 0.4

_session_cache = {"at": 0.0, "rows": []}


class BackendError(RuntimeError):
    pass


def _display_username(value):
    value = str(value or "").strip()
    suffix = f"@{REALM}"
    if value.casefold().endswith(suffix.casefold()):
        return value[: -len(suffix)]
    return value


def _login_username(value):
    value = _display_username(value)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', value):
        raise BackendError('invalid username; use letters, digits, dot, dash or underscore')
    return f"{value}@{REALM}"


def _load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, type(default)) else default
    except (OSError, ValueError, TypeError):
        return default


def _atomic_write(path, text, mode=0o600):
    directory = os.path.dirname(path)
    os.makedirs(directory, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".accel-", dir=directory, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_path, mode)
        os.replace(tmp_path, path)
    finally:
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass


def _locked_chap_records():
    os.makedirs(os.path.dirname(CHAP_LOCK_FILE), exist_ok=True)
    lock = open(CHAP_LOCK_FILE, "a+", encoding="utf-8")
    try:
        os.chmod(CHAP_LOCK_FILE, 0o600)
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        records = {}
        try:
            with open(CHAP_SECRETS_FILE, "r", encoding="utf-8") as source:
                for raw in source:
                    line = raw.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split()
                    if len(parts) < 4:
                        continue
                    login, _server, password, address = parts[:4]
                    records[_display_username(login)] = {
                        "login": _login_username(login),
                        "password": password,
                        "ip": address,
                    }
        except FileNotFoundError:
            pass
        return lock, records
    except Exception:
        lock.close()
        raise


def _save_chap_records(records):
    rows = []
    for username in sorted(records, key=lambda item: item.casefold()):
        item = records[username]
        address = str(ipaddress.ip_address(item["ip"]))
        password = str(item["password"])
        if not 8 <= len(password) <= 128 or re.search(r'''[\s"'\\#]''', password):
            raise BackendError("password must be 8-128 characters without whitespace, quotes, backslash or #")
        rows.append(f'{_login_username(username)} * {password} {address}\n')
    _atomic_write(CHAP_SECRETS_FILE, "".join(rows), 0o600)


def sync_static_ips(mappings=None):
    mappings = mappings if isinstance(mappings, dict) else _load_json(STATIC_IP_FILE, {})
    lock, records = _locked_chap_records()
    try:
        changed = False
        for username, address in mappings.items():
            short = _display_username(username)
            if short not in records:
                continue
            clean_address = str(ipaddress.ip_address(address))
            if records[short]["ip"] != clean_address:
                records[short]["ip"] = clean_address
                changed = True
        if changed:
            _save_chap_records(records)
    finally:
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        lock.close()
    return True


def _run_cli(command, timeout=10):
    try:
        result = subprocess.run(
            [ACCEL_CMD, "-H", ACCEL_HOST, "-p", ACCEL_PORT, command],
            capture_output=True,
            text=True,
            timeout=max(1, float(timeout)),
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise BackendError(type(exc).__name__) from exc
    output = (result.stdout or "") + (result.stderr or "")
    if result.returncode:
        raise BackendError(output.strip() or f"accel-cmd rc={result.returncode}")
    return output


def _parse_cli_table(text):
    lines = [line.rstrip() for line in (text or "").splitlines() if "|" in line]
    if not lines:
        return []
    header_index = None
    headers = []
    for index, line in enumerate(lines):
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        lowered = [cell.casefold() for cell in cells]
        if "username" in lowered and "ifname" in lowered:
            header_index = index
            headers = lowered
            break
    if header_index is None:
        return []
    rows = []
    for line in lines[header_index + 1 :]:
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) != len(headers) or all(set(cell) <= {"-", "+"} for cell in cells):
            continue
        row = dict(zip(headers, cells))
        if row.get("username") and row.get("ifname"):
            rows.append(row)
    return rows


def sessions(timeout=10, fresh=False):
    now = time.monotonic()
    if not fresh and now - _session_cache["at"] <= SESSION_CACHE_SECONDS:
        return [dict(item) for item in _session_cache["rows"]]
    columns = "ifname,username,ip,state,calling-sid,sid,rx-bytes-raw,tx-bytes-raw"
    rows = _parse_cli_table(_run_cli(f"show sessions {columns}", timeout))
    result = []
    for row in rows:
        try:
            address = str(ipaddress.ip_address(row.get("ip", "")))
        except ValueError:
            address = ""
        result.append(
            {
                "ifname": row.get("ifname", ""),
                "username": _display_username(row.get("username", "")),
                "ip": address,
                "state": row.get("state", ""),
                "calling_sid": row.get("calling-sid", ""),
                "sid": row.get("sid", ""),
                "rx": int(re.sub(r"\D", "", row.get("rx-bytes-raw", "")) or 0),
                "tx": int(re.sub(r"\D", "", row.get("tx-bytes-raw", "")) or 0),
            }
        )
    _session_cache["at"] = now
    _session_cache["rows"] = result
    return [dict(item) for item in result]


def terminate_session(session_name, timeout=10):
    ifname = str(session_name or "").removeprefix("SID-")
    target = next((item for item in sessions(timeout, fresh=True) if item["ifname"] == ifname), None)
    if not target:
        return
    login = _login_username(target["username"])
    _run_cli(f"terminate match username {login} hard", timeout)
    _session_cache["at"] = 0


def terminate_user(username, timeout=10):
    login = _login_username(username)
    _run_cli(f"terminate match username {login} hard", timeout)
    _session_cache["at"] = 0


def _record_lines(records):
    output = []
    for record in records:
        for key, value in record:
            output.append(f"{key:<31}|{value}")
        output.append("")
    output.append(SUCCESS)
    return "\n".join(output)


def _option(parts, prefix, default=""):
    wanted = prefix.upper() + ":"
    for part in parts:
        if part.upper().startswith(wanted):
            return part.split(":", 1)[1]
    return default


def compat_command(parts, hub=None, timeout=10):
    del hub
    if isinstance(parts, str):
        parts = parts.split()
    parts = [str(part) for part in parts]
    if not parts:
        raise BackendError("empty command")
    command = parts[0].casefold()

    if command == "userlist":
        _lock, records = _locked_chap_records()
        try:
            return _record_lines(
                [("User Name", username), ("Auth Type", "Password Authentication")]
                for username in sorted(records, key=lambda item: item.casefold())
            )
        finally:
            fcntl.flock(_lock.fileno(), fcntl.LOCK_UN)
            _lock.close()

    if command in {"sessionlist", "iptable"}:
        active = sessions(timeout, fresh=True)
        records = []
        for item in active:
            common = [
                ("Session Name", f'SID-{item["ifname"]}'),
                ("User Name", item["username"]),
                ("IP Address", item["ip"]),
            ]
            if command == "sessionlist":
                common.extend(
                    [
                        ("Source Host Name", item["calling_sid"]),
                        ("Client Host Name", item["calling_sid"]),
                    ]
                )
            records.append(common)
        return _record_lines(records)

    if command in {"dhcptable", "mactable"}:
        return _record_lines([])

    if command == "userget":
        username = _display_username(parts[1] if len(parts) > 1 else "")
        active = [item for item in sessions(timeout, fresh=True) if item["username"] == username]
        download = sum(item["tx"] for item in active)
        upload = sum(item["rx"] for item in active)
        return _record_lines(
            [
                [
                    ("User Name", username),
                    ("Outgoing Unicast Total Size", str(download)),
                    ("Outgoing Broadcast Total Size", "0"),
                    ("Incoming Unicast Total Size", str(upload)),
                    ("Incoming Broadcast Total Size", "0"),
                ]
            ]
        )

    if command == "usercreate":
        username = _display_username(parts[1] if len(parts) > 1 else "")
        mappings = _load_json(STATIC_IP_FILE, {})
        if username not in mappings:
            raise BackendError("static IP missing")
        lock, records = _locked_chap_records()
        try:
            if any(name.casefold() == username.casefold() for name in records):
                raise BackendError("user already exists")
            records[username] = {
                "login": _login_username(username),
                "password": secrets.token_urlsafe(24),
                "ip": str(ipaddress.ip_address(mappings[username])),
            }
            _save_chap_records(records)
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            lock.close()
        return SUCCESS

    if command == "userpasswordset":
        username = _display_username(parts[1] if len(parts) > 1 else "")
        password = _option(parts, "/PASSWORD")
        if not password:
            raise BackendError("password missing")
        lock, records = _locked_chap_records()
        try:
            if username not in records:
                raise BackendError("user not found")
            records[username]["password"] = password
            _save_chap_records(records)
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            lock.close()
        return SUCCESS

    if command == "userpolicyset":
        return SUCCESS

    if command == "userdelete":
        username = _display_username(parts[1] if len(parts) > 1 else "")
        try:
            terminate_user(username, timeout)
        except BackendError:
            pass
        lock, records = _locked_chap_records()
        try:
            if username not in records:
                raise BackendError("user not found")
            del records[username]
            _save_chap_records(records)
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            lock.close()
        return SUCCESS

    if command == "sessiondisconnect":
        terminate_session(parts[1] if len(parts) > 1 else "", timeout)
        return SUCCESS

    raise BackendError(f"unsupported command: {parts[0]}")
