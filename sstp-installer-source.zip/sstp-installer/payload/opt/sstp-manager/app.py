import subprocess, os, re, random, json, time, tarfile, io, tempfile, fcntl, logging, ipaddress, shlex, secrets, glob
from datetime import datetime
from flask import Flask, request, redirect, url_for, session, flash, render_template_string, send_file, jsonify
from functools import wraps
from contextlib import contextmanager
from accel_backend import BackendError, compat_command, sessions as accel_sessions, sync_static_ips, terminate_user

app = Flask(__name__)
ADMIN_DIR = '/opt/sstp-manager'
with open(f'{ADMIN_DIR}/.secret_key', encoding='utf-8') as secret_file:
    app.secret_key = secret_file.read().strip()
app.config.update(
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    MAX_CONTENT_LENGTH=1024 * 1024,
)

HUB = 'VPN'
TRAFFIC_FILE = os.environ.get('SSTP_TRAFFIC_FILE', f'{ADMIN_DIR}/traffic.json')
TRAFFIC_LOCK_FILE = TRAFFIC_FILE + '.lock'
TRAFFIC_SCHEMA_VERSION = 3
TRAFFIC_SAMPLE_BATCH = int(os.environ.get('SSTP_TRAFFIC_SAMPLE_BATCH', '8'))
TRAFFIC_VIEW_FILE = os.environ.get(
    'SSTP_TRAFFIC_VIEW_FILE', f'{ADMIN_DIR}/traffic-view.json'
)
TRAFFIC_VIEW_SCHEMA_VERSION = 1
STATUS_CACHE_FILE = os.environ.get(
    'SSTP_STATUS_CACHE_FILE', f'{ADMIN_DIR}/status-cache.json'
)
STATUS_CACHE_LOCK_FILE = STATUS_CACHE_FILE + '.lock'
STATUS_CACHE_SCHEMA_VERSION = 1
STATUS_CACHE_STALE_AFTER = float(os.environ.get('SSTP_STATUS_STALE_AFTER', '8'))
STATUS_VPNCMD_TIMEOUT = float(os.environ.get('SSTP_STATUS_VPNCMD_TIMEOUT', '6'))
VPNCMD_LOCK_FILE = os.environ.get(
    'SSTP_VPNCMD_LOCK_FILE', '/run/lock/sstp-vpncmd.lock'
)
VPNCMD_LOCK_WAIT = float(os.environ.get('SSTP_VPNCMD_LOCK_WAIT', '10'))
VPN_TAP_INTERFACE = 'sstp0'
DNSMASQ_LEASE_FILE = '/var/lib/misc/sstp-dnsmasq.leases'
STATIC_IP_FILE = f'{ADMIN_DIR}/static-ips.json'
KNOWN_MAC_FILE = f'{ADMIN_DIR}/known-macs.json'
PORT_FORWARD_FILE = f'{ADMIN_DIR}/port-forwards.json'
NETWORK_SETTINGS_FILE = f'{ADMIN_DIR}/network-settings.json'
ACCESS_NETWORK_FILE = f'{ADMIN_DIR}/access-networks.json'
ROUTES_FILE = f'{ADMIN_DIR}/routes.json'
LOG_JOURNAL_UNITS = (
    'sstp-accel.service',
    'sstp-manager.service',
    'sstp-manager-collector.service',
    'sstp-nft-reconcile.service',
    'sstp-nft-reconcile.timer',
    'sstp-cascade.service',
    'sstp-cascade.timer',
)
LOG_SOURCE_LABELS = {
    'connections': 'Подключения SSTP',
    'server': 'Сервер Accel-PPP',
    'services': 'Службы SSTP',
}
NFT_APPLY = '/usr/local/sbin/sstp-nft-apply'
NFT_BIN = '/usr/sbin/nft'
CASCADE_EXIT_CONTROL = '/usr/local/sbin/sstp-cascade-exit'
VPN_NETWORK = ipaddress.ip_network('10.77.0.0/24')
VPN_GATEWAY = ipaddress.ip_address('10.77.0.1')
VPN_STAGING_IP = ipaddress.ip_address('10.77.0.254')
VPN_MANAGEMENT_IP = ipaddress.ip_address('10.77.0.250')
VPN_PROBE_IP = ipaddress.ip_address('10.77.0.253')
DEFAULT_NETWORK_SETTINGS = {
    'pool_start': '10.77.0.10',
    'pool_end': '10.77.0.249',
    'nat_enabled': True,
}
RESERVED_PUBLIC_PORTS = {22, 80, 2001, 5001, int("__ADMIN_PORT__"), int("__SSTP_PORT__")}
DEFAULT_PUBLIC_PORT_START = 2100
VPNCMD_TIMEOUT = 15
VPNCMD_SUCCESS_MARKER = 'The command completed successfully.'

logger = logging.getLogger(__name__)

try:
    with open('/etc/sstp-manager/reserved-ports.json', encoding='utf-8') as handle:
        RESERVED_PUBLIC_PORTS.update(int(port) for port in json.load(handle))
except (OSError, ValueError, TypeError):
    pass

def _load_json(path, default):
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, type(default)) else default
    except (FileNotFoundError, OSError, ValueError, TypeError):
        return default

def _save_json(path, data):
    directory = os.path.dirname(path)
    os.makedirs(directory, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix='.state-', suffix='.tmp', dir=directory)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, path)
        os.chmod(path, 0o600)
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)

def load_network_settings():
    raw = _load_json(NETWORK_SETTINGS_FILE, {})
    settings = dict(DEFAULT_NETWORK_SETTINGS)
    settings.update({key: raw[key] for key in settings if key in raw})
    try:
        first = ipaddress.ip_address(str(settings['pool_start']))
        last = ipaddress.ip_address(str(settings['pool_end']))
    except ValueError:
        return dict(DEFAULT_NETWORK_SETTINGS)
    usable_first = VPN_GATEWAY + 1
    usable_last = VPN_PROBE_IP - 1
    if (
        first.version != 4 or last.version != 4
        or first not in VPN_NETWORK or last not in VPN_NETWORK
        or not (usable_first <= first <= last <= usable_last)
    ):
        return dict(DEFAULT_NETWORK_SETTINGS)
    return {
        'pool_start': str(first),
        'pool_end': str(last),
        'nat_enabled': bool(settings.get('nat_enabled', True)),
    }

def validate_network_settings(pool_start, pool_end, nat_enabled):
    try:
        first = ipaddress.ip_address(pool_start)
        last = ipaddress.ip_address(pool_end)
    except ValueError as exc:
        raise ValueError('Начало и конец пула должны быть корректными IPv4-адресами.') from exc
    usable_first = VPN_GATEWAY + 1
    usable_last = VPN_PROBE_IP - 1
    if first.version != 4 or last.version != 4 or first not in VPN_NETWORK or last not in VPN_NETWORK:
        raise ValueError(f'Пул должен находиться внутри {VPN_NETWORK}.')
    if not (usable_first <= first <= last <= usable_last):
        raise ValueError(f'Допустимый пул: от {usable_first} до {usable_last}.')
    return {
        'pool_start': str(first),
        'pool_end': str(last),
        'nat_enabled': bool(nat_enabled),
    }

def vpn_pool_bounds():
    settings = load_network_settings()
    return (
        ipaddress.ip_address(settings['pool_start']),
        ipaddress.ip_address(settings['pool_end']),
    )

def load_static_ips():
    data = _load_json(STATIC_IP_FILE, {})
    result = {}
    pool_first, pool_last = vpn_pool_bounds()
    for username, value in data.items():
        try:
            address = ipaddress.ip_address(str(value))
        except ValueError:
            continue
        if address in VPN_NETWORK and pool_first <= address <= pool_last:
            result[str(username)] = str(address)
    return result

def load_known_macs():
    data = _load_json(KNOWN_MAC_FILE, {})
    result = {}
    for username, value in data.items():
        mac = _normalise_mac(str(value))
        if mac:
            result[str(username)] = mac
    return result

def validate_static_ip(value, username='', mappings=None):
    try:
        address = ipaddress.ip_address(value)
    except ValueError as exc:
        raise ValueError('Укажите корректный IPv4-адрес.') from exc
    if address.version != 4 or address not in VPN_NETWORK:
        raise ValueError(f'IP должен относиться к сети {VPN_NETWORK}.')
    pool_first, pool_last = vpn_pool_bounds()
    if not (pool_first <= address <= pool_last) or address == VPN_GATEWAY:
        raise ValueError(f'Выберите адрес от {pool_first} до {pool_last}.')
    mappings = mappings if mappings is not None else load_static_ips()
    for other_user, other_ip in mappings.items():
        if other_user != username and other_ip == str(address):
            raise ValueError(f'IP {address} уже назначен пользователю {other_user}.')
    return str(address)

def apply_static_ips():
    try:
        sync_static_ips(load_static_ips())
        return subprocess.CompletedProcess(
            [], 0, 'Accel-PPP static IP map synchronized', '',
        )
    except (BackendError, ValueError, OSError) as exc:
        logger.warning(
            'Accel-PPP fixed IP sync failed: %s', type(exc).__name__,
        )
        return subprocess.CompletedProcess([], 1, '', type(exc).__name__)

def load_port_forwards():
    data = _load_json(PORT_FORWARD_FILE, [])
    result = []
    for item in data:
        if isinstance(item, dict):
            result.append(item)
    return result

def natural_rule_name_key(rule):
    """Sort rule names naturally: numbers numerically, text alphabetically."""
    label = str(rule.get('label', '')).strip().casefold()
    parts = tuple(
        (0, int(part)) if part.isdigit() else (1, part)
        for part in re.split(r'(\d+)', label)
        if part
    )
    return (0 if label.isdigit() else 1, parts, label)

def next_available_static_ip(mappings=None):
    """Return the first unused permanent address from the configured pool."""
    if mappings is None:
        mappings = load_static_ips()
    first, last = vpn_pool_bounds()
    used = set()
    for value in mappings.values():
        try:
            used.add(ipaddress.ip_address(value))
        except ValueError:
            continue
    for raw_address in range(int(first), int(last) + 1):
        address = ipaddress.ip_address(raw_address)
        if address not in used and address not in {VPN_GATEWAY, VPN_STAGING_IP, VPN_PROBE_IP, VPN_MANAGEMENT_IP}:
            return str(address)
    return ''

def next_available_public_port(forwards=None):
    """Return the first unused public port in the panel's numeric queue."""
    if forwards is None:
        forwards = load_port_forwards()
    used = set()
    for item in forwards:
        try:
            used.add(int(item.get('public_port')))
        except (TypeError, ValueError):
            continue
    for port in range(DEFAULT_PUBLIC_PORT_START, 65536):
        if port not in used and port not in RESERVED_PUBLIC_PORTS:
            return port
    return ''

def apply_port_forwards():
    return subprocess.run(
        [NFT_APPLY], capture_output=True, text=True, timeout=20, check=False,
    )

def load_port_forward_diagnostics():
    rules = load_port_forwards()
    diagnostics = {
        str(item.get('id', '')): {
            'wan_attempts': 0,
            'loopback_attempts': 0,
            'forward_packets': 0,
            'reply_packets': 0,
        }
        for item in rules if item.get('id')
    }
    completed = subprocess.run(
        [NFT_BIN, '-a', 'list', 'table', 'ip', 'sstp_manager'],
        capture_output=True, text=True, timeout=5, check=False,
    )
    if completed.returncode:
        raise RuntimeError('nftables state unavailable')
    stage_fields = {
        'wan': 'wan_attempts',
        'loopback': 'loopback_attempts',
        'forward': 'forward_packets',
        'loop-forward': 'forward_packets',
        'reply': 'reply_packets',
    }
    for line in completed.stdout.splitlines():
        marker = re.search(
            r'comment "pf:([0-9a-f]{16}):(wan|loopback|forward|loop-forward|reply)"',
            line,
        )
        counter = re.search(r'counter packets (\d+) bytes (\d+)', line)
        if not marker or not counter:
            continue
        rule_id, stage = marker.groups()
        if rule_id not in diagnostics:
            continue
        field = stage_fields[stage]
        diagnostics[rule_id][field] += int(counter.group(1))
    return diagnostics

def apply_network_settings():
    return apply_port_forwards()

def load_cascade_exit_status():
    fallback = {
        'available': False,
        'status_available': False,
        'mode': 'direct',
        'enabled': False,
        'direct_ip': '',
        'exit_ip': '',
        'port': 0,
        'runtime_ip': '',
        'healthy': False,
        'handshake_label': 'статус недоступен',
        'job': {'active': False, 'stage': 'idle', 'message': ''},
    }
    try:
        result = subprocess.run(
            [CASCADE_EXIT_CONTROL, 'status'],
            capture_output=True, text=True, timeout=5, check=False,
        )
        payload = json.loads(result.stdout)
        address_text = str(payload.get('exit_ip', '')).strip()
        address = ipaddress.ip_address(address_text) if address_text else None
        port = int(payload.get('port', 0))
    except (OSError, subprocess.TimeoutExpired, ValueError, TypeError, json.JSONDecodeError):
        logger.warning('Cascade exit status is unavailable')
        return fallback
    if (
        result.returncode or not payload.get('success')
        or (address is not None and address.version != 4)
        or not 0 <= port <= 65535
    ):
        logger.warning('Cascade exit status returned invalid data')
        return fallback
    return {
        'available': payload.get('available') is True,
        'status_available': True,
        'mode': 'cascade' if payload.get('enabled') is True else 'direct',
        'enabled': payload.get('enabled') is True,
        'direct_ip': str(payload.get('direct_ip', '')),
        'exit_ip': str(address) if address is not None else '',
        'port': port,
        'runtime_ip': str(payload.get('runtime_ip', '')),
        'healthy': payload.get('healthy') is True,
        'handshake_label': str(payload.get('handshake_label', 'статус недоступен'))[:80],
        'job': payload.get('job') if isinstance(payload.get('job'), dict) else fallback['job'],
    }

def validate_private_network(value):
    try:
        network = ipaddress.ip_network(value, strict=False)
    except ValueError as exc:
        raise ValueError('Укажите корректную IPv4-подсеть в формате 192.168.1.0/24.') from exc
    if network.version != 4 or network.prefixlen == 0 or not network.is_private:
        raise ValueError('Разрешены только частные IPv4-подсети, но не маршрут 0.0.0.0/0.')
    if network.overlaps(VPN_NETWORK):
        raise ValueError(f'Подсеть не должна пересекаться с VPN-сетью {VPN_NETWORK}.')
    return str(network)

def load_access_networks():
    result = []
    for item in _load_json(ACCESS_NETWORK_FILE, []):
        if not isinstance(item, dict):
            continue
        try:
            cidr = validate_private_network(str(item.get('cidr', '')))
        except ValueError:
            continue
        result.append({
            'id': str(item.get('id', '')),
            'label': str(item.get('label', ''))[:48],
            'cidr': cidr,
        })
    return result

def load_routes():
    static_ips = load_static_ips()
    result = []
    for item in _load_json(ROUTES_FILE, []):
        if not isinstance(item, dict):
            continue
        username = str(item.get('user', ''))
        try:
            cidr = validate_private_network(str(item.get('cidr', '')))
        except ValueError:
            continue
        next_hop = static_ips.get(username)
        if not next_hop:
            continue
        result.append({
            'id': str(item.get('id', '')),
            'label': str(item.get('label', ''))[:48],
            'cidr': cidr,
            'user': username,
            'next_hop': next_hop,
        })
    return result

def _empty_traffic(month=None):
    now = datetime.now()
    return {
        'schema': TRAFFIC_SCHEMA_VERSION,
        'month': month or now.strftime('%Y-%m'),
        'users': {},
        'last_sessions': {},
        'daily': {},
        'sample_cursor': 0,
        'accurate_since': now.strftime('%Y-%m-%d %H:%M:%S'),
    }

@contextmanager
def _traffic_lock():
    os.makedirs(os.path.dirname(TRAFFIC_LOCK_FILE), exist_ok=True)
    with open(TRAFFIC_LOCK_FILE, 'a+', encoding='utf-8') as lock_file:
        os.chmod(TRAFFIC_LOCK_FILE, 0o600)
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)

def _normalise_traffic(data):
    current_month = datetime.now().strftime('%Y-%m')
    if not isinstance(data, dict) or data.get('month') != current_month:
        return _empty_traffic(current_month)

    schema = data.get('schema')
    if schema == 2:
        # Preserve the existing monthly totals, but discard the unsafe
        # per-user aggregate baselines. Active sessions become baselines on
        # the first schema-3 sample and are not charged twice.
        migrated = _empty_traffic(current_month)
        for username, old in data.get('users', {}).items():
            if not isinstance(old, dict):
                continue
            migrated['users'][username] = {
                'dl': max(0, int(old.get('dl', 0) or 0)),
                'ul': max(0, int(old.get('ul', 0) or 0)),
                'legacy_total': max(0, int(old.get('legacy_total', 0) or 0)),
            }
        return migrated

    if schema != TRAFFIC_SCHEMA_VERSION:
        migrated = _empty_traffic(current_month)
        for username, old in data.get('users', {}).items():
            if not isinstance(old, dict):
                continue
            legacy_total = (
                max(0, int(old.get('dl', 0) or 0))
                + max(0, int(old.get('ul', 0) or 0))
                + max(0, int(old.get('legacy_total', 0) or 0))
            )
            migrated['users'][username] = {
                'dl': 0, 'ul': 0, 'legacy_total': legacy_total,
            }
        return migrated

    if not isinstance(data.get('users'), dict):
        data['users'] = {}
    if not isinstance(data.get('last_sessions'), dict):
        data['last_sessions'] = {}
    if not isinstance(data.get('daily'), dict):
        data['daily'] = {}
    data.setdefault('sample_cursor', 0)
    data.setdefault('accurate_since', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    data.pop('last_user', None)
    return data

def _load_traffic_unlocked():
    try:
        with open(TRAFFIC_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return _normalise_traffic(data)
    except FileNotFoundError:
        return _empty_traffic()
    except (OSError, ValueError, TypeError) as exc:
        corrupt_path = f'{TRAFFIC_FILE}.corrupt-{datetime.now().strftime("%Y%m%d_%H%M%S")}'
        try:
            if os.path.exists(TRAFFIC_FILE):
                os.replace(TRAFFIC_FILE, corrupt_path)
        except OSError:
            logger.exception('Unable to preserve corrupt traffic file')
        logger.warning('Traffic data was unreadable and preserved as %s: %s', corrupt_path, exc)
        return _empty_traffic()

def _save_traffic_unlocked(data):
    directory = os.path.dirname(TRAFFIC_FILE)
    os.makedirs(directory, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix='.traffic-', suffix='.tmp', dir=directory)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, sort_keys=True)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, TRAFFIC_FILE)
        os.chmod(TRAFFIC_FILE, 0o600)
        dir_fd = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    except Exception:
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass
        raise

def load_traffic():
    with _traffic_lock():
        return _load_traffic_unlocked()

def save_traffic(data):
    with _traffic_lock():
        _save_traffic_unlocked(_normalise_traffic(data))


def _empty_traffic_view(month=None):
    return {
        'schema': TRAFFIC_VIEW_SCHEMA_VERSION,
        'month': month or datetime.now().strftime('%Y-%m'),
        'reset_at': '',
        'users': {},
    }


def _load_traffic_view_unlocked(month):
    try:
        with open(TRAFFIC_VIEW_FILE, 'r', encoding='utf-8') as view_file:
            data = json.load(view_file)
    except FileNotFoundError:
        return _empty_traffic_view(month)
    except (OSError, ValueError, TypeError) as exc:
        logger.warning('Traffic view data is unreadable; ignoring it: %s', type(exc).__name__)
        return _empty_traffic_view(month)
    if (
        not isinstance(data, dict)
        or data.get('schema') != TRAFFIC_VIEW_SCHEMA_VERSION
        or data.get('month') != month
        or not isinstance(data.get('users'), dict)
    ):
        return _empty_traffic_view(month)
    data.setdefault('reset_at', '')
    return data


def _save_traffic_view_unlocked(data):
    directory = os.path.dirname(TRAFFIC_VIEW_FILE)
    os.makedirs(directory, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix='.traffic-view-', suffix='.tmp', dir=directory)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as view_file:
            json.dump(data, view_file, indent=2, sort_keys=True)
            view_file.write('\n')
            view_file.flush()
            os.fsync(view_file.fileno())
        os.replace(tmp_path, TRAFFIC_VIEW_FILE)
        os.chmod(TRAFFIC_VIEW_FILE, 0o600)
    except Exception:
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass
        raise


def load_traffic_view(month):
    with _traffic_lock():
        return _load_traffic_view_unlocked(month)


def _traffic_view_record(record):
    return {
        'dl': max(0, int(record.get('dl', 0) or 0)),
        'ul': max(0, int(record.get('ul', 0) or 0)),
        'legacy_total': max(0, int(record.get('legacy_total', 0) or 0)),
    }


def reset_traffic_view_baseline():
    """Set a display-only baseline without changing monthly or SoftEther counters."""
    with _traffic_lock():
        traffic = _load_traffic_unlocked()
        baseline = _empty_traffic_view(traffic['month'])
        baseline['reset_at'] = datetime.now().astimezone().isoformat(timespec='seconds')
        for username, record in traffic.get('users', {}).items():
            baseline['users'][username] = _traffic_view_record(record)
        _save_traffic_view_unlocked(baseline)
    return baseline['reset_at']


def reset_user_traffic_view_baseline(username):
    """Reset only one user's display baseline; monthly counters remain intact."""
    with _traffic_lock():
        traffic = _load_traffic_unlocked()
        baseline = _load_traffic_view_unlocked(traffic['month'])
        record = traffic.get('users', {}).get(username, {})
        baseline['users'][username] = _traffic_view_record(record)
        reset_at = datetime.now().astimezone().isoformat(timespec='seconds')
        baseline.setdefault('user_reset_at', {})[username] = reset_at
        _save_traffic_view_unlocked(baseline)
    return reset_at


def _traffic_since_view_baseline(record, baseline):
    return {
        key: max(0, int(record.get(key, 0) or 0) - int(baseline.get(key, 0) or 0))
        for key in ('dl', 'ul', 'legacy_total')
    }

class VpncmdError(RuntimeError):
    def __init__(self, command, kind, detail=''):
        self.command = command
        self.kind = kind
        self.detail = detail
        super().__init__(f'{command}: {kind}' + (f' ({detail})' if detail else ''))

    @property
    def public_message(self):
        if self.kind == 'busy':
            return (
                f'Административный канал VPN-сервера занят при выполнении {self.command}. '
                'Повторите действие через несколько секунд.'
            )
        if self.kind == 'timeout':
            return f'Команда VPN-сервера {self.command} не ответила вовремя. Результат не определён.'
        if self.kind == 'unavailable':
            return f'Не удалось запустить команду VPN-сервера {self.command}. Результат не определён.'
        return f'VPN-сервер отклонил команду {self.command}. Успешное выполнение не подтверждено.'


@contextmanager
def _vpncmd_process_lock(command_name, wait_timeout=VPNCMD_LOCK_WAIT):
    """Serialize SoftEther administration commands across all panel processes."""
    os.makedirs(os.path.dirname(VPNCMD_LOCK_FILE), exist_ok=True)
    deadline = time.monotonic() + max(0.1, float(wait_timeout))
    with open(VPNCMD_LOCK_FILE, 'a+', encoding='utf-8') as lock_file:
        while True:
            try:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise VpncmdError(command_name, 'busy', f'{wait_timeout}s')
                time.sleep(0.05)
        try:
            yield
        finally:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


class StatusCacheError(RuntimeError):
    def __init__(self, message, snapshot=None):
        self.public_message = message
        self.snapshot = snapshot
        super().__init__(message)


def _vpncmd_failure_detail(output, secrets=()):
    safe = output or ''
    safe = re.sub(r'(?i)/PASSWORD:\S+', '/PASSWORD:[redacted]', safe)
    for secret in secrets:
        if secret:
            safe = safe.replace(secret, '[redacted]')
    error_lines = [
        line.strip() for line in safe.splitlines()
        if re.search(r'(?i)error|failed|denied|not found', line)
    ]
    if not error_lines:
        return 'success marker missing'
    return ' | '.join(error_lines[-2:])[:300]


def vpncmd(cmd, hub=None, timeout=VPNCMD_TIMEOUT):
    if isinstance(cmd, str):
        parts = shlex.split(cmd)
    else:
        parts = [str(part) for part in cmd]
    if not parts:
        raise VpncmdError('unknown', 'invalid', 'empty command')

    command_name = parts[0]
    with _vpncmd_process_lock(command_name):
        try:
            return compat_command(parts, hub=hub, timeout=timeout)
        except BackendError as exc:
            logger.warning(
                'Accel-PPP backend command %s failed: %s',
                command_name, type(exc).__name__,
            )
            raise VpncmdError(
                command_name, 'rejected', type(exc).__name__,
            ) from exc


@contextmanager
def _status_cache_lock():
    directory = os.path.dirname(STATUS_CACHE_LOCK_FILE)
    os.makedirs(directory, exist_ok=True)
    with open(STATUS_CACHE_LOCK_FILE, 'a+', encoding='utf-8') as lock_file:
        os.chmod(STATUS_CACHE_LOCK_FILE, 0o600)
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


def _read_status_cache_unlocked():
    with open(STATUS_CACHE_FILE, 'r', encoding='utf-8') as cache_file:
        data = json.load(cache_file)
    if (
        not isinstance(data, dict)
        or data.get('schema') != STATUS_CACHE_SCHEMA_VERSION
        or not isinstance(data.get('users'), list)
        or not isinstance(data.get('collected_ts'), (int, float))
    ):
        raise ValueError('invalid status cache schema')
    return data


def _write_status_cache_unlocked(data):
    directory = os.path.dirname(STATUS_CACHE_FILE)
    os.makedirs(directory, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix='.status-cache-', suffix='.tmp', dir=directory)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as cache_file:
            json.dump(data, cache_file, ensure_ascii=False, separators=(',', ':'))
            cache_file.write('\n')
            cache_file.flush()
            os.fsync(cache_file.fileno())
        os.replace(tmp_path, STATUS_CACHE_FILE)
        os.chmod(STATUS_CACHE_FILE, 0o600)
    except Exception:
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass
        raise


def save_status_snapshot(snapshot):
    data = dict(snapshot)
    data['schema'] = STATUS_CACHE_SCHEMA_VERSION
    data['collector_error'] = ''
    data['collector_error_at'] = ''
    with _status_cache_lock():
        _write_status_cache_unlocked(data)


def mark_status_cache_error(message):
    with _status_cache_lock():
        try:
            data = _read_status_cache_unlocked()
        except (FileNotFoundError, OSError, ValueError, TypeError, json.JSONDecodeError):
            data = {
                'schema': STATUS_CACHE_SCHEMA_VERSION,
                'collected_at': '',
                'collected_ts': 0,
                'users': [],
                'month': datetime.now().strftime('%Y-%m'),
                'total_dl': 'н/д',
                'total_ul': 'н/д',
                'total_all': 'н/д',
                'traffic_note': 'Данные статуса ещё не собраны.',
            }
        data['collector_error'] = message
        data['collector_error_at'] = datetime.now().astimezone().isoformat(timespec='seconds')
        _write_status_cache_unlocked(data)


def load_status_snapshot(require_fresh=True):
    try:
        with _status_cache_lock():
            data = _read_status_cache_unlocked()
    except FileNotFoundError as exc:
        raise StatusCacheError('Сборщик данных запускается; статус пока недоступен.') from exc
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise StatusCacheError('Кэш статусов недоступен для чтения; состояние не определено.') from exc

    data = dict(data)
    age = max(0.0, time.time() - float(data['collected_ts']))
    data['age_seconds'] = round(age, 1)
    if require_fresh and data.get('collector_error'):
        raise StatusCacheError(data['collector_error'], data)
    if require_fresh and age > STATUS_CACHE_STALE_AFTER:
        raise StatusCacheError(
            f'Данные статуса устарели (возраст {age:.1f} с); текущая таблица сохранена.',
            data,
        )
    return data


def cached_usernames():
    try:
        snapshot = load_status_snapshot(require_fresh=False)
    except StatusCacheError:
        return []
    return [
        user.get('name') for user in snapshot.get('users', [])
        if isinstance(user, dict) and user.get('name')
    ]

def _parse_softether_records(text):
    records = []
    current = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or '---' in stripped:
            if current:
                records.append(current)
                current = {}
            continue
        if '|' in line:
            key, value = line.split('|', 1)
            key = key.strip()
            if key in current:
                records.append(current)
                current = {}
            current[key] = value.strip()
    if current:
        records.append(current)
    return records


def _clean_ipv4(value):
    candidate = (value or '').split(' ', 1)[0].strip()
    try:
        parsed = ipaddress.ip_address(candidate)
    except ValueError:
        return ''
    return str(parsed) if parsed.version == 4 else ''


def _normalise_mac(value):
    candidate = (value or '').strip().lower().replace('-', ':')
    if re.fullmatch(r'[0-9a-f]{2}(?::[0-9a-f]{2}){5}', candidate):
        return candidate
    return ''


def parse_dhcp_table(text):
    entries = {}
    for record in _parse_softether_records(text):
        host = record.get('Client Host Name', '')
        ip = _clean_ipv4(record.get('Allocated IP', ''))
        if host and ip:
            entries[host] = ip
    return entries


def _parse_softether_int(value):
    return int(re.sub(r'[^0-9]', '', value or '0') or 0)

def parse_session_list(text):
    sessions = []
    for record in _parse_softether_records(text):
        sname = record.get('Session Name', '')
        uname = record.get('User Name', '')
        if sname.startswith('SID-') and uname and uname not in ('(Unknown)', 'SecureNAT'):
            sessions.append({
                'user': uname,
                'session': sname,
                'client_ip': record.get('Source Host Name', '') or record.get('Client Host Name', ''),
                'vpn_ip': _clean_ipv4(record.get('IP Address', '')),
            })
    return sessions

def parse_ip_table(text):
    """Parse IpTable: session_name -> vpn_ip"""
    entries = {}
    for record in _parse_softether_records(text):
        sname = record.get('Session Name', '')
        ip = _clean_ipv4(record.get('IP Address', ''))
        if sname.startswith('SID-') and ip:
            entries[sname] = ip
    return entries


def parse_mac_table(text):
    """Parse MacTable: session_name -> learned client MAC addresses."""
    entries = {}
    for record in _parse_softether_records(text):
        sname = record.get('Session Name', '')
        mac = _normalise_mac(record.get('MAC Address', ''))
        if sname.startswith('SID-') and mac:
            entries.setdefault(sname, [])
            if mac not in entries[sname]:
                entries[sname].append(mac)
    return entries


def parse_neighbor_table(text):
    """Parse `ip neigh` into MAC -> best live IPv4 candidates."""
    state_order = {
        'REACHABLE': 0, 'DELAY': 1, 'PROBE': 2,
        'STALE': 3, 'PERMANENT': 4, 'NOARP': 5,
    }
    candidates = {}
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 4 or 'lladdr' not in parts:
            continue
        ip = _clean_ipv4(parts[0])
        mac_index = parts.index('lladdr') + 1
        mac = _normalise_mac(parts[mac_index] if mac_index < len(parts) else '')
        state = parts[-1].upper()
        if not ip or not mac or state in ('FAILED', 'INCOMPLETE'):
            continue
        candidates.setdefault(mac, []).append((state_order.get(state, 9), ip))
    return {
        mac: [ip for _, ip in sorted(values, key=lambda item: (item[0], item[1]))]
        for mac, values in candidates.items()
    }


def parse_dnsmasq_leases(text):
    """Parse dnsmasq leases into MAC -> newest allocated IPv4 candidates."""
    candidates = {}
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 3:
            continue
        try:
            expires = int(parts[0])
        except ValueError:
            continue
        mac = _normalise_mac(parts[1])
        ip = _clean_ipv4(parts[2])
        if mac and ip:
            candidates.setdefault(mac, []).append((expires, ip))
    return {
        mac: [ip for _, ip in sorted(values, key=lambda item: item[0], reverse=True)]
        for mac, values in candidates.items()
    }


def read_neighbor_table():
    if not os.path.exists(f'/sys/class/net/{VPN_TAP_INTERFACE}'):
        return {}
    try:
        result = subprocess.run(
            ['ip', '-4', 'neigh', 'show', 'dev', VPN_TAP_INTERFACE],
            capture_output=True, text=True, timeout=3,
        )
        if result.returncode != 0:
            logger.warning('Unable to read neighbor table: %s', result.stderr.strip())
            return {}
        return parse_neighbor_table(result.stdout)
    except (OSError, subprocess.TimeoutExpired):
        logger.exception('Unable to read neighbor table')
        return {}


def read_dnsmasq_leases():
    try:
        with open(DNSMASQ_LEASE_FILE, encoding='utf-8') as lease_file:
            return parse_dnsmasq_leases(lease_file.read())
    except FileNotFoundError:
        return {}
    except OSError:
        logger.exception('Unable to read dnsmasq leases')
        return {}


def build_session_info(sessions, ip_by_session, mac_by_session,
                       dhcp_by_client, neighbor_by_mac, lease_by_mac,
                       fixed_ip_by_user=None, known_mac_by_user=None):
    """Group every active session by user and resolve one current IP per session."""
    fixed_ip_by_user = fixed_ip_by_user or {}
    known_mac_by_user = known_mac_by_user or {}
    grouped = {}
    for session in sessions:
        username = session['user']
        session_name = session['session']
        client_ip = session.get('client_ip', '')
        macs = mac_by_session.get(session_name, [])
        vpn_ip = session.get('vpn_ip', '') or ip_by_session.get(session_name, '')
        source = 'accel' if session.get('vpn_ip') else ('compat' if vpn_ip else '')

        if not vpn_ip:
            for mac in macs:
                candidates = neighbor_by_mac.get(mac, [])
                if candidates:
                    vpn_ip = candidates[0]
                    source = 'neighbor'
                    break
        if not vpn_ip:
            for mac in macs:
                candidates = lease_by_mac.get(mac, [])
                if candidates:
                    vpn_ip = candidates[0]
                    source = 'lease'
                    break
        if not vpn_ip:
            vpn_ip = dhcp_by_client.get(client_ip, '')
            if vpn_ip:
                source = 'dhcp'

        # SoftEther ages idle clients out of MacTable and IpTable even while
        # their SSTP session remains active.  In that case use the selected
        # fixed IP only when the fixed-IP synchroniser has also installed the
        # same user's known MAC as a permanent kernel neighbour.  If a live
        # MacTable entry exists but differs, do not claim that the IP is ready.
        if not vpn_ip:
            fixed_ip = fixed_ip_by_user.get(username, '')
            known_mac = known_mac_by_user.get(username, '')
            fixed_candidates = neighbor_by_mac.get(known_mac, [])
            current_mac_matches = not macs or known_mac in macs
            if (
                fixed_ip and known_mac and current_mac_matches
                and fixed_ip in fixed_candidates
            ):
                vpn_ip = fixed_ip
                source = 'fixed-neighbor'

        grouped.setdefault(username, []).append({
            'session': session_name,
            'client_ip': client_ip,
            'vpn_ip': vpn_ip,
            'vpn_ip_source': source,
            'macs': macs,
        })
    return grouped

def parse_user_traffic(text):
    """Return cumulative per-user counters from SoftEther UserGet.

    Outgoing counters are bytes sent by the hub to the user (client download),
    while incoming counters are bytes received from the user (client upload).
    Broadcast and unicast traffic are both included.
    """
    fields = {}
    for line in text.split('\n'):
        if '|' not in line:
            continue
        key, value = line.split('|', 1)
        fields[key.strip()] = value.strip()

    required = ('Outgoing Unicast Total Size', 'Incoming Unicast Total Size')
    if not all(key in fields for key in required):
        return None

    download = (
        _parse_softether_int(fields.get('Outgoing Unicast Total Size'))
        + _parse_softether_int(fields.get('Outgoing Broadcast Total Size'))
    )
    upload = (
        _parse_softether_int(fields.get('Incoming Unicast Total Size'))
        + _parse_softether_int(fields.get('Incoming Broadcast Total Size'))
    )
    return {'dl': download, 'ul': upload}

def _reserve_traffic_batch(usernames):
    names = sorted(set(usernames))
    if not names:
        return []
    with _traffic_lock():
        data = _load_traffic_unlocked()
        cursor = int(data.get('sample_cursor', 0) or 0) % len(names)
        count = min(TRAFFIC_SAMPLE_BATCH, len(names))
        batch = [names[(cursor + offset) % len(names)] for offset in range(count)]
        data['sample_cursor'] = (cursor + count) % len(names)
        _save_traffic_unlocked(data)
    return batch

def _collect_session_traffic():
    counters = {}
    for session in accel_sessions(timeout=STATUS_VPNCMD_TIMEOUT, fresh=True):
        if session.get('state') != 'active':
            continue
        sid = str(session.get('sid', '')).strip()
        username = str(session.get('username', '')).strip()
        if not sid or not username:
            logger.warning(
                'Skipping Accel-PPP traffic sample without SID or username: %r',
                session,
            )
            continue
        counters[sid] = {
            'username': username,
            'dl': max(0, int(session.get('tx', 0) or 0)),
            'ul': max(0, int(session.get('rx', 0) or 0)),
        }
    return counters

def _apply_session_traffic(counters):
    with _traffic_lock():
        data = _load_traffic_unlocked()
        previous_sessions = data.setdefault('last_sessions', {})
        today = datetime.now().strftime('%Y-%m-%d')
        daily_users = data.setdefault('daily', {}).setdefault(today, {})
        next_sessions = {}

        for sid, current in counters.items():
            username = current['username']
            current_dl = max(0, int(current.get('dl', 0) or 0))
            current_ul = max(0, int(current.get('ul', 0) or 0))
            previous = previous_sessions.get(sid)
            dl_delta = 0
            ul_delta = 0

            if isinstance(previous, dict) and previous.get('username') == username:
                previous_dl = max(0, int(previous.get('dl', 0) or 0))
                previous_ul = max(0, int(previous.get('ul', 0) or 0))

                if current_dl >= previous_dl:
                    dl_delta = current_dl - previous_dl
                else:
                    logger.warning(
                        'Accel-PPP download counter decreased for SID %s (%s); '
                        'baseline replaced without charging old bytes',
                        sid, username,
                    )

                if current_ul >= previous_ul:
                    ul_delta = current_ul - previous_ul
                else:
                    logger.warning(
                        'Accel-PPP upload counter decreased for SID %s (%s); '
                        'baseline replaced without charging old bytes',
                        sid, username,
                    )

            # A previously unseen SID is a baseline. At most one polling
            # interval is omitted, while old or parallel-session bytes can
            # never be charged a second time.
            next_sessions[sid] = {
                'username': username,
                'dl': current_dl,
                'ul': current_ul,
            }

            if not dl_delta and not ul_delta:
                continue

            record = data['users'].setdefault(
                username, {'dl': 0, 'ul': 0, 'legacy_total': 0}
            )
            record.setdefault('dl', 0)
            record.setdefault('ul', 0)
            record.setdefault('legacy_total', 0)
            record['dl'] += dl_delta
            record['ul'] += ul_delta

            day_record = daily_users.setdefault(username, {'dl': 0, 'ul': 0})
            day_record['dl'] = max(0, int(day_record.get('dl', 0) or 0)) + dl_delta
            day_record['ul'] = max(0, int(day_record.get('ul', 0) or 0)) + ul_delta

        data['last_sessions'] = next_sessions
        _save_traffic_unlocked(data)
        return data

def update_traffic(usernames):
    # Keep the public signature used by collector.py. One Accel-PPP query now
    # captures every active session, independently keyed by Acct-Session-ID.
    del usernames
    return _apply_session_traffic(_collect_session_traffic())

def fmt_bytes(b):
    if b < 1024: return f'{b} Б'
    if b < 1048576: return f'{b/1024:.1f} КБ'
    if b < 1073741824: return f'{b/1048576:.1f} МБ'
    return f'{b/1073741824:.2f} ГБ'

def get_all_user_data():
    raw = vpncmd('UserList', HUB, timeout=STATUS_VPNCMD_TIMEOUT)
    usernames = re.findall(r'User Name\s*\|\s*(\S+)', raw)

    raw_sess = vpncmd('SessionList', HUB, timeout=STATUS_VPNCMD_TIMEOUT)
    sessions = parse_session_list(raw_sess)

    raw_dhcp = vpncmd('DhcpTable', HUB, timeout=STATUS_VPNCMD_TIMEOUT)
    dhcp_map = parse_dhcp_table(raw_dhcp)

    raw_iptable = vpncmd('IpTable', HUB, timeout=STATUS_VPNCMD_TIMEOUT)
    ip_by_session = parse_ip_table(raw_iptable)

    raw_mactable = vpncmd('MacTable', HUB, timeout=STATUS_VPNCMD_TIMEOUT)
    mac_by_session = parse_mac_table(raw_mactable)
    static_ips = load_static_ips()
    known_macs = load_known_macs()
    sess_info = build_session_info(
        sessions, ip_by_session, mac_by_session, dhcp_map,
        read_neighbor_table(), read_dnsmasq_leases(), static_ips, known_macs,
    )

    traffic = load_traffic()
    traffic_view = load_traffic_view(traffic['month'])

    users = []
    total_dl, total_ul, total_legacy = 0, 0, 0
    underlying_legacy = 0
    for u in usernames:
        active_sessions = sess_info.get(u, [])
        vpn_ips = list(dict.fromkeys(
            item['vpn_ip'] for item in active_sessions if item.get('vpn_ip')
        ))
        client_ips = list(dict.fromkeys(
            item['client_ip'] for item in active_sessions if item.get('client_ip')
        ))
        stored = traffic['users'].get(u, {'dl': 0, 'ul': 0, 'legacy_total': 0})
        baseline = traffic_view['users'].get(u, {})
        displayed = _traffic_since_view_baseline(stored, baseline)
        dl = displayed['dl']
        ul = displayed['ul']
        legacy = displayed['legacy_total']
        underlying_legacy += max(0, int(stored.get('legacy_total', 0) or 0))
        total_dl += dl
        total_ul += ul
        total_legacy += legacy
        desired_ip = static_ips.get(u, '')
        users.append({
            'name': u, 'online': bool(active_sessions),
            'session_count': len(active_sessions),
            'sessions': active_sessions,
            'client_ips': client_ips,
            'client_ip': client_ips[0] if client_ips else '',
            'vpn_ips': vpn_ips,
            'vpn_ip': vpn_ips[0] if vpn_ips else '',
            'desired_ip': desired_ip,
            'ip_ready': bool(desired_ip and desired_ip in vpn_ips),
            'dl': fmt_bytes(dl), 'ul': fmt_bytes(ul),
            'total': fmt_bytes(dl + ul + legacy),
        })
    if traffic_view.get('reset_at'):
        reset_label = traffic_view['reset_at'].replace('T', ' ').split('+', 1)[0]
        traffic_note = (
            f'Точка отсчёта трафика сброшена {reset_label}; показан прирост с этого момента. '
            'Месячный учёт и счётчики VPN не обнулены.'
        )
    else:
        traffic_note = ''
    return (
        users, traffic['month'], fmt_bytes(total_dl), fmt_bytes(total_ul),
        fmt_bytes(total_dl + total_ul + total_legacy), traffic_note
    )


def collect_status_snapshot():
    users, month, total_dl, total_ul, total_all, traffic_note = get_all_user_data()
    now = datetime.now().astimezone()
    return {
        'schema': STATUS_CACHE_SCHEMA_VERSION,
        'collected_at': now.isoformat(timespec='seconds'),
        'collected_ts': time.time(),
        'users': users,
        'month': month,
        'total_dl': total_dl,
        'total_ul': total_ul,
        'total_all': total_all,
        'traffic_note': traffic_note,
    }


def collect_quick_status_snapshot():
    """Refresh online state every two seconds while retaining the last full IP view."""
    try:
        snapshot = load_status_snapshot(require_fresh=False)
    except StatusCacheError:
        return collect_status_snapshot()

    raw_sessions = vpncmd('SessionList', HUB, timeout=STATUS_VPNCMD_TIMEOUT)
    active_by_user = {}
    for session_info in parse_session_list(raw_sessions):
        active_by_user.setdefault(session_info['user'], []).append(session_info)

    users = []
    for old_user in snapshot.get('users', []):
        user = dict(old_user)
        current_sessions = active_by_user.get(user.get('name'), [])
        old_by_name = {
            item.get('session'): item
            for item in user.get('sessions', [])
            if isinstance(item, dict) and item.get('session')
        }
        sessions = []
        for current in current_sessions:
            previous = old_by_name.get(current['session'], {})
            sessions.append({
                'session': current['session'],
                'client_ip': current.get('client_ip', ''),
                'vpn_ip': current.get('vpn_ip', '') or previous.get('vpn_ip', ''),
                'vpn_ip_source': (
                    'accel'
                    if current.get('vpn_ip')
                    else previous.get('vpn_ip_source', '')
                ),
                'macs': previous.get('macs', []),
            })
        vpn_ips = list(dict.fromkeys(
            item['vpn_ip'] for item in sessions if item.get('vpn_ip')
        ))
        client_ips = list(dict.fromkeys(
            item['client_ip'] for item in sessions if item.get('client_ip')
        ))
        user.update({
            'online': bool(sessions),
            'session_count': len(sessions),
            'sessions': sessions,
            'client_ips': client_ips,
            'client_ip': client_ips[0] if client_ips else '',
            'vpn_ips': vpn_ips,
            'vpn_ip': vpn_ips[0] if vpn_ips else '',
        })
        users.append(user)

    now = datetime.now().astimezone()
    snapshot.update({
        'schema': STATUS_CACHE_SCHEMA_VERSION,
        'collected_at': now.isoformat(timespec='seconds'),
        'collected_ts': time.time(),
        'users': users,
    })
    snapshot.pop('age_seconds', None)
    return snapshot

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper

def csrf_token():
    token = session.get('csrf_token')
    if not token:
        token = secrets.token_urlsafe(32)
        session['csrf_token'] = token
    return token

def csrf_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        expected = session.get('csrf_token', '')
        supplied = request.form.get('csrf', '')
        if not expected or not secrets.compare_digest(expected, supplied):
            flash('Запрос отклонён: обновите страницу и повторите действие.', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return wrapper

def _redact_log_line(value):
    line = str(value).replace('\x00', '')
    line = re.sub(r'(?i)(/PASSWORD:)[^\s]*', r'\1[скрыто]', line)
    line = re.sub(
        r'(?i)\b(password|passwd|authorization|secret|token)(\s*[:=]\s*)(\S+)',
        r'\1\2[скрыто]', line,
    )
    return line[:4000]

def _latest_log_file(pattern):
    candidates = [path for path in glob.glob(pattern) if os.path.isfile(path)]
    return max(candidates, key=os.path.getmtime) if candidates else ''

def _tail_log_file(path, line_limit, byte_limit=2 * 1024 * 1024):
    if not path:
        return [], 'файл пока не создан'
    with open(path, 'rb') as handle:
        handle.seek(0, os.SEEK_END)
        size = handle.tell()
        start = max(0, size - byte_limit)
        handle.seek(start)
        payload = handle.read(byte_limit)
    text = payload.decode('utf-8', errors='replace')
    lines = text.splitlines()
    if start and lines:
        lines = lines[1:]
    return lines[-line_limit:], os.path.basename(path)

def _journal_log_lines(line_limit):
    command = ['journalctl', '--no-pager', '-o', 'short-iso-precise', '-n', str(line_limit)]
    for unit in LOG_JOURNAL_UNITS:
        command.extend(['-u', unit])
    try:
        result = subprocess.run(
            command, capture_output=True, text=True, errors='replace',
            timeout=5, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.warning('Log journal read failed: %s', type(exc).__name__)
        return ['Не удалось прочитать системный журнал.'], 'journalctl'
    lines = result.stdout.splitlines()
    if result.returncode != 0:
        lines.append('journalctl завершился с ошибкой чтения.')
    return lines[-line_limit:], 'systemd journal'

def read_sstp_logs(source, line_limit):
    try:
        limit = max(50, min(500, int(line_limit)))
    except (TypeError, ValueError):
        limit = 250
    if source == 'connections':
        lines, origin = _tail_log_file('/var/log/sstp-accel/auth-fail.log', limit // 2)
        service_lines, _ = _tail_log_file('/var/log/sstp-accel/accel.log', limit)
        lines += service_lines
        origin = 'auth-fail.log / accel.log'
    elif source == 'server':
        lines, origin = _tail_log_file('/var/log/sstp-accel/accel.log', limit)
    elif source == 'services':
        lines, origin = _journal_log_lines(limit)
    else:
        raise ValueError('unknown log source')
    return {
        'source': source,
        'source_label': LOG_SOURCE_LABELS[source],
        'origin': origin,
        'lines': [_redact_log_line(line) for line in lines],
        'updated_at': datetime.now().astimezone().isoformat(timespec='seconds'),
    }

LOGIN_TPL = '''
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SSTP Manager — вход администратора</title>
<style>body{font-family:sans-serif;background:#1a1a2e;color:#e0e0e0;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.box{box-sizing:border-box;background:#16213e;padding:40px;border-radius:10px;text-align:center;width:min(400px,calc(100% - 24px));min-width:0}
input{padding:10px;margin:8px;border:1px solid #444;border-radius:5px;background:#0f3460;color:#fff;font-size:16px;width:200px}
button{padding:10px 30px;background:#e94560;color:#fff;border:none;border-radius:5px;cursor:pointer;font-size:16px;margin-top:10px}
.flash{color:#e94560}
.captcha{background:#0f3460;border:1px solid #444;border-radius:5px;padding:10px 20px;display:inline-block;font-size:20px;font-weight:bold;color:#7dd3fc;letter-spacing:3px;margin:10px 0;user-select:none}
.captcha-label{color:#64748b;font-size:12px;margin-top:5px}
@media(max-width:440px){.box{padding:30px 20px}.box h2{font-size:22px;line-height:1.25}input{max-width:100%}}
</style></head>
<body><div class="box"><h2>SSTP Manager — вход администратора</h2>
{% for m in get_flashed_messages() %}<p class="flash">{{m}}</p>{% endfor %}
<form method="post">
<input type="password" name="password" placeholder="Пароль" autofocus>
<input type="text" name="website" style="position:fixed;width:1px;height:1px;opacity:0;pointer-events:none" tabindex="-1" autocomplete="off" aria-hidden="true">
<br>
<div class="captcha">{{a}} + {{b}} = ?</div>
<div class="captcha-label">Решите пример для входа</div>
<input type="number" name="captcha" placeholder="Ответ" style="width:100px"><br>
<button type="submit">Войти</button>
</form></div></body></html>
'''

LOGS_TPL = '''
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SSTP Manager — журналы SSTP</title>
<style>
:root{color-scheme:dark;--bg:#08111d;--surface:#0d1825;--surface-2:#122033;--border:#27374a;--border-soft:#1b2a3b;--text:#edf4fc;--muted:#8191a7;--brand:#ff5e68;--green:#48d477;--cyan:#38c9ff;--blue:#1686d9;--amber:#e99a19;--red:#f04f5f}
*{box-sizing:border-box}html,body{min-height:100%}body{margin:0;background:radial-gradient(circle at 50% -30%,#142439 0,transparent 44%),linear-gradient(180deg,var(--bg),#060d16);color:var(--text);font-family:Inter,Manrope,"Segoe UI",system-ui,-apple-system,sans-serif;font-size:14px;line-height:1.45}
button,input,select{font:inherit}.top{min-height:72px;padding:12px clamp(20px,3vw,48px);display:flex;align-items:center;justify-content:space-between;gap:18px;border-bottom:1px solid var(--border-soft);background:rgba(8,17,29,.9);position:sticky;top:0;z-index:10}.brand{margin:0;color:var(--brand);font-size:24px;font-weight:800;letter-spacing:.055em}.top-actions,.toolbar,.tabs{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.page{width:min(1440px,calc(100% - 48px));margin:0 auto;padding:26px 0 34px}.title-row{display:flex;align-items:end;justify-content:space-between;gap:20px;margin-bottom:18px}.title-row h2{margin:0 0 5px;font-size:26px}.hint,.status{margin:0;color:var(--muted);font-size:13px}
.btn{min-height:36px;padding:8px 14px;display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid #17699f;border-radius:7px;background:transparent;color:var(--cyan);font-weight:700;text-decoration:none;cursor:pointer}.btn:hover,.btn.active{background:rgba(22,134,217,.16);border-color:var(--cyan)}.btn.active{color:#fff}.btn svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.btn-logout{border-color:#933442;color:var(--brand)}.btn-refresh{background:#125f99;color:#fff}.btn-refresh:hover{background:#1978bb}
.panel{border:1px solid var(--border);border-radius:11px;background:rgba(13,24,37,.96);box-shadow:0 20px 55px rgba(0,0,0,.28);overflow:hidden}.controls{padding:14px 16px;display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap;border-bottom:1px solid var(--border);background:var(--surface-2)}.toolbar input,.toolbar select{height:38px;border:1px solid var(--border);border-radius:7px;background:#0a1623;color:var(--text);padding:0 11px}.toolbar input{width:min(280px,70vw)}.toolbar select{width:120px}.auto{display:inline-flex;align-items:center;gap:7px;color:var(--muted);cursor:pointer}.auto input{width:17px;height:17px;accent-color:var(--green)}
.log-meta{min-height:42px;padding:10px 16px;display:flex;align-items:center;justify-content:space-between;gap:12px;border-bottom:1px solid var(--border-soft);color:var(--muted);font-size:12px}.live{color:var(--green)}.error{color:#ff9ca7}.log-wrap{height:calc(100vh - 285px);min-height:430px;overflow:auto;scrollbar-color:#607086 #111d2b;scrollbar-width:thin}.log{min-height:100%;margin:0;padding:16px 18px;color:#d9e6f5;background:#07111b;font:12.5px/1.55 ui-monospace,SFMono-Regular,Consolas,"Liberation Mono",monospace;white-space:pre-wrap;overflow-wrap:anywhere;tab-size:2}.empty{color:var(--muted)}
@media(max-width:720px){.top{align-items:flex-start}.brand{font-size:20px;margin-top:7px}.page{width:calc(100% - 22px);padding-top:18px}.title-row{display:block}.title-row h2{font-size:23px}.tabs{margin-top:14px}.tabs .btn{flex:1}.controls{align-items:flex-start}.toolbar{width:100%}.toolbar input{width:100%}.log-wrap{height:calc(100vh - 390px);min-height:360px}}
</style></head><body>
<header class="top"><h1 class="brand">SSTP MANAGER</h1><div class="top-actions"><a href="/" class="btn"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>К панели</a><a href="/logout" class="btn btn-logout">Выйти</a></div></header>
<main class="page"><div class="title-row"><div><h2>Журналы SSTP</h2><p class="hint">Только __VPN_DOMAIN__:__SSTP_PORT__. Страница доступна после входа администратора.</p></div><div class="tabs" role="tablist" aria-label="Источник журнала"><button class="btn active" type="button" data-source="connections">Подключения</button><button class="btn" type="button" data-source="server">Сервер</button><button class="btn" type="button" data-source="services">Службы</button></div></div>
<section class="panel" aria-label="Журнал SSTP"><div class="controls"><div class="toolbar"><input id="log-filter" type="search" placeholder="Фильтр: пользователь, IP, ошибка…" autocomplete="off"><select id="line-limit" aria-label="Количество строк"><option value="100">100 строк</option><option value="250" selected>250 строк</option><option value="500">500 строк</option></select></div><div class="toolbar"><label class="auto"><input id="auto-refresh" type="checkbox" checked>Автообновление 3 с</label><button id="refresh" class="btn btn-refresh" type="button">Обновить</button></div></div>
<div class="log-meta"><span id="log-state" class="live">● подключение к журналу</span><span id="log-origin">загрузка…</span></div><div id="log-wrap" class="log-wrap"><pre id="log-output" class="log" aria-live="polite">Загрузка журнала…</pre></div></section></main>
<script>
var source="connections", rawLines=[], loading=false;
var output=document.getElementById("log-output"), state=document.getElementById("log-state"), origin=document.getElementById("log-origin"), wrap=document.getElementById("log-wrap"), filter=document.getElementById("log-filter"), limit=document.getElementById("line-limit"), auto=document.getElementById("auto-refresh");
function render(){var q=filter.value.trim().toLocaleLowerCase("ru");var lines=q?rawLines.filter(function(line){return String(line).toLocaleLowerCase("ru").includes(q)}):rawLines;output.textContent=lines.length?lines.join("\\n"):(q?"По фильтру ничего не найдено.":"В журнале пока нет записей.");output.classList.toggle("empty",!lines.length)}
async function loadLogs(scrollToEnd){if(loading)return;loading=true;state.className="live";state.textContent="● обновление…";try{var response=await fetch("/api/logs?source="+encodeURIComponent(source)+"&lines="+encodeURIComponent(limit.value),{cache:"no-store",headers:{"Accept":"application/json"}});var data=await response.json();if(!response.ok||!data.success)throw new Error(data.error||"Ошибка загрузки");rawLines=Array.isArray(data.lines)?data.lines:[];render();origin.textContent=data.source_label+" · "+data.origin+" · "+new Date(data.updated_at).toLocaleTimeString();state.className="live";state.textContent="● в реальном времени";if(scrollToEnd)wrap.scrollTop=wrap.scrollHeight}catch(error){state.className="error";state.textContent="● журнал временно недоступен";origin.textContent=error.message||"Ошибка загрузки"}finally{loading=false}}
document.querySelectorAll("[data-source]").forEach(function(button){button.addEventListener("click",function(){document.querySelectorAll("[data-source]").forEach(function(item){item.classList.remove("active")});button.classList.add("active");source=button.dataset.source;rawLines=[];render();loadLogs(true)})});
document.getElementById("refresh").addEventListener("click",function(){loadLogs(false)});filter.addEventListener("input",render);limit.addEventListener("change",function(){loadLogs(true)});setInterval(function(){if(auto.checked&&!document.hidden)loadLogs(false)},3000);loadLogs(true);
</script></body></html>
'''

INDEX_TPL = '''
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SSTP Manager — панель управления</title>
<style>
:root{color-scheme:dark;--bg:#08111d;--bg-deep:#060d16;--surface:#0d1825;--surface-2:#122033;--surface-hover:#16263a;--border:#27374a;--border-soft:#1b2a3b;--text:#edf4fc;--muted:#8191a7;--brand:#ff5e68;--green:#48d477;--cyan:#38c9ff;--blue:#1686d9;--blue-hover:#2799ec;--amber:#e99a19;--red:#f04f5f;--red-hover:#ff6574;--radius:10px;--shadow:0 20px 55px rgba(0,0,0,.28)}
*{box-sizing:border-box}html,body{min-height:100%}
body{margin:0;background:radial-gradient(circle at 50% -30%,#142439 0,transparent 44%),linear-gradient(180deg,var(--bg) 0,var(--bg-deep) 100%);color:var(--text);font-family:Inter,Manrope,"Segoe UI",system-ui,-apple-system,sans-serif;font-size:14px;line-height:1.45}
button,input,select{font:inherit}button,a,input,select{outline:none}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible{box-shadow:0 0 0 3px rgba(56,201,255,.22)}
.top{height:72px;padding:0 clamp(24px,3vw,48px);display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border-soft);background:rgba(8,17,29,.86);backdrop-filter:blur(18px);position:sticky;top:0;z-index:20}
.brand{margin:0;color:var(--brand);font-size:24px;font-weight:800;letter-spacing:.055em;line-height:1}.top-actions{display:flex;align-items:center;gap:12px}.top-actions form{display:inline-flex;margin:0}
.page{width:min(1440px,calc(100% - 64px));margin:0 auto;padding:24px 0 34px}.add-toolbar{display:flex;align-items:center;margin:0 0 18px}.add-toolbar form{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
input,select{width:230px;height:42px;margin:0;padding:0 14px;color:var(--text);background:#0e1b2a;border:1px solid var(--border);border-radius:7px;transition:border-color .18s ease,background .18s ease,box-shadow .18s ease}input::placeholder{color:#71839b}input:hover,select:hover{border-color:#3a506a}input:focus,select:focus{border-color:var(--cyan);background:#102032}
.btn{min-height:34px;padding:7px 15px;display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;border-radius:6px;background:var(--blue);color:#fff;font-size:13px;font-weight:700;line-height:1;text-decoration:none;cursor:pointer;white-space:nowrap;transition:background .18s ease,border-color .18s ease,transform .18s ease,box-shadow .18s ease}.btn:hover{background:var(--blue-hover);transform:translateY(-1px)}.btn:active{transform:translateY(0)}
.btn svg{width:16px;height:16px;display:block;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.btn-outline{background:transparent;border-color:#17699f;color:var(--cyan)}.btn-outline:hover{background:rgba(22,134,217,.13);border-color:var(--cyan)}
.btn-add{height:42px;min-width:68px;padding:0 19px;background:#45bd67;font-size:14px}.btn-add:hover{background:#55ce77}.btn-suggest{height:42px;padding:0 12px;background:transparent;border-color:#17699f;color:var(--cyan)}.btn-suggest:hover{background:rgba(22,134,217,.13);border-color:var(--cyan)}.btn-reset,.btn-user-reset{background:transparent;border-color:#9a620e;color:#f3a51f}.btn-reset:hover,.btn-user-reset:hover{background:rgba(233,154,25,.12);border-color:var(--amber)}.btn-logout{background:transparent;border-color:#933442;color:var(--brand)}.btn-logout:hover{background:rgba(240,79,95,.1);border-color:var(--red-hover)}.btn-kick{background:#0d5f9e}.btn-kick:hover{background:#1677bf}.btn-del{background:var(--red)}.btn-del:hover{background:var(--red-hover)}.btn-ip-ready{background:#168f4d;border-color:var(--green);color:#fff;box-shadow:0 0 0 2px rgba(72,212,119,.14)}.btn-ip-ready:hover{background:#20a65c;border-color:#71e497}
.section-head{margin-bottom:16px}.section-head h2{margin:0 0 7px;font-size:25px;line-height:1.2;letter-spacing:-.02em}.month-info{margin:2px 0;color:var(--muted);font-size:13px}.live-row{display:flex;align-items:center;gap:6px;margin-top:7px}
.on{color:var(--green)}.off{color:#7a8798}.stale{color:#f4b63f}.ip{color:var(--cyan);font-weight:600;text-decoration:none}.ip:hover{text-decoration:underline}.session-count{color:var(--muted);font-size:12px}.ip-list{line-height:1.45}
.panel-notifications{min-width:0;flex:1;display:flex;align-items:center;justify-content:flex-end;gap:8px;margin-left:18px}.panel-notice{display:block;max-width:min(720px,100%);padding:6px 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:1px solid var(--border);border-radius:6px;background:rgba(13,24,37,.78);font-size:12px;font-weight:650;transition:opacity .25s ease,transform .25s ease,max-width .25s ease,padding .25s ease,border-width .25s ease}.panel-notice[hidden]{display:none}.panel-notice-success{color:#7de39b;border-color:rgba(72,212,119,.35)}.panel-notice-error{color:#ff9ca7;border-color:rgba(240,79,95,.4)}.panel-notice-info{color:#82dafb;border-color:rgba(56,201,255,.35)}.panel-notice-hiding{max-width:0;padding-left:0;padding-right:0;overflow:hidden;opacity:0;transform:translateX(5px);border-left-width:0;border-right-width:0}
.table-card{overflow:hidden;border:1px solid var(--border);border-radius:var(--radius);background:rgba(13,24,37,.94);box-shadow:var(--shadow)}.table-wrap{max-height:calc(100vh - 350px);min-height:390px;overflow:auto;scrollbar-color:#607086 #111d2b;scrollbar-width:thin}.table-wrap::-webkit-scrollbar{width:10px;height:10px}.table-wrap::-webkit-scrollbar-track{background:#111d2b}.table-wrap::-webkit-scrollbar-thumb{background:#5b697c;border:2px solid #111d2b;border-radius:99px}.ip-editor{display:flex;gap:6px;align-items:center}.ip-editor input{width:142px;height:34px;padding:0 9px}.ip-editor .btn{padding:7px 10px}.ready{color:var(--green);font-size:12px}.pending{color:#f4b63f;font-size:12px}.subsection{margin-top:28px}.subsection h2{margin:0 0 12px;font-size:21px}.forward-form{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px}.forward-form input,.forward-form select{width:170px}.forward-form input[name=label]{width:220px}.forward-table .table-wrap{min-height:0;max-height:min(58vh,560px)}.compact-table .table-wrap{min-height:0;max-height:330px}.forward-table table{min-width:1180px}.compact-table table{min-width:720px}.pf-diagnostic{display:block;max-width:330px;color:var(--muted);font-size:12px;line-height:1.35;white-space:normal}.pf-diagnostic.pf-ok{color:#7de39b}.pf-diagnostic.pf-warning{color:#f4b63f}.pf-diagnostic.pf-idle{color:var(--muted)}.pf-check{margin-right:8px}.hint{color:var(--muted);font-size:12px;margin:7px 0 14px}.network-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.network-card{padding:18px;border:1px solid var(--border);border-radius:var(--radius);background:rgba(13,24,37,.94)}.network-card h3{margin:0 0 6px;font-size:17px}.network-card.full{grid-column:1/-1}.network-form{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap}.network-form .field{display:grid;gap:6px}.network-form .field span{color:var(--muted);font-size:12px}.network-form input,.network-form select{width:190px}.toggle{min-height:42px;display:inline-flex;align-items:center;gap:9px;padding:0 10px;color:var(--text);cursor:pointer}.toggle input{width:18px;height:18px;margin:0;accent-color:var(--green)}.network-summary{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 14px}.badge{padding:5px 9px;border:1px solid var(--border);border-radius:99px;color:var(--muted);font-size:12px}.badge.on-badge{color:#7de39b;border-color:rgba(72,212,119,.35)}
.cascade-card{margin-top:18px;padding:17px 18px;display:grid;grid-template-columns:minmax(300px,1fr) auto;gap:14px 24px;align-items:center;border:1px solid var(--border);border-radius:var(--radius);background:linear-gradient(135deg,rgba(18,32,51,.96),rgba(13,24,37,.96));box-shadow:0 14px 36px rgba(0,0,0,.2)}.cascade-copy h2{margin:0 0 5px;font-size:19px}.cascade-copy p{margin:0;color:var(--muted);font-size:12px}.cascade-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:9px}.cascade-state{padding:5px 9px;border:1px solid rgba(244,182,63,.35);border-radius:99px;color:#f4b63f;font-size:12px}.cascade-state.ok{color:#7de39b;border-color:rgba(72,212,119,.35)}.cascade-state.error{color:#ff9ca7;border-color:rgba(240,79,95,.4)}.cascade-mode-badge.on-badge{color:#7de39b;border-color:rgba(72,212,119,.35)}.cascade-actions{display:flex;align-items:flex-end;justify-content:flex-end;gap:10px;flex-wrap:wrap}.cascade-mode-form{display:flex;margin:0}.cascade-mode-button{height:42px;min-width:154px;background:#45bd67}.cascade-mode-button:hover{background:#55ce77}.cascade-mode-button.enabled{background:transparent;border-color:#933442;color:#ff7b87}.cascade-mode-button.enabled:hover{background:rgba(240,79,95,.1);border-color:var(--red-hover)}.cascade-form{display:flex;align-items:flex-end;gap:10px}.cascade-form .field{display:grid;gap:6px}.cascade-form .field span{color:var(--muted);font-size:12px}.cascade-form input{width:205px}.cascade-note{grid-column:1/-1;margin:0;padding-top:11px;border-top:1px solid var(--border-soft);color:var(--muted);font-size:12px}.cascade-note strong{color:#cfd9e7}.cascade-progress-box{grid-column:1/-1;padding:12px 14px;border:1px solid var(--border-soft);border-radius:8px;background:rgba(6,15,25,.46);transition:border-color .2s ease,background .2s ease}.cascade-progress-box.active{border-color:rgba(56,201,255,.38);background:rgba(10,29,44,.72)}.cascade-progress-box.success{border-color:rgba(72,212,119,.34)}.cascade-progress-box.error{border-color:rgba(240,79,95,.42);background:rgba(49,17,25,.32)}.cascade-progress-head,.cascade-progress-meta{display:flex;align-items:center;justify-content:space-between;gap:12px}.cascade-progress-title{color:#dce9f7;font-size:13px;font-weight:750}.cascade-progress-box.active .cascade-progress-title{color:#82dafb}.cascade-progress-box.success .cascade-progress-title{color:#7de39b}.cascade-progress-box.error .cascade-progress-title{color:#ff9ca7}.cascade-progress-counter,.cascade-progress-time{color:var(--muted);font-size:11px;white-space:nowrap}.cascade-progress-track{height:6px;margin:9px 0 8px;overflow:hidden;border-radius:99px;background:#17263a}.cascade-progress-fill{width:0;height:100%;border-radius:inherit;background:linear-gradient(90deg,#1686d9,#38c9ff);transition:width .45s ease}.cascade-progress-box.active .cascade-progress-fill{background:linear-gradient(90deg,#1686d9,#48d4ff);box-shadow:0 0 12px rgba(56,201,255,.24)}.cascade-progress-box.success .cascade-progress-fill{background:#48d477}.cascade-progress-box.error .cascade-progress-fill{background:#f04f5f}.cascade-progress-message{margin:0;color:#a9b8ca;font-size:12px}.cascade-steps{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:6px;margin:11px 0 0;padding:0;list-style:none}.cascade-step{min-width:0;padding:6px 7px;border:1px solid var(--border-soft);border-radius:6px;color:#66768a;background:rgba(8,17,29,.52);font-size:10px;line-height:1.2;text-align:center}.cascade-step.done{color:#86d99e;border-color:rgba(72,212,119,.24)}.cascade-step.active{color:#9be4ff;border-color:rgba(56,201,255,.45);background:rgba(22,134,217,.12)}.cascade-step.error{color:#ff9ca7;border-color:rgba(240,79,95,.42)}.cascade-button[disabled],.cascade-mode-button[disabled]{opacity:.65;cursor:wait;transform:none}
.cascade-steps[hidden]{display:none}
section[aria-labelledby="users-heading"] table{display:block;min-width:1360px}
section[aria-labelledby="users-heading"] thead,section[aria-labelledby="users-heading"] tbody{display:block}
section[aria-labelledby="users-heading"] tr{display:grid;grid-template-columns:180px 120px 240px 160px 115px 115px 115px minmax(315px,1fr)}
section[aria-labelledby="users-heading"] thead{position:sticky;top:0;z-index:3}
section[aria-labelledby="users-heading"] th{position:static;display:flex;align-items:center}
section[aria-labelledby="users-heading"] td{display:flex;align-items:center;height:auto;min-height:55px;border-bottom:0}
section[aria-labelledby="users-heading"] td.ip-list{flex-direction:column;align-items:flex-start;justify-content:center}
section[aria-labelledby="users-heading"] tbody tr{box-shadow:inset 0 -1px var(--border-soft)}
section[aria-labelledby="users-heading"] tbody tr:last-child{box-shadow:none}
table{width:100%;min-width:1010px;border-collapse:separate;border-spacing:0;font-variant-numeric:tabular-nums}th,td{height:47px;padding:10px 24px;text-align:left;border-bottom:1px solid var(--border-soft);white-space:nowrap}th{height:50px;position:sticky;top:0;z-index:3;background:#17253a;color:#f4f7fb;font-size:13px;font-weight:750;letter-spacing:.005em;box-shadow:0 1px 0 var(--border)}tbody tr{transition:background .16s ease}tbody tr:hover{background:var(--surface-hover)}tbody tr:last-child td{border-bottom:0}td{color:#e7eef8;font-weight:500}td:nth-child(4),td:nth-child(5),td:nth-child(6){font-variant-numeric:tabular-nums}td:last-child{vertical-align:middle}td:last-child form{display:inline-flex;margin:0}td:last-child form+form{margin-left:8px}
.total{min-height:50px;padding:8px 24px;display:flex;align-items:center;justify-content:space-between;gap:16px;border-top:1px solid var(--border);background:#132033;color:#ced9e7;font-size:13px;font-weight:650;font-variant-numeric:tabular-nums}.total #month-total{flex:0 0 auto;white-space:nowrap}
@media(max-width:820px){.top{height:auto;min-height:68px;padding:14px 18px;align-items:flex-start;gap:14px}.brand{font-size:20px;margin-top:8px}.top-actions{justify-content:flex-end;flex-wrap:wrap;gap:8px}.top-actions .btn{padding:7px 10px}.page{width:calc(100% - 28px);padding-top:18px}.add-toolbar form{width:100%}.add-toolbar input{width:calc(50% - 45px);min-width:150px}.section-head h2{font-size:22px}.table-wrap{max-height:64vh;min-height:420px}th,td{padding:9px 16px}.cascade-card{grid-template-columns:1fr}.cascade-actions,.cascade-form{justify-content:flex-start}.cascade-note{grid-column:auto}.network-grid{grid-template-columns:1fr}.network-card.full{grid-column:auto}.network-form .field,.network-form input,.network-form select{width:100%}.panel-notice{max-width:430px}}
@media(max-width:560px){.top{display:block}.brand{margin:0 0 14px}.top-actions{justify-content:flex-start}.top-actions .btn svg{display:none}.add-toolbar input{width:100%}.btn-add{width:100%}.page{width:calc(100% - 20px)}.section-head{margin-top:4px}.month-info{font-size:12px}.table-card{border-radius:8px}.cascade-actions,.cascade-form{align-items:stretch;flex-direction:column}.cascade-mode-form,.cascade-mode-button,.cascade-form .field,.cascade-form input,.cascade-form .btn{width:100%}.cascade-progress-head,.cascade-progress-meta{align-items:flex-start}.cascade-steps{grid-template-columns:repeat(2,minmax(0,1fr))}.total{align-items:stretch;flex-direction:column;overflow:hidden}.panel-notifications{order:-1;width:100%;margin-left:0;justify-content:flex-start}.panel-notice{max-width:100%}.total #month-total{overflow-x:auto}}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;transition:none!important}}
</style></head><body>
<header class="top"><h1 class="brand">SSTP MANAGER</h1><div class="top-actions"><form method="post" action="/traffic/reset-view" onsubmit="return confirm('Сбросить только отображаемые значения трафика в этой таблице? Счётчики VPN не будут обнулены.')"><input type="hidden" name="csrf" value="{{csrf_token}}"><button type="submit" class="btn btn-reset" aria-label="Сбросить отсчёт трафика"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.34 5.66M20 4v7h-7"/></svg>Сбросить отсчёт</button></form><a href="/logs" target="_blank" rel="noopener" class="btn btn-outline" aria-label="Открыть журналы SSTP"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h9l3 3v15H6zM15 3v4h4M9 11h6M9 15h6M9 19h4"/></svg>Логи</a><a href="/backup" class="btn btn-outline"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 20h14"/></svg>Резервная копия</a><a href="/logout" class="btn btn-logout"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 5H5v14h5m4-4 4-4-4-4m4 4H9"/></svg>Выйти</a></div></header>
<main class="page"><div class="add-toolbar"><form method="post" action="/add"><input type="hidden" name="csrf" value="{{csrf_token}}"><input name="username" placeholder="Имя пользователя" autocomplete="off" required><input name="password" type="password" placeholder="Пароль" autocomplete="new-password" required><input id="new-user-ip" name="ip" value="{{suggested_ip}}" placeholder="Свободных IP нет" inputmode="decimal" required><button id="suggest-ip" type="button" class="btn btn-suggest" title="Подставить первый свободный IP">Свободный IP</button><button type="submit" class="btn btn-add">Добавить</button></form></div>
<section aria-labelledby="users-heading"><div class="section-head"><h2 id="users-heading">Пользователи (<span id="user-count">{% if user_count_label is not none %}{{user_count_label}}{% else %}{{users|length}}{% endif %}</span>)</h2>
<div class="month-info">Период учёта трафика: {{month}} &middot; сброс 1-го числа каждого месяца</div><div class="month-info" id="traffic-note"{% if not traffic_note %} hidden{% endif %}>{{traffic_note}}</div>
<div class="month-info live-row"><span id="collector-state" class="{% if status_error %}stale{% else %}on{% endif %}">{% if status_error %}&#9679; данные устарели{% else %}&#9679; в реальном времени{% endif %}</span><span>&middot; обновлено <span id="last-update">{{collected_at or 'ещё нет'}}</span> &middot; обновление каждые 2 с</span></div></div>
<div class="table-card"><div class="table-wrap"><table><thead><tr><th>Имя пользователя</th><th>Статус</th><th>Постоянный IP</th><th>Текущий IP</th><th>Трафик &#8595;</th><th>Трафик &#8593;</th><th>Всего</th><th>Действия</th></tr></thead><tbody id="user-tbody">
{% for u in users %}
<tr data-user="{{u.name}}"><td>{{u.name}}</td>
<td>{% if u.online %}<span class="on">&#9679; онлайн</span>{% if u.session_count > 1 %} <span class="session-count">(сеансов: {{u.session_count}})</span>{% endif %}{% else %}<span class="off">&#9679; офлайн</span>{% endif %}</td>
<td><form class="ip-editor" method="post" action="/ip"><input type="hidden" name="csrf" value="{{csrf_token}}"><input type="hidden" name="user" value="{{u.name}}"><input name="ip" value="{{u.desired_ip}}" placeholder="10.77.0.x" required><button type="submit" class="btn {% if u.ip_ready %}btn-ip-ready{% else %}btn-outline{% endif %}" aria-label="{% if u.ip_ready %}Постоянный IP применён{% else %}Сохранить постоянный IP{% endif %}">IP</button></form></td>
<td class="ip-list">{% if u.vpn_ips %}{% for ip in u.vpn_ips %}<a class="ip" href="http://{{ip}}" target="_blank" rel="noopener">{{ip}}</a>{% if not loop.last %}<br>{% endif %}{% endfor %}{% else %}&mdash;{% endif %}</td>

<td>{{u.dl}}</td><td>{{u.ul}}</td><td>{{u.total}}</td>
<td><form method="post" action="/kick"><input type="hidden" name="csrf" value="{{csrf_token}}"><input type="hidden" name="user" value="{{u.name}}"><button type="submit" class="btn btn-kick">Отключить</button></form>
<form method="post" action="/delete"><input type="hidden" name="csrf" value="{{csrf_token}}"><input type="hidden" name="user" value="{{u.name}}"><button type="submit" class="btn btn-del">Удалить</button></form>
<form method="post" action="/traffic/reset-user-view" onsubmit="return confirm('Сбросить только отображаемый трафик пользователя {{u.name}}? Счётчики VPN и месячный учёт не изменятся.')"><input type="hidden" name="csrf" value="{{csrf_token}}"><input type="hidden" name="user" value="{{u.name}}"><button type="submit" class="btn btn-user-reset" aria-label="Сбросить визуальный трафик пользователя {{u.name}}">Сбросить</button></form></td></tr>
{% endfor %}
</tbody></table></div><div class="total"><span id="month-total">Итог за месяц: &#8595; {{total_dl}} &middot; &#8593; {{total_ul}} &middot; &Sigma; {{total_all}}</span><div id="panel-notifications" class="panel-notifications" aria-live="polite" aria-atomic="true">{% for category, m in get_flashed_messages(with_categories=true) %}<span class="panel-notice panel-notice-{{category}}" data-flash-category="{{category}}" title="{{m}}"{% if category == 'success' %} role="status"{% else %} role="alert"{% endif %}>{{m}}</span>{% endfor %}<span id="status-error" class="panel-notice panel-notice-error"{% if not status_error %} hidden{% endif %}>{{status_error}}</span></div></div></div></section>
<section class="cascade-card" aria-labelledby="cascade-heading"><div class="cascade-copy"><h2 id="cascade-heading">Выход SSTP-каскада</h2><p>Включайте готовый каскад одной кнопкой или укажите IP нового Ubuntu/Debian VPS.</p><div class="cascade-meta"><span id="cascade-mode-badge" class="badge cascade-mode-badge{% if cascade_exit.enabled %} on-badge{% endif %}">Каскад: {% if cascade_exit.enabled %}включён{% else %}выключен{% endif %}</span><span class="badge">Настроенный exit: <strong id="cascade-current-ip">{{cascade_exit.exit_ip or 'н/д'}}</strong></span><span id="cascade-port" class="badge">UDP {% if cascade_exit.port %}{{cascade_exit.port}}{% else %}авто{% endif %}</span><span id="cascade-health" class="cascade-state {% if cascade_exit.enabled and cascade_exit.healthy %}ok{% endif %}">{% if not cascade_exit.enabled %}&#9679; прямой выход{% if cascade_exit.direct_ip %} · {{cascade_exit.direct_ip}}{% endif %}{% elif cascade_exit.healthy %}&#9679; каскад работает · {{cascade_exit.handshake_label}}{% elif cascade_exit.exit_ip %}&#9679; нет свежего handshake · {{cascade_exit.handshake_label}}{% else %}&#9679; exit ещё не настроен{% endif %}</span></div></div><div class="cascade-actions"><form id="cascade-mode-form" class="cascade-mode-form" method="post" action="/cascade/mode" data-enabled="{{'true' if cascade_exit.enabled else 'false'}}"><input type="hidden" name="csrf" value="{{csrf_token}}"><input id="cascade-mode-value" type="hidden" name="mode" value="{{'off' if cascade_exit.enabled else 'on'}}"><button id="cascade-mode-button" type="submit" class="btn cascade-mode-button{% if cascade_exit.enabled %} enabled{% endif %}"{% if cascade_exit.job.active %} disabled{% endif %}>{% if cascade_exit.job.active %}Переключаю…{% elif cascade_exit.enabled %}Выключить каскад{% else %}Включить каскад{% endif %}</button></form><form id="cascade-exit-form" class="cascade-form" method="post" action="/cascade/exit" data-current-ip="{{cascade_exit.exit_ip}}"><input type="hidden" name="csrf" value="{{csrf_token}}"><label class="field"><span>Новый публичный IPv4</span><input id="cascade-exit-ip" name="exit_ip" value="{{cascade_exit.exit_ip}}" placeholder="203.0.113.10" inputmode="decimal" autocomplete="off" required></label><button type="submit" class="btn btn-add cascade-button"{% if cascade_exit.job.active %} disabled{% endif %}>{% if cascade_exit.job.active %}Подготавливаю…{% else %}Подготовить и переключить{% endif %}</button></form></div><div id="cascade-progress-box" class="cascade-progress-box{% if cascade_exit.job.active %} active{% elif cascade_exit.job.stage == 'success' %} success{% elif cascade_exit.job.stage == 'error' %} error{% endif %}" aria-live="polite"><div class="cascade-progress-head"><span id="cascade-progress-title" class="cascade-progress-title">{% if cascade_exit.job.active %}Подготовка выполняется{% elif cascade_exit.job.stage == 'success' %}Готово{% elif cascade_exit.job.stage == 'error' %}Ошибка подготовки{% else %}Ожидание{% endif %}</span><span id="cascade-progress-counter" class="cascade-progress-counter"></span></div><div id="cascade-progress-track" class="cascade-progress-track" role="progressbar" aria-label="Подготовка выхода каскада" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="cascade-progress-fill" class="cascade-progress-fill"></div></div><div class="cascade-progress-meta"><p id="cascade-progress" class="cascade-progress-message">{% if cascade_exit.job.message %}{{cascade_exit.job.message}}{% else %}Введите IP нового сервера — здесь будут показаны все этапы подготовки.{% endif %}</p><span id="cascade-progress-time" class="cascade-progress-time"></span></div><ol id="cascade-steps" class="cascade-steps"{% if not cascade_exit.job.active and cascade_exit.job.stage not in ['success', 'error'] %} hidden{% endif %}><li class="cascade-step">Доступ SSH</li><li class="cascade-step">Подготовка VPS</li><li class="cascade-step">Туннель</li><li class="cascade-step">Handshake</li><li class="cascade-step">Проверка IP</li><li class="cascade-step">Завершение</li></ol></div><p class="cascade-note"><strong>«Выключить каскад»</strong> возвращает прямой выход через этот SSTP-сервер. <strong>«Включить каскад»</strong> поднимает уже настроенный туннель, проверяет handshake и реальный внешний IP; при ошибке автоматически сохраняется прямой рабочий выход.</p></section>
<section class="subsection" aria-labelledby="network-heading"><h2 id="network-heading">Сеть и доступ</h2><p class="hint">Настройки относятся только к SSTP на __VPN_DOMAIN__:__SSTP_PORT__. Пул задаёт доступные постоянные IP. Действующие подключения не перезапускаются.</p>
<div class="network-summary"><span class="badge">Сеть {{vpn_network}}</span><span class="badge">Шлюз {{vpn_gateway}}</span><span class="badge {% if network_settings.nat_enabled %}on-badge{% endif %}">NAT: {% if network_settings.nat_enabled %}включён{% else %}выключен{% endif %}</span></div>
<div class="network-grid">
<article class="network-card full"><h3>Пул адресов и интернет</h3><p class="hint">Постоянные IP пользователей должны оставаться внутри выбранного пула. Адрес 10.77.0.254 зарезервирован для автоматической первичной настройки новых клиентов. Если NAT выключен, клиентам доступны только явно разрешённые сети и маршруты.</p><form class="network-form" method="post" action="/settings/network"><input type="hidden" name="csrf" value="{{csrf_token}}"><label class="field"><span>Первый адрес</span><input name="pool_start" value="{{network_settings.pool_start}}" inputmode="decimal" required></label><label class="field"><span>Последний адрес</span><input name="pool_end" value="{{network_settings.pool_end}}" inputmode="decimal" required></label><label class="toggle"><input type="checkbox" name="nat_enabled" value="1"{% if network_settings.nat_enabled %} checked{% endif %}>Выход клиентов в интернет через NAT</label><button type="submit" class="btn btn-add">Сохранить</button></form></article>
<article class="network-card"><h3>Разрешённые сети</h3><p class="hint">Частные сети, к которым SSTP-клиенты могут обращаться даже при выключенном NAT.</p><form class="network-form" method="post" action="/access/add"><input type="hidden" name="csrf" value="{{csrf_token}}"><label class="field"><span>Название</span><input name="label" placeholder="Например, офис" maxlength="48" required></label><label class="field"><span>Подсеть</span><input name="cidr" placeholder="10.20.0.0/16" required></label><button type="submit" class="btn btn-add">Добавить</button></form></article>
<article class="network-card"><h3>Маршруты за Keenetic</h3><p class="hint">Сеть за выбранным роутером будет доступна через его постоянный SSTP-IP. На Keenetic должен быть разрешён доступ к домашней сети.</p><form class="network-form" method="post" action="/routes/add"><input type="hidden" name="csrf" value="{{csrf_token}}"><label class="field"><span>Название</span><input name="label" placeholder="Например, камеры" maxlength="48" required></label><label class="field"><span>Подсеть за роутером</span><input name="cidr" placeholder="192.168.1.0/24" required></label><label class="field"><span>Клиент</span><select name="user" required><option value="">Выберите</option>{% for username, ip in static_ips|dictsort %}<option value="{{username}}">{{username}} — {{ip}}</option>{% endfor %}</select></label><button type="submit" class="btn btn-add">Добавить</button></form></article>
<article class="network-card compact-table"><h3>Список разрешённых сетей</h3><div class="table-card"><div class="table-wrap"><table><thead><tr><th>Название</th><th>Подсеть</th><th>Действия</th></tr></thead><tbody>{% for item in access_networks %}<tr><td>{{item.label}}</td><td>{{item.cidr}}</td><td><form method="post" action="/access/delete"><input type="hidden" name="csrf" value="{{csrf_token}}"><input type="hidden" name="item_id" value="{{item.id}}"><button class="btn btn-del" type="submit">Удалить</button></form></td></tr>{% else %}<tr><td colspan="3" class="off">Разрешённых сетей пока нет</td></tr>{% endfor %}</tbody></table></div></div></article>
<article class="network-card compact-table"><h3>Список маршрутов</h3><div class="table-card"><div class="table-wrap"><table><thead><tr><th>Название</th><th>Подсеть</th><th>Через клиента</th><th>Действия</th></tr></thead><tbody>{% for item in routes %}<tr><td>{{item.label}}</td><td>{{item.cidr}}</td><td>{{item.user}} — {{item.next_hop}}</td><td><form method="post" action="/routes/delete"><input type="hidden" name="csrf" value="{{csrf_token}}"><input type="hidden" name="item_id" value="{{item.id}}"><button class="btn btn-del" type="submit">Удалить</button></form></td></tr>{% else %}<tr><td colspan="4" class="off">Маршрутов пока нет</td></tr>{% endfor %}</tbody></table></div></div></article>
</div></section>
<section class="subsection" aria-labelledby="forward-heading"><h2 id="forward-heading">Проброс портов</h2><p class="hint">Публичный порт на __PUBLIC_IP__ направляется только на выбранный постоянный IP SSTP-клиента. Служебные порты сервера защищены от выбора.</p>
<form class="forward-form" method="post" action="/forwards/add"><input type="hidden" name="csrf" value="{{csrf_token}}"><input name="label" placeholder="Название правила" maxlength="48" required><select name="protocol" required><option value="tcp">TCP</option><option value="udp">UDP</option></select><input id="new-public-port" name="public_port" type="number" min="1024" max="65535" value="{{suggested_port}}" placeholder="Свободных портов нет" required><button id="suggest-port" type="button" class="btn btn-suggest" title="Подставить следующий свободный внешний порт">Свободный порт</button><select name="user" required><option value="">Клиент</option>{% for username, ip in static_ips|dictsort %}<option value="{{username}}">{{username}} — {{ip}}</option>{% endfor %}</select><input name="target_port" type="number" min="1" max="65535" placeholder="Порт клиента" required><button type="submit" class="btn btn-add">Добавить правило</button></form>
<div class="table-card forward-table"><div class="table-wrap"><table><thead><tr><th>Название</th><th>Протокол</th><th>Снаружи</th><th>Клиент</th><th>Назначение</th><th>Диагностика</th><th>Действия</th></tr></thead><tbody>{% for rule in port_forwards %}<tr><td>{{rule.label}}</td><td>{{rule.protocol|upper}}</td><td>__PUBLIC_IP__:{{rule.public_port}}</td><td>{{rule.user}}</td><td>{{rule.target_ip}}:{{rule.target_port}}</td><td><span id="pf-state-{{rule.id}}" class="pf-diagnostic pf-idle">Нажмите «Проверить»</span></td><td><button class="btn btn-outline pf-check" type="button" data-rule-id="{{rule.id}}">Проверить</button><form method="post" action="/forwards/delete"><input type="hidden" name="csrf" value="{{csrf_token}}"><input type="hidden" name="rule_id" value="{{rule.id}}"><button class="btn btn-del" type="submit">Удалить правило</button></form></td></tr>{% else %}<tr><td colspan="7" class="off">Правил пока нет</td></tr>{% endfor %}</tbody></table></div></div></section></main>
<script>
var csrf={{csrf_token|tojson}};
var busy=false;
function confirmCascadeExit(form){
  var input=form.querySelector('input[name="exit_ip"]');
  var current=(form.getAttribute('data-current-ip')||'').trim();
  var next=(input&&input.value||'').trim();
  if(next!==current&&!window.confirm('Подготовить '+next+' как новый выход SSTP? Панель покажет каждый этап. Прямой рабочий выход сохранится до завершения всех проверок.'))return false;
  return true;
}
var cascadeExitForm=document.getElementById('cascade-exit-form');
var cascadePollTimer=null;
var cascadePollBusy=false;
var cascadeLocalErrorUntil=0;
var cascadeStageMap={
  queued:{step:1,progress:5,title:'Запуск подготовки'},
  checking_ssh:{step:1,progress:15,title:'Проверка доступа по SSH'},
  installing:{step:2,progress:35,title:'Подготовка нового VPS'},
  configuring_tunnel:{step:3,progress:56,title:'Настройка защищённого туннеля'},
  checking_handshake:{step:4,progress:72,title:'Проверка handshake'},
  checking_egress:{step:5,progress:88,title:'Переключение и проверка внешнего IP'},
  cleaning_previous:{step:6,progress:96,title:'Завершение и очистка'},
  switching_mode:{step:0,progress:55,title:'Переключение режима каскада'},
  success:{step:6,progress:100,title:'Готово'},
  idle:{step:0,progress:0,title:'Ожидание'}
};
function formatCascadeDuration(seconds){
  seconds=Math.max(0,Math.floor(seconds||0));
  if(seconds<60)return seconds+' сек.';
  var minutes=Math.floor(seconds/60),rest=seconds%60;
  return minutes+' мин. '+String(rest).padStart(2,'0')+' сек.';
}
function renderCascadeProgress(job){
  job=job||{};
  var box=document.getElementById('cascade-progress-box');
  var title=document.getElementById('cascade-progress-title');
  var counter=document.getElementById('cascade-progress-counter');
  var track=document.getElementById('cascade-progress-track');
  var fill=document.getElementById('cascade-progress-fill');
  var message=document.getElementById('cascade-progress');
  var elapsed=document.getElementById('cascade-progress-time');
  var steps=document.getElementById('cascade-steps');
  if(!box||!title||!counter||!track||!fill||!message||!elapsed||!steps)return;
  var stage=job.stage||'idle';
  var failedStage=job.failed_stage||'';
  var meta=cascadeStageMap[stage]||cascadeStageMap.idle;
  if(stage==='error')meta=cascadeStageMap[failedStage]||{step:0,progress:0,title:'Ошибка подготовки'};
  var isProvision=Boolean(job.requested_ip)||['queued','checking_ssh','installing','configuring_tunnel','checking_handshake','checking_egress','cleaning_previous'].includes(stage);
  var active=job.active===true;
  var success=stage==='success';
  var error=stage==='error';
  box.classList.toggle('active',active);
  box.classList.toggle('success',success);
  box.classList.toggle('error',error);
  title.textContent=error?'Ошибка подготовки':meta.title;
  var progress=Math.max(0,Math.min(100,Number(meta.progress)||0));
  fill.style.width=progress+'%';
  track.setAttribute('aria-valuenow',String(progress));
  if(isProvision){
    counter.textContent=error?(meta.step?'Остановлено на шаге '+meta.step+' из 6':'Остановлено'):(success?'6 из 6 · 100%':'Шаг '+Math.max(1,meta.step)+' из 6 · '+progress+'%');
  }else{
    counter.textContent=active?progress+'%':'';
  }
  message.textContent=job.message||(stage==='idle'?'Введите IP нового сервера — здесь будут показаны все этапы подготовки.':'Статус обновляется…');
  var started=Number(job.started_at)||0;
  var finished=Number(job.finished_at)||0;
  elapsed.textContent=started?'Прошло: '+formatCascadeDuration((finished||Date.now()/1000)-started):'';
  steps.hidden=!isProvision;
  var history=document.getElementById('cascade-history');
  if(!history){history=document.createElement('ol');history.id='cascade-history';history.style.cssText='font-size:12px;line-height:1.7;max-height:180px;overflow:auto;padding-left:24px;margin-top:12px';steps.parentNode.appendChild(history)}
  var entries=Array.isArray(job.history)?job.history.slice(-30):[];
  var signature=JSON.stringify(entries);
  if(history.getAttribute('data-history')!==signature){
    history.replaceChildren();
    entries.forEach(function(entry){var item=document.createElement('li');var at=Number(entry.at);item.textContent=(at?new Date(at*1000).toLocaleTimeString()+' — ':'')+String(entry.message||entry.stage||'');history.appendChild(item)});
    history.setAttribute('data-history',signature);
  }
  history.hidden=entries.length===0;
  Array.prototype.forEach.call(steps.children,function(item,index){
    var number=index+1;
    item.classList.toggle('done',success||number<meta.step);
    item.classList.toggle('active',active&&number===meta.step);
    item.classList.toggle('error',error&&number===meta.step);
  });
}
if(cascadeExitForm)cascadeExitForm.addEventListener('submit',function(event){
  event.preventDefault();
  if(!confirmCascadeExit(cascadeExitForm))return;
  var button=cascadeExitForm.querySelector('.cascade-button');
  var input=cascadeExitForm.querySelector('input[name="exit_ip"]');
  var requested=(input&&input.value||'').trim();
  cascadeLocalErrorUntil=0;
  if(button){button.disabled=true;button.textContent='Запускаю…'}
  renderCascadeProgress({active:true,stage:'queued',message:'Передаю задачу на сервер…',requested_ip:requested,started_at:Math.floor(Date.now()/1000)});
  fetch(cascadeExitForm.action,{method:'POST',body:new FormData(cascadeExitForm),headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}})
    .then(function(response){return response.json().catch(function(){return {success:false,error:'Сервер вернул непонятный ответ.'}}).then(function(data){if(!response.ok||!data.success)throw new Error(data.error||'Подготовка не запущена.');return data})})
    .then(function(data){cascadeLocalErrorUntil=0;renderCascadeProgress({active:data.started===true,stage:data.started===true?'queued':'success',message:data.message||'Подготовка запущена.',requested_ip:requested,started_at:Math.floor(Date.now()/1000)});pollCascadeExit()})
    .catch(function(error){cascadeLocalErrorUntil=Date.now()+15000;renderCascadeProgress({active:false,stage:'error',failed_stage:'queued',message:error.message||'Подготовка не запущена.',requested_ip:requested,started_at:Math.floor(Date.now()/1000),finished_at:Math.floor(Date.now()/1000)});if(button){button.disabled=false;button.textContent='Подготовить и переключить'}});
});
var cascadeModeForm=document.getElementById('cascade-mode-form');
if(cascadeModeForm)cascadeModeForm.addEventListener('submit',function(event){
  var enabled=cascadeModeForm.getAttribute('data-enabled')==='true';
  var action=enabled?'выключить каскад и вернуть прямой выход':'включить каскад через настроенный exit';
  if(!window.confirm('Действительно '+action+'?')){event.preventDefault();return}
  var button=document.getElementById('cascade-mode-button');
  if(button){button.disabled=true;button.textContent='Переключаю…'}
});
function renderCascadeExit(data){
  if(!data||!data.success||data.status_available===false)return;
  var current=document.getElementById('cascade-current-ip');
  var port=document.getElementById('cascade-port');
  var health=document.getElementById('cascade-health');
  var progress=document.getElementById('cascade-progress');
  var button=cascadeExitForm&&cascadeExitForm.querySelector('.cascade-button');
  var modeBadge=document.getElementById('cascade-mode-badge');
  var modeButton=document.getElementById('cascade-mode-button');
  var modeValue=document.getElementById('cascade-mode-value');
  var job=data.job||{};
  var enabled=data.enabled===true;
  if(current)current.textContent=data.exit_ip||'н/д';
  if(port)port.textContent='UDP '+(data.port||'авто');
  if(health){
    health.classList.toggle('ok',enabled&&data.healthy===true);
    health.classList.toggle('error',job.stage==='error');
    health.textContent=!enabled?'● прямой выход'+(data.direct_ip?' · '+data.direct_ip:''):(data.healthy?'● каскад работает · '+data.handshake_label:(data.exit_ip?'● нет свежего handshake · '+data.handshake_label:'● exit ещё не настроен'));
  }
  if(modeBadge){modeBadge.textContent='Каскад: '+(enabled?'включён':'выключен');modeBadge.classList.toggle('on-badge',enabled)}
  if(cascadeModeForm)cascadeModeForm.setAttribute('data-enabled',enabled?'true':'false');
  if(modeValue)modeValue.value=enabled?'off':'on';
  if(modeButton){modeButton.disabled=job.active===true||(!enabled&&!data.exit_ip);modeButton.classList.toggle('enabled',enabled);modeButton.textContent=job.active?'Переключаю…':(enabled?'Выключить каскад':(data.exit_ip?'Включить каскад':'Сначала укажите exit'))}
  if(job.stage!=='idle'||Date.now()>=cascadeLocalErrorUntil)renderCascadeProgress(job);
  if(button){button.disabled=job.active===true;button.textContent=job.active?'Подготавливаю…':'Подготовить и переключить'}
  if(cascadeExitForm)cascadeExitForm.setAttribute('data-current-ip',data.exit_ip||'');
}
function pollCascadeExit(){
  if(!cascadeExitForm&&!cascadeModeForm)return;
  if(cascadePollBusy)return;
  cascadePollBusy=true;
  if(cascadePollTimer){window.clearTimeout(cascadePollTimer);cascadePollTimer=null}
  fetch('/api/cascade/status',{cache:'no-store',headers:{'Accept':'application/json'}})
    .then(function(response){if(!response.ok)throw new Error('status unavailable');return response.json()})
    .then(function(data){if(data.status_available===false)throw new Error('unavailable');renderCascadeExit(data);cascadePollBusy=false;cascadePollTimer=window.setTimeout(pollCascadeExit,data.job&&data.job.active===true?1000:3000)})
    .catch(function(){cascadePollBusy=false;var health=document.getElementById('cascade-health');if(health){health.textContent='Статус временно недоступен — повторная проверка…';health.classList.add('error')}cascadePollTimer=window.setTimeout(pollCascadeExit,3000)});
}
if(cascadeExitForm||cascadeModeForm)pollCascadeExit();
function refreshSuggestion(kind,button){
  var field=document.getElementById(kind==='ip'?'new-user-ip':'new-public-port');
  if(!field||!button)return;
  button.disabled=true;
  fetch('/api/suggestions',{cache:'no-store',headers:{'Accept':'application/json'}})
    .then(function(response){if(!response.ok)throw new Error('suggestion unavailable');return response.json()})
    .then(function(data){
      var value=kind==='ip'?data.ip:data.public_port;
      if(value!==''&&value!=null){field.value=value;field.focus();field.select()}
    })
    .catch(function(){button.title='Не удалось обновить. Повторите попытку.'})
    .finally(function(){button.disabled=false});
}
var suggestIpButton=document.getElementById('suggest-ip');
var suggestPortButton=document.getElementById('suggest-port');
if(suggestIpButton)suggestIpButton.addEventListener('click',function(){refreshSuggestion('ip',suggestIpButton)});
if(suggestPortButton)suggestPortButton.addEventListener('click',function(){refreshSuggestion('port',suggestPortButton)});
document.querySelectorAll('[data-flash-category="success"],[data-flash-category="info"]').forEach(function(message){
  window.setTimeout(function(){
    message.classList.add('panel-notice-hiding');
    window.setTimeout(function(){message.remove()},250);
  },60000);
});
function formatCollected(value){
  if(!value)return "ещё нет";
  var parsed=new Date(value);
  return isNaN(parsed.getTime())?value:parsed.toLocaleTimeString();
}
function esc(v){
  return String(v==null?"":v).replace(/[&<>"']/g,function(c){
    return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
  });
}
function renderIps(u){
  var ips=Array.isArray(u.vpn_ips)?u.vpn_ips:(u.vpn_ip?[u.vpn_ip]:[]);
  if(!ips.length)return "\u2014";
  return ips.map(function(ip){
    var safe=esc(ip);
    return "<a class='ip' href='http://"+safe+"' target='_blank' rel='noopener'>"+safe+"</a>";
  }).join("<br>");
}
document.querySelectorAll(".pf-check").forEach(function(button){
  button.addEventListener("click",function(){
    var ruleId=button.dataset.ruleId;
    var state=document.getElementById("pf-state-"+ruleId);
    button.disabled=true;
    state.className="pf-diagnostic pf-idle";
    state.textContent="Проверка счётчиков…";
    fetch("/api/forwards/status?rule_id="+encodeURIComponent(ruleId),{cache:"no-store",headers:{"Accept":"application/json"}}).then(function(response){
      return response.json().then(function(data){
        if(!response.ok||!data.success)throw new Error(data.error||"Диагностика недоступна");
        return data;
      });
    }).then(function(data){
      state.className="pf-diagnostic pf-"+(data.state||"idle");
      state.textContent=data.message+" · снаружи "+data.wan_attempts+" · из VPN "+data.loopback_attempts+" · передано "+data.forward_packets+" · ответы "+data.reply_packets;
    }).catch(function(error){
      state.className="pf-diagnostic pf-warning";
      state.textContent=error.message||"Диагностика временно недоступна";
    }).finally(function(){button.disabled=false});
  });
});
function syncUserTable(markup){
  var tbody=document.getElementById("user-tbody");
  var wrap=tbody.closest(".table-wrap");
  var scrollTop=wrap?wrap.scrollTop:0;
  var scrollLeft=wrap?wrap.scrollLeft:0;
  var activeIpInput=document.activeElement&&document.activeElement.matches("#user-tbody input[name='ip']")?document.activeElement:null;
  if(wrap){
    wrap.style.overflowAnchor="none";
    wrap.style.scrollbarGutter="stable";
  }

  var template=document.createElement("template");
  template.innerHTML="<table><tbody>"+markup+"</tbody></table>";
  var freshBody=template.content.querySelector("tbody");
  var oldByUser=new Map();
  Array.prototype.forEach.call(tbody.rows,function(row){
    oldByUser.set(row.dataset.user,row);
  });

  var orderedRows=[];
  Array.prototype.forEach.call(freshBody.rows,function(freshRow){
    var oldRow=oldByUser.get(freshRow.dataset.user);
    if(!oldRow){
      orderedRows.push(freshRow);
      return;
    }
    oldByUser.delete(freshRow.dataset.user);

    [1,3].forEach(function(index){
      if(oldRow.cells[index].innerHTML!==freshRow.cells[index].innerHTML){
        oldRow.cells[index].innerHTML=freshRow.cells[index].innerHTML;
      }
    });
    [4,5,6].forEach(function(index){
      var nextText=freshRow.cells[index].textContent;
      if(oldRow.cells[index].textContent!==nextText)oldRow.cells[index].textContent=nextText;
    });

    var oldIpInput=oldRow.cells[2].querySelector("input[name='ip']");
    var freshIpInput=freshRow.cells[2].querySelector("input[name='ip']");
    if(oldIpInput&&freshIpInput&&oldIpInput!==activeIpInput&&oldIpInput.value!==freshIpInput.value){
      oldIpInput.value=freshIpInput.value;
    }
    var oldIpButton=oldRow.cells[2].querySelector("button");
    var freshIpButton=freshRow.cells[2].querySelector("button");
    if(oldIpButton&&freshIpButton){
      var nextButtonClass=freshIpButton.className;
      if(oldIpButton.className!==nextButtonClass)oldIpButton.className=nextButtonClass;
      var nextButtonLabel=freshIpButton.getAttribute("aria-label");
      if(oldIpButton.getAttribute("aria-label")!==nextButtonLabel){
        oldIpButton.setAttribute("aria-label",nextButtonLabel);
      }
    }
    orderedRows.push(oldRow);
  });

  oldByUser.forEach(function(row){row.remove()});
  var currentRows=Array.prototype.slice.call(tbody.rows);
  var sameOrder=currentRows.length===orderedRows.length&&orderedRows.every(function(row,index){return currentRows[index]===row});
  if(!sameOrder){
    var fragment=document.createDocumentFragment();
    orderedRows.forEach(function(row){fragment.appendChild(row)});
    tbody.appendChild(fragment);
  }
  if(wrap){
    wrap.scrollTop=scrollTop;
    wrap.scrollLeft=scrollLeft;
  }
}
function refresh(){
  if(busy)return;
  busy=true;
  fetch("/api/status",{cache:"no-store"}).then(function(r){
    return r.json().then(function(d){
      if(!r.ok||d.success===false)throw new Error(d.error||"Статус VPN недоступен");
      return d;
    });
  }).then(function(d){
    var h="";
    d.users.forEach(function(u){
      var name=esc(u.name);
      var count=Number(u.session_count||0);
      var st=u.online?"<span class='on'>\\u25cf онлайн</span>"+(count>1?" <span class='session-count'>(сеансов: "+count+")</span>":""):"<span class='off'>\\u25cf офлайн</span>";
      var vi=renderIps(u);
      var desired=esc(u.desired_ip||"");
      var ipButtonClass=u.ip_ready?"btn btn-ip-ready":"btn btn-outline";
      h+="<tr data-user='"+name+"'><td>"+name+"</td><td>"+st+"</td>";
      h+="<td><form class='ip-editor' method='post' action='/ip'><input type='hidden' name='csrf' value='"+esc(csrf)+"'><input type='hidden' name='user' value='"+name+"'><input name='ip' value='"+desired+"' placeholder='10.77.0.x' required><button type='submit' class='"+ipButtonClass+"' aria-label='"+(u.ip_ready?"Постоянный IP применён":"Сохранить постоянный IP")+"'>IP</button></form></td>";
      h+="<td class='ip-list'>"+vi+"</td>";
      h+="<td>"+esc(u.dl)+"</td><td>"+esc(u.ul)+"</td><td>"+esc(u.total)+"</td>";
      h+="<td><form method='post' action='/kick'><input type='hidden' name='csrf' value='"+esc(csrf)+"'><input type='hidden' name='user' value='"+name+"'><button type='submit' class='btn btn-kick'>Отключить</button></form> ";
      h+="<form method='post' action='/delete'><input type='hidden' name='csrf' value='"+esc(csrf)+"'><input type='hidden' name='user' value='"+name+"'><button type='submit' class='btn btn-del'>Удалить</button></form> ";
      h+="<form method='post' action='/traffic/reset-user-view' onsubmit=\\\"return confirm('Сбросить только отображаемый трафик пользователя "+name+"? Счётчики VPN и месячный учёт не изменятся.')\\\"><input type='hidden' name='csrf' value='"+esc(csrf)+"'><input type='hidden' name='user' value='"+name+"'><button type='submit' class='btn btn-user-reset' aria-label='Сбросить визуальный трафик пользователя "+name+"'>Сбросить</button></form></td></tr>";
    });
    syncUserTable(h);
    document.getElementById("user-count").textContent=d.users.length;
    document.getElementById("month-total").innerHTML="Итог за месяц: \\u2193 "+d.total_dl+" \\u00b7 \\u2191 "+d.total_ul+" \\u00b7 \\u03a3 "+d.total_all;
    var trafficNote=document.getElementById("traffic-note");
    trafficNote.textContent=d.traffic_note || "";
    trafficNote.hidden=!d.traffic_note;
    document.getElementById("last-update").textContent=formatCollected(d.collected_at);
    var collectorState=document.getElementById("collector-state");
    collectorState.textContent="\\u25cf в реальном времени";
    collectorState.className="on";
    var errorBox=document.getElementById("status-error");
    errorBox.textContent="";
    errorBox.hidden=true;
    busy=false;
  }).catch(function(e){
    var errorBox=document.getElementById("status-error");
    errorBox.textContent=(e&&e.message?e.message:"Не удалось обновить статус.")+" Текущая таблица сохранена.";
    errorBox.hidden=false;
    var collectorState=document.getElementById("collector-state");
    collectorState.textContent="\\u25cf данные устарели";
    collectorState.className="stale";
    busy=false;
  });
}
document.getElementById("last-update").textContent=formatCollected({{collected_at|tojson}});
setTimeout(refresh,500);
setInterval(refresh,2000);
</script>
</body></html>
'''

DELETE_CONFIRM_TPL = '''
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Подтверждение удаления — SSTP Manager</title>
<style>
:root{color-scheme:dark;--bg:#08111d;--surface:#0d1825;--border:#27374a;--text:#edf4fc;--muted:#9aabc0;--red:#f04f5f;--red-hover:#ff6574;--blue:#1686d9}
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--bg);color:var(--text);font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif;padding:24px}
.card{width:min(520px,100%);background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:30px;box-shadow:0 24px 60px rgba(0,0,0,.3)}
h1{margin:0 0 12px;font-size:26px}p{margin:0 0 12px;color:var(--muted)}strong{color:var(--text)}.warning{margin:18px 0 24px;padding:13px 15px;border:1px solid rgba(240,79,95,.55);border-radius:9px;color:#ffd9dd;background:rgba(240,79,95,.09)}
.actions{display:flex;gap:12px;flex-wrap:wrap}.actions form{margin:0}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 18px;border-radius:8px;border:1px solid transparent;color:white;text-decoration:none;font-weight:700;cursor:pointer;font:inherit}.cancel{background:var(--blue)}.delete{background:var(--red)}.delete:hover{background:var(--red-hover)}
</style></head><body><main class="card"><h1>Удалить пользователя?</h1>
<p>Будет удалена учётная запись <strong>{{ user }}</strong> на VPN-сервере.</p>
<div class="warning">Это удалит пользователя целиком, а не отдельный IP-адрес или одну SSTP-сессию.</div>
<div class="actions"><a class="btn cancel" href="{{ url_for('index') }}">Отмена</a>
<form method="post" action="{{ url_for('delete') }}"><input type="hidden" name="csrf" value="{{csrf_token}}"><input type="hidden" name="user" value="{{ user }}"><input type="hidden" name="confirmed" value="1"><button class="btn delete" type="submit">Да, удалить пользователя</button></form></div>
</main></body></html>
'''

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        if request.form.get('website', ''):
            flash('Доступ запрещён')
            a, b = random.randint(10,99), random.randint(10,99)
            session['captcha_answer'] = a + b
            return render_template_string(LOGIN_TPL, a=a, b=b)
        captcha_answer = request.form.get('captcha', '')
        expected = session.get('captcha_answer')
        with open(f'{ADMIN_DIR}/.admin_password', encoding='utf-8') as password_file:
            pwd = password_file.read().strip()
        if not expected or captcha_answer != str(expected):
            flash('Неверный ответ')
        elif not secrets.compare_digest(request.form.get('password', '').encode('utf-8'), pwd.encode('utf-8')):
            flash('Неверный пароль')
        else:
            session['logged_in'] = True
            session['csrf_token'] = secrets.token_urlsafe(32)
            return redirect(url_for('index'))
    a, b = random.randint(10,99), random.randint(10,99)
    session['captcha_answer'] = a + b
    return render_template_string(LOGIN_TPL, a=a, b=b)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/logs')
@login_required
def logs_page():
    response = app.make_response(render_template_string(LOGS_TPL))
    response.headers['Cache-Control'] = 'no-store'
    return response

@app.route('/api/logs')
@login_required
def api_logs():
    source = request.args.get('source', 'connections').strip().lower()
    if source not in LOG_SOURCE_LABELS:
        return jsonify(success=False, error='Неизвестный источник журнала.'), 400
    try:
        payload = read_sstp_logs(source, request.args.get('lines', '250'))
    except OSError as exc:
        logger.warning('SSTP log read failed for %s: %s', source, type(exc).__name__)
        return jsonify(success=False, error='Журнал временно недоступен.'), 503
    response = jsonify(success=True, **payload)
    response.headers['Cache-Control'] = 'no-store'
    return response

@app.route('/')
@login_required
def index():
    token = csrf_token()
    static_ips = load_static_ips()
    port_forwards = sorted(load_port_forwards(), key=natural_rule_name_key)
    network_settings = load_network_settings()
    access_networks = load_access_networks()
    routes = load_routes()
    try:
        snapshot = load_status_snapshot()
        status_error = ''
        status_code = 200
    except StatusCacheError as exc:
        logger.warning('Dashboard cache unavailable: %s', exc.public_message)
        snapshot = exc.snapshot or {
            'users': [], 'month': datetime.now().strftime('%Y-%m'),
            'total_dl': 'н/д', 'total_ul': 'н/д',
            'total_all': 'н/д',
            'traffic_note': 'Статус и данные трафика не загружены.',
            'collected_at': '',
        }
        status_error = exc.public_message
        status_code = 503
    users = snapshot.get('users', [])
    response = render_template_string(
        INDEX_TPL, users=users, month=snapshot.get('month', ''),
        total_dl=snapshot.get('total_dl', 'н/д'),
        total_ul=snapshot.get('total_ul', 'н/д'),
        total_all=snapshot.get('total_all', 'н/д'),
        traffic_note=snapshot.get('traffic_note', ''),
        collected_at=snapshot.get('collected_at', ''),
        status_error=status_error,
        csrf_token=token, static_ips=static_ips, port_forwards=port_forwards,
        suggested_ip=next_available_static_ip(static_ips),
        suggested_port=next_available_public_port(port_forwards),
        network_settings=network_settings, access_networks=access_networks,
    routes=routes, vpn_network=str(VPN_NETWORK), vpn_gateway=str(VPN_GATEWAY),
        cascade_exit=load_cascade_exit_status(),
        user_count_label=None if users else ('н/д' if status_error else None),
    )
    return response, status_code

@app.route('/api/suggestions')
@login_required
def api_suggestions():
    response = jsonify(
        success=True,
        ip=next_available_static_ip(),
        public_port=next_available_public_port(),
    )
    response.headers['Cache-Control'] = 'no-store'
    return response

@app.route('/api/cascade/status')
@login_required
def api_cascade_status():
    payload = load_cascade_exit_status()
    response = jsonify(success=True, **payload)
    response.headers['Cache-Control'] = 'no-store'
    return response

@app.route('/api/status')
@login_required
def api_status():
    try:
        snapshot = load_status_snapshot()
    except StatusCacheError as exc:
        logger.warning('Status API cache unavailable: %s', exc.public_message)
        return jsonify(success=False, error=exc.public_message), 503
    return jsonify(
        success=True,
        users=snapshot['users'], month=snapshot['month'],
        total_dl=snapshot['total_dl'], total_ul=snapshot['total_ul'],
        total_all=snapshot['total_all'], traffic_note=snapshot['traffic_note'],
        collected_at=snapshot['collected_at'], age_seconds=snapshot['age_seconds'],
    )


@app.route('/api/forwards/status')
@login_required
def api_forward_status():
    rule_id = request.args.get('rule_id', '').strip()
    rules = {
        str(item.get('id', '')): item
        for item in load_port_forwards() if item.get('id')
    }
    if rule_id not in rules:
        return jsonify(success=False, error='Правило проброса не найдено.'), 404
    try:
        metrics = load_port_forward_diagnostics().get(rule_id, {})
    except (OSError, subprocess.TimeoutExpired, RuntimeError) as exc:
        logger.warning('Port-forward diagnostics unavailable: %s', exc)
        return jsonify(
            success=False,
            error='Диагностика сетевого правила временно недоступна.',
        ), 503
    wan_attempts = int(metrics.get('wan_attempts', 0))
    loopback_attempts = int(metrics.get('loopback_attempts', 0))
    forward_packets = int(metrics.get('forward_packets', 0))
    reply_packets = int(metrics.get('reply_packets', 0))
    if reply_packets:
        state = 'ok'
        message = 'Ответ от клиента получен'
    elif forward_packets or wan_attempts or loopback_attempts:
        state = 'warning'
        message = 'Запрос передан клиенту, ответа пока нет'
    else:
        state = 'idle'
        message = 'Запросов после применения правила ещё не было'
    return jsonify(
        success=True,
        rule_id=rule_id,
        state=state,
        message=message,
        wan_attempts=wan_attempts,
        loopback_attempts=loopback_attempts,
        forward_packets=forward_packets,
        reply_packets=reply_packets,
    )


@app.route('/traffic/reset-view', methods=['POST'])
@login_required
@csrf_required
def reset_traffic_view():
    reset_at = reset_traffic_view_baseline()
    try:
        save_status_snapshot(collect_status_snapshot())
        refresh_note = 'Таблица обновлена сразу.'
    except VpncmdError as exc:
        logger.warning('Immediate refresh after traffic view reset failed: %s', exc.kind)
        refresh_note = 'Фоновый сборщик обновит таблицу в ближайшее время.'
    flash(
        f'Точка отсчёта в таблице сброшена {reset_at}. '
        f'Счётчики VPN и месячного учёта не обнулены. {refresh_note}',
        'success',
    )
    return redirect(url_for('index'))


@app.route('/traffic/reset-user-view', methods=['POST'])
@login_required
@csrf_required
def reset_user_traffic_view():
    username = request.form.get('user', '').strip()
    if not username or username not in load_static_ips():
        flash('Визуальный трафик не сброшен: пользователь не найден.', 'error')
        return redirect(url_for('index'))
    reset_at = reset_user_traffic_view_baseline(username)
    try:
        save_status_snapshot(collect_status_snapshot())
        refresh_note = 'Строка обновлена сразу.'
    except VpncmdError as exc:
        logger.warning(
            'Immediate refresh after user traffic view reset failed for %s: %s',
            username, exc.kind,
        )
        refresh_note = 'Фоновый сборщик обновит строку в ближайшее время.'
    flash(
        f'Визуальный трафик пользователя {username} сброшен {reset_at}. '
        f'Счётчики VPN и месячный учёт не изменены. {refresh_note}',
        'success',
    )
    return redirect(url_for('index'))

@app.route('/add', methods=['POST'])
@login_required
@csrf_required
def add():
    u = request.form.get('username', '').strip()
    if u.casefold().endswith('@vpn'):
        u = u[:-4]
    p = request.form.get('password', '')
    ip_value = request.form.get('ip', '').strip()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', u):
        flash('Пользователь не добавлен: начните имя с буквы или цифры; допустимы также точка, _ и -. Суффикс подключения: @VPN.', 'error')
        return redirect(url_for('index'))
    if not 8 <= len(p) <= 128 or re.search(r'''[\s"'\\#]''', p):
        flash('Пароль: 8–128 символов без пробелов, кавычек, обратной косой черты и #.', 'error')
        return redirect(url_for('index'))
    mappings = load_static_ips()
    try:
        selected_ip = validate_static_ip(ip_value, u, mappings)
    except ValueError as exc:
        flash(f'Пользователь не добавлен: {exc}', 'error')
        return redirect(url_for('index'))
    old_mappings = dict(mappings)
    mappings[u] = selected_ip
    _save_json(STATIC_IP_FILE, mappings)
    try:
        vpncmd(['UserCreate', u, '/GROUP:none', f'/REALNAME:{u}', '/NOTE:'], HUB)
    except VpncmdError as exc:
        _save_json(STATIC_IP_FILE, old_mappings)
        flash(f'Пользователь {u} не добавлен. {exc.public_message}', 'error')
        return redirect(url_for('index'))
    try:
        vpncmd(['UserPasswordSet', u, f'/PASSWORD:{p}'], HUB)
        vpncmd(['UserPolicySet', u, '/NAME:MultiLogins', '/VALUE:1'], HUB)
    except VpncmdError as exc:
        try:
            vpncmd(['UserDelete', u], HUB)
        except VpncmdError as rollback_exc:
            logger.error(
                'Unable to roll back incomplete user %s after %s error: %s',
                u, exc.kind, rollback_exc.kind,
            )
        _save_json(STATIC_IP_FILE, old_mappings)
        flash(
            f'Пользователь {u} не добавлен: пароль или ограничение одного входа '
            f'не применено. '
            f'{exc.public_message}',
            'error',
        )
        return redirect(url_for('index'))
    result = apply_static_ips()
    if result.returncode:
        flash(
            f'Пользователь {u} добавлен, IP {selected_ip} сохранён, но служба закрепления '
            'не подтвердила применение. Проверьте журнал тестового контура.', 'error'
        )
    else:
        flash(f'Пользователь {u} добавлен.', 'success')
    try:
        save_status_snapshot(collect_status_snapshot())
    except VpncmdError as exc:
        logger.warning(
            'Immediate status refresh after adding user %s failed: %s',
            u, exc.kind,
        )
    except Exception:
        logger.exception('Unexpected immediate status refresh failure after adding user %s', u)
    return redirect(url_for('index'))

@app.route('/ip', methods=['POST'])
@login_required
@csrf_required
def set_ip():
    u = request.form.get('user', '').strip()
    ip_value = request.form.get('ip', '').strip()
    mappings = load_static_ips()
    try:
        selected_ip = validate_static_ip(ip_value, u, mappings)
    except ValueError as exc:
        flash(f'IP для {u} не изменён: {exc}', 'error')
        return redirect(url_for('index'))
    old_mappings = dict(mappings)
    mappings[u] = selected_ip
    _save_json(STATIC_IP_FILE, mappings)
    forwards = load_port_forwards()
    old_forwards = [dict(item) for item in forwards]
    changed_forward = False
    for item in forwards:
        if item.get('user') == u:
            item['target_ip'] = selected_ip
            changed_forward = True
    if changed_forward:
        _save_json(PORT_FORWARD_FILE, forwards)
    routes = _load_json(ROUTES_FILE, [])
    old_routes = [dict(item) for item in routes if isinstance(item, dict)]
    for item in routes:
        if isinstance(item, dict) and item.get('user') == u:
            item['next_hop'] = selected_ip
    _save_json(ROUTES_FILE, routes)
    network_result = apply_network_settings()
    if network_result.returncode:
        _save_json(STATIC_IP_FILE, old_mappings)
        _save_json(PORT_FORWARD_FILE, old_forwards)
        _save_json(ROUTES_FILE, old_routes)
        apply_network_settings()
        flash(f'IP для {u} не изменён: сетевые правила не прошли проверку.', 'error')
        return redirect(url_for('index'))
    result = apply_static_ips()
    if result.returncode:
        flash(f'IP {selected_ip} сохранён, но применение не подтверждено.', 'error')
    else:
        try:
            terminate_user(u)
        except BackendError:
            pass
        flash(f'Для {u} установлен IP {selected_ip}.', 'success')
    return redirect(url_for('index'))

@app.route('/delete', methods=['POST'])
@login_required
@csrf_required
def delete():
    u = request.form.get('user', '').strip()
    if not u:
        flash('Пользователь не удалён: не указано имя.', 'error')
        return redirect(url_for('index'))
    if request.form.get('confirmed') != '1':
        return render_template_string(DELETE_CONFIRM_TPL, user=u, csrf_token=csrf_token())
    try:
        vpncmd(['UserDelete', u], HUB)
    except VpncmdError as exc:
        flash(f'Пользователь {u} не удалён. {exc.public_message}', 'error')
        return redirect(url_for('index'))
    mappings = load_static_ips()
    mappings.pop(u, None)
    _save_json(STATIC_IP_FILE, mappings)
    forwards = [item for item in load_port_forwards() if item.get('user') != u]
    _save_json(PORT_FORWARD_FILE, forwards)
    routes = [item for item in _load_json(ROUTES_FILE, []) if item.get('user') != u]
    _save_json(ROUTES_FILE, routes)
    apply_static_ips()
    apply_network_settings()
    flash(f'Пользователь {u}, его закрепление IP, маршруты и правила проброса удалены', 'success')
    return redirect(url_for('index'))

@app.route('/kick', methods=['POST'])
@login_required
@csrf_required
def kick():
    u = request.form.get('user', '').strip()
    if not u:
        flash('Сеансы не отключены: не указано имя пользователя.', 'error')
        return redirect(url_for('index'))
    try:
        raw = vpncmd('SessionList', HUB)
    except VpncmdError as exc:
        flash(f'Не удалось отключить сеансы пользователя {u}. {exc.public_message}', 'error')
        return redirect(url_for('index'))
    user_sessions = [item for item in parse_session_list(raw) if item['user'] == u]
    if not user_sessions:
        flash(f'У пользователя {u} нет активных сеансов.', 'info')
        return redirect(url_for('index'))
    disconnected = 0
    for item in user_sessions:
        try:
            vpncmd(['SessionDisconnect', item['session']], HUB)
            disconnected += 1
        except VpncmdError as exc:
            logger.warning(
                'Unable to disconnect session for %s after %s error', u, exc.kind,
            )
    failed = len(user_sessions) - disconnected
    if failed:
        flash(
            f'Пользователь {u}: отключено сеансов — {disconnected} из {len(user_sessions)}; '
            f'не удалось отключить — {failed}.',
            'error',
        )
    else:
        flash(f'Пользователь {u}: отключено сеансов — {disconnected}.', 'success')
    return redirect(url_for('index'))

@app.route('/settings/network', methods=['POST'])
@login_required
@csrf_required
def update_network_settings():
    old_settings = load_network_settings()
    try:
        new_settings = validate_network_settings(
            request.form.get('pool_start', '').strip(),
            request.form.get('pool_end', '').strip(),
            request.form.get('nat_enabled') == '1',
        )
    except ValueError as exc:
        flash(f'Настройки сети не изменены: {exc}', 'error')
        return redirect(url_for('index'))
    first = ipaddress.ip_address(new_settings['pool_start'])
    last = ipaddress.ip_address(new_settings['pool_end'])
    outside = [
        f'{username} ({address})' for username, address in load_static_ips().items()
        if not first <= ipaddress.ip_address(address) <= last
    ]
    if outside:
        flash(
            'Настройки сети не изменены: за пределами нового пула останутся постоянные IP: '
            + ', '.join(outside[:6]),
            'error',
        )
        return redirect(url_for('index'))
    _save_json(NETWORK_SETTINGS_FILE, new_settings)
    result = apply_network_settings()
    if result.returncode:
        _save_json(NETWORK_SETTINGS_FILE, old_settings)
        apply_network_settings()
        logger.error('Network settings apply failed: %s', (result.stderr or result.stdout)[-1000:])
        flash('Настройки сети не изменены: проверка конфигурации не прошла, прежние значения восстановлены.', 'error')
        return redirect(url_for('index'))
    nat_label = 'включён' if new_settings['nat_enabled'] else 'выключен'
    flash(
        f'Пул {new_settings["pool_start"]}–{new_settings["pool_end"]} сохранён. NAT {nat_label}.',
        'success',
    )
    return redirect(url_for('index'))

@app.route('/cascade/mode', methods=['POST'])
@login_required
@csrf_required
def update_cascade_mode():
    mode = request.form.get('mode', '').strip().lower()
    if mode not in {'on', 'off'}:
        flash('Режим каскада не изменён: обновите страницу и повторите.', 'error')
        return redirect(url_for('index'))
    try:
        result = subprocess.run(
            [CASCADE_EXIT_CONTROL, 'mode-start', mode],
            capture_output=True, text=True, timeout=20, check=False,
        )
        payload = json.loads(result.stdout)
    except subprocess.TimeoutExpired:
        logger.error('Cascade mode switch start timed out: %s', mode)
        flash('Переключение не запущено: служба не ответила вовремя.', 'error')
        return redirect(url_for('index'))
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        logger.error('Cascade mode control failed: %s', type(exc).__name__)
        flash('Переключение не запущено: управление каскадом временно недоступно.', 'error')
        return redirect(url_for('index'))
    if result.returncode or not payload.get('success'):
        message = str(payload.get('error', 'не удалось запустить переключение'))[:240]
        logger.warning('Cascade mode switch rejected: %s', message)
        flash(f'Режим не изменён: {message}', 'error')
        return redirect(url_for('index'))
    message = str(payload.get('message', 'Переключение каскада запущено.'))[:240]
    logger.info('Cascade mode switch requested: mode=%s started=%s', mode, payload.get('started'))
    flash(message, 'success' if payload.get('started') else 'info')
    return redirect(url_for('index'))

@app.route('/cascade/exit', methods=['POST'])
@login_required
@csrf_required
def update_cascade_exit():
    value = request.form.get('exit_ip', '').strip()
    wants_json = (
        request.headers.get('X-Requested-With') == 'XMLHttpRequest'
        or request.accept_mimetypes.best == 'application/json'
    )
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        message = 'Exit не изменён: укажите корректный IPv4-адрес.'
        if wants_json:
            return jsonify(success=False, error=message), 400
        flash(message, 'error')
        return redirect(url_for('index'))
    if address.version != 4 or not address.is_global:
        message = 'Exit не изменён: нужен публичный IPv4-адрес.'
        if wants_json:
            return jsonify(success=False, error=message), 400
        flash(message, 'error')
        return redirect(url_for('index'))
    try:
        result = subprocess.run(
            [CASCADE_EXIT_CONTROL, 'start', str(address)],
            capture_output=True, text=True, timeout=20, check=False,
        )
        payload = json.loads(result.stdout)
    except subprocess.TimeoutExpired:
        logger.error('Cascade exit job start timed out for %s', address)
        message = 'Подготовка не запущена: служба не ответила вовремя.'
        if wants_json:
            return jsonify(success=False, error=message), 504
        flash(message, 'error')
        return redirect(url_for('index'))
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        logger.error('Cascade exit control failed for %s: %s', address, type(exc).__name__)
        message = 'Подготовка не запущена: служба безопасной замены временно недоступна.'
        if wants_json:
            return jsonify(success=False, error=message), 503
        flash(message, 'error')
        return redirect(url_for('index'))
    if result.returncode or not payload.get('success'):
        message = str(payload.get('error', 'новый сервер не прошёл проверку'))[:240]
        logger.warning('Cascade exit job for %s rejected: %s', address, message)
        if wants_json:
            return jsonify(success=False, error=message), 409
        flash(f'Подготовка не запущена: {message}', 'error')
        return redirect(url_for('index'))
    message = str(payload.get('message', f'Подготовка выхода {address} запущена.'))[:240]
    logger.info('Cascade exit job requested for %s; started=%s', address, payload.get('started'))
    if wants_json:
        return jsonify(
            success=True,
            started=payload.get('started') is True,
            job_id=str(payload.get('job_id', '')),
            message=message,
        ), (202 if payload.get('started') is True else 200)
    flash(message, 'success' if payload.get('started') else 'info')
    return redirect(url_for('index'))

@app.route('/access/add', methods=['POST'])
@login_required
@csrf_required
def add_access_network():
    label = request.form.get('label', '').strip()
    if not label or len(label) > 48:
        flash('Разрешённая сеть не добавлена: укажите короткое название.', 'error')
        return redirect(url_for('index'))
    try:
        cidr = validate_private_network(request.form.get('cidr', '').strip())
    except ValueError as exc:
        flash(f'Разрешённая сеть не добавлена: {exc}', 'error')
        return redirect(url_for('index'))
    old_items = load_access_networks()
    if any(item['cidr'] == cidr for item in old_items):
        flash(f'Сеть {cidr} уже находится в списке разрешённых.', 'info')
        return redirect(url_for('index'))
    new_items = old_items + [{'id': secrets.token_hex(8), 'label': label, 'cidr': cidr}]
    _save_json(ACCESS_NETWORK_FILE, new_items)
    result = apply_network_settings()
    if result.returncode:
        _save_json(ACCESS_NETWORK_FILE, old_items)
        apply_network_settings()
        flash('Разрешённая сеть не добавлена: сетевые правила не прошли проверку.', 'error')
        return redirect(url_for('index'))
    flash(f'Доступ из SSTP к сети {cidr} разрешён.', 'success')
    return redirect(url_for('index'))

@app.route('/access/delete', methods=['POST'])
@login_required
@csrf_required
def delete_access_network():
    item_id = request.form.get('item_id', '').strip()
    old_items = load_access_networks()
    kept = [item for item in old_items if item.get('id') != item_id]
    if len(kept) == len(old_items):
        flash('Разрешённая сеть уже отсутствует.', 'info')
        return redirect(url_for('index'))
    _save_json(ACCESS_NETWORK_FILE, kept)
    result = apply_network_settings()
    if result.returncode:
        _save_json(ACCESS_NETWORK_FILE, old_items)
        apply_network_settings()
        flash('Разрешённая сеть не удалена: прежние правила восстановлены.', 'error')
        return redirect(url_for('index'))
    flash('Разрешённая сеть удалена.', 'success')
    return redirect(url_for('index'))

@app.route('/routes/add', methods=['POST'])
@login_required
@csrf_required
def add_route():
    label = request.form.get('label', '').strip()
    username = request.form.get('user', '').strip()
    if not label or len(label) > 48:
        flash('Маршрут не добавлен: укажите короткое название.', 'error')
        return redirect(url_for('index'))
    try:
        cidr = validate_private_network(request.form.get('cidr', '').strip())
    except ValueError as exc:
        flash(f'Маршрут не добавлен: {exc}', 'error')
        return redirect(url_for('index'))
    next_hop = load_static_ips().get(username)
    if not next_hop:
        flash('Маршрут не добавлен: выберите пользователя с постоянным IP.', 'error')
        return redirect(url_for('index'))
    old_routes = load_routes()
    if any(item['cidr'] == cidr for item in old_routes):
        flash(f'Маршрут к {cidr} уже существует.', 'info')
        return redirect(url_for('index'))
    new_routes = old_routes + [{
        'id': secrets.token_hex(8), 'label': label, 'cidr': cidr,
        'user': username, 'next_hop': next_hop,
    }]
    _save_json(ROUTES_FILE, new_routes)
    result = apply_network_settings()
    if result.returncode:
        _save_json(ROUTES_FILE, old_routes)
        apply_network_settings()
        logger.error('Route apply failed: %s', (result.stderr or result.stdout)[-1000:])
        flash('Маршрут не добавлен: проверка таблицы маршрутизации не прошла.', 'error')
        return redirect(url_for('index'))
    flash(f'Маршрут {cidr} через {username} ({next_hop}) добавлен.', 'success')
    return redirect(url_for('index'))

@app.route('/routes/delete', methods=['POST'])
@login_required
@csrf_required
def delete_route():
    item_id = request.form.get('item_id', '').strip()
    old_routes = load_routes()
    kept = [item for item in old_routes if item.get('id') != item_id]
    if len(kept) == len(old_routes):
        flash('Маршрут уже отсутствует.', 'info')
        return redirect(url_for('index'))
    _save_json(ROUTES_FILE, kept)
    result = apply_network_settings()
    if result.returncode:
        _save_json(ROUTES_FILE, old_routes)
        apply_network_settings()
        flash('Маршрут не удалён: прежняя конфигурация восстановлена.', 'error')
        return redirect(url_for('index'))
    flash('Маршрут удалён.', 'success')
    return redirect(url_for('index'))

@app.route('/forwards/add', methods=['POST'])
@login_required
@csrf_required
def add_forward():
    label = request.form.get('label', '').strip()
    protocol = request.form.get('protocol', '').strip().lower()
    username = request.form.get('user', '').strip()
    try:
        public_port = int(request.form.get('public_port', ''))
        target_port = int(request.form.get('target_port', ''))
    except ValueError:
        flash('Правило не добавлено: порты должны быть числами.', 'error')
        return redirect(url_for('index'))
    if not label or len(label) > 48:
        flash('Правило не добавлено: укажите короткое название.', 'error')
        return redirect(url_for('index'))
    if protocol not in {'tcp', 'udp'}:
        flash('Правило не добавлено: разрешены только TCP и UDP.', 'error')
        return redirect(url_for('index'))
    if not (1024 <= public_port <= 65535) or public_port in RESERVED_PUBLIC_PORTS:
        flash('Правило не добавлено: этот публичный порт запрещён или зарезервирован.', 'error')
        return redirect(url_for('index'))
    if not (1 <= target_port <= 65535):
        flash('Правило не добавлено: неверный порт клиента.', 'error')
        return redirect(url_for('index'))
    static_ips = load_static_ips()
    target_ip = static_ips.get(username)
    if not target_ip:
        flash('Правило не добавлено: у клиента нет постоянного IP.', 'error')
        return redirect(url_for('index'))
    forwards = load_port_forwards()
    if any(
        item.get('protocol') == protocol
        and int(item.get('public_port', 0)) == public_port
        for item in forwards
    ):
        flash(f'Правило не добавлено: {protocol.upper()} {public_port} уже занят.', 'error')
        return redirect(url_for('index'))
    rule = {
        'id': secrets.token_hex(8),
        'label': label,
        'protocol': protocol,
        'public_port': public_port,
        'user': username,
        'target_ip': target_ip,
        'target_port': target_port,
    }
    forwards.append(rule)
    _save_json(PORT_FORWARD_FILE, forwards)
    result = apply_port_forwards()
    if result.returncode:
        forwards = [item for item in forwards if item.get('id') != rule['id']]
        _save_json(PORT_FORWARD_FILE, forwards)
        apply_port_forwards()
        flash('Правило не добавлено: проверка сетевых правил не прошла.', 'error')
        return redirect(url_for('index'))
    flash(
        f'{protocol.upper()} {public_port} → {username} ({target_ip}:{target_port}) добавлен.',
        'success',
    )
    return redirect(url_for('index'))

@app.route('/forwards/delete', methods=['POST'])
@login_required
@csrf_required
def delete_forward():
    rule_id = request.form.get('rule_id', '').strip()
    forwards = load_port_forwards()
    kept = [item for item in forwards if item.get('id') != rule_id]
    if len(kept) == len(forwards):
        flash('Правило уже отсутствует.', 'info')
        return redirect(url_for('index'))
    _save_json(PORT_FORWARD_FILE, kept)
    result = apply_port_forwards()
    if result.returncode:
        _save_json(PORT_FORWARD_FILE, forwards)
        apply_port_forwards()
        flash('Правило не удалено: сетевой набор не удалось безопасно применить.', 'error')
        return redirect(url_for('index'))
    flash('Правило проброса удалено.', 'success')
    return redirect(url_for('index'))

@app.route('/backup')
@login_required
def backup():
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    fname = f'sstp-manager-backup_{ts}.tar.gz'
    paths = [
        '/opt/sstp-accel',
        '/opt/sstp-manager',
        '/etc/sstp-accel',
        '/etc/sstp-manager',
        '/etc/sstp-exit-provisioner.key.pub',
        '/etc/logrotate.d/sstp-accel',
        '/usr/local/sbin/sstp-route-reconcile',
        '/etc/sstp.nft',
        '/etc/sstp-egress-mode',
        '/etc/sstp-exit-known_hosts',
        '/etc/sstp-exit-provisioner.key',
        '/etc/wireguard/sstp_exit.conf',
        '/etc/wireguard/sstp_exit.key',
        '/var/lib/sstp-exit',
        '/etc/systemd/system/sstp-accel.service',
        '/etc/systemd/system/sstp-manager.service',
        '/etc/systemd/system/sstp-manager-collector.service',
        '/etc/systemd/system/sstp-manager.service.d',
        '/etc/systemd/system/sstp-nft-reconcile.service',
        '/etc/systemd/system/sstp-nft-reconcile.timer',
        '/etc/systemd/system/sstp-nft-reconcile.service.d',
        '/etc/systemd/system/sstp-peer-reconcile.service',
        '/etc/systemd/system/sstp-peer-reconcile.timer',
        '/etc/systemd/system/sstp-network.service',
        '/etc/systemd/system/sstp-network.service.d',
        '/etc/systemd/system/sstp-cascade.service',
        '/etc/systemd/system/sstp-cascade.timer',
        '/etc/nginx/sites-available/sstp-manager',
        '/etc/sysctl.d/90-sstp.conf',
        '/etc/letsencrypt/renewal-hooks/deploy/sstp-reload',
        '/usr/local/sbin/sstp-nft-apply',
        '/usr/local/sbin/sstp-nft-reconcile',
        '/usr/local/sbin/sstp-peer-reconcile',
        '/usr/local/sbin/sstp-network-up',
        '/usr/local/sbin/sstp-cascade-apply',
        '/usr/local/sbin/sstp-cascade-reconcile',
        '/usr/local/sbin/sstp-cascade-exit',
    ]
    for d in ['/etc/letsencrypt/live/__VPN_DOMAIN__', '/etc/letsencrypt/archive/__VPN_DOMAIN__']:
        if os.path.isdir(d):
            for fn in os.listdir(d):
                fp = os.path.join(d, fn)
                if os.path.isfile(fp) or os.path.islink(fp):
                    paths.append(fp)
    renewal = '/etc/letsencrypt/renewal/__VPN_DOMAIN__.conf'
    if os.path.isfile(renewal):
        paths.append(renewal)

    # File-object response is closed by the WSGI server; no backup is left in /tmp.
    tmp_f = tempfile.TemporaryFile(mode='w+b')
    try:
        with tarfile.open(fileobj=tmp_f, mode='w:gz') as tar:
            for path in paths:
                real = os.path.realpath(path) if os.path.islink(path) else path
                if os.path.exists(real):
                    tar.add(real, arcname='backup/files' + path, recursive=True)
        tmp_f.seek(0)
        return send_file(tmp_f, as_attachment=True, download_name=fname, mimetype='application/gzip')
    except Exception:
        tmp_f.close()
        raise

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5001)
