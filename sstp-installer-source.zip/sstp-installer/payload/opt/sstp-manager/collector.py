#!/usr/bin/env python3
import argparse
import json
import logging
import signal
import threading
import time

import app


STATUS_INTERVAL = 2.0
TRAFFIC_INTERVAL = 5.0
FULL_STATUS_INTERVAL = 15.0
STATUS_FAILURES_BEFORE_ERROR = 3
stop_event = threading.Event()
vpncmd_lock = threading.Lock()
logger = logging.getLogger('vpn-admin-collector')
consecutive_status_failures = 0


def stop_collector(signum, frame):
    stop_event.set()


def wait_for_next(started, interval):
    stop_event.wait(max(0.1, interval - (time.monotonic() - started)))


def collect_status_once(full=True):
    with vpncmd_lock:
        snapshot = (
            app.collect_status_snapshot()
            if full else app.collect_quick_status_snapshot()
        )
    app.save_status_snapshot(snapshot)
    return snapshot


def reset_status_failures():
    global consecutive_status_failures
    consecutive_status_failures = 0


def record_status_failure(message):
    global consecutive_status_failures
    consecutive_status_failures += 1
    if consecutive_status_failures >= STATUS_FAILURES_BEFORE_ERROR:
        app.mark_status_cache_error(message)
    return consecutive_status_failures


def status_loop():
    last_full = 0.0
    while not stop_event.is_set():
        started = time.monotonic()
        try:
            full = not last_full or started - last_full >= FULL_STATUS_INTERVAL
            collect_status_once(full=full)
            reset_status_failures()
            if full:
                last_full = time.monotonic()
        except app.VpncmdError as exc:
            failures = record_status_failure(exc.public_message)
            logger.warning(
                'Status collection failed after %s error (%s/%s)',
                exc.kind, failures, STATUS_FAILURES_BEFORE_ERROR,
            )
        except Exception:
            logger.exception('Unexpected status collector failure')
            record_status_failure(
                'Сборщик статуса завершился с непредвиденной ошибкой; текущая таблица сохранена.'
            )
        wait_for_next(started, STATUS_INTERVAL)


def traffic_loop():
    stop_event.wait(0.5)
    while not stop_event.is_set():
        started = time.monotonic()
        try:
            usernames = app.cached_usernames()
            if usernames:
                with vpncmd_lock:
                    app.update_traffic(usernames)
        except Exception:
            logger.exception('Unexpected traffic collector failure')
        wait_for_next(started, TRAFFIC_INTERVAL)


def run_once():
    snapshot = collect_status_once(full=True)
    usernames = [user['name'] for user in snapshot['users']]
    if usernames:
        with vpncmd_lock:
            app.update_traffic(usernames)
        snapshot = collect_status_once(full=True)
    print(json.dumps({
        'collected_at': snapshot['collected_at'],
        'user_count': len(snapshot['users']),
        'online_count': sum(1 for user in snapshot['users'] if user['online']),
        'cache_file': app.STATUS_CACHE_FILE,
    }, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s: %(message)s',
    )
    if args.once:
        run_once()
        return

    signal.signal(signal.SIGTERM, stop_collector)
    signal.signal(signal.SIGINT, stop_collector)
    workers = [
        threading.Thread(target=status_loop, name='status-collector'),
        threading.Thread(target=traffic_loop, name='traffic-collector'),
    ]
    for worker in workers:
        worker.start()
    for worker in workers:
        worker.join()


if __name__ == '__main__':
    main()
