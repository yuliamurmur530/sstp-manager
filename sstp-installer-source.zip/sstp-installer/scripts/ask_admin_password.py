#!/usr/bin/env python3
"""Ask on a real terminal and write a chosen panel password into private staging."""
import argparse
import getpass
import os
from pathlib import Path
import secrets
import sys


def validation_error(password):
    if not 12 <= len(password) <= 128:
        return 'Используйте от 12 до 128 символов.'
    if password != password.strip():
        return 'Пароль не должен начинаться или заканчиваться пробелом.'
    if not password.isprintable():
        return 'Управляющие и непечатные символы в пароле недопустимы.'
    return ''


def choose_password(terminal, reader=getpass.getpass):
    terminal.write('\nЗадайте пароль для входа в админ-панель. Ввод не отображается.\n')
    terminal.flush()
    while True:
        password = reader('Пароль админ-панели (12–128 символов): ', stream=terminal)
        error = validation_error(password)
        if error:
            terminal.write(error + '\n')
            terminal.flush()
            continue
        repeated = reader('Повторите пароль: ', stream=terminal)
        # UTF-8 bytes allow non-ASCII passphrases with constant-time comparison.
        if secrets.compare_digest(password.encode('utf-8'), repeated.encode('utf-8')):
            return password
        terminal.write('Пароли не совпали. Введите их ещё раз.\n')
        terminal.flush()


def store_password(path, password):
    if validation_error(password):
        raise ValueError('Invalid administrator password')
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(path, flags, 0o600)
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8', newline='\n') as stream:
            stream.write(password + '\n')
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        Path(path).unlink(missing_ok=True)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    # No getpass stdin fallback: a downloaded installer must not consume its
    # own script stream or accidentally show a password on a non-interactive pipe.
    try:
        with open('/dev/tty', 'r+', encoding='utf-8') as terminal:
            if not os.isatty(terminal.fileno()):
                raise OSError('Controlling terminal unavailable')
            password = choose_password(terminal)
        store_password(args.destination, password)
    except (OSError, EOFError, KeyboardInterrupt):
        print('Пароль не сохранён. Нужен интерактивный терминал SSH; установка остановлена.', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
