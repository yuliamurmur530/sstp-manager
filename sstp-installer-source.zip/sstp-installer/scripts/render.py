#!/usr/bin/env python3
"""Render a reviewed public payload into a private staging tree, never in-place."""
import argparse
import ipaddress
import re
from pathlib import Path


def installation_settings(subnet, suffix):
    """Keep the existing /24 host offsets and allow only private client networks."""
    network = ipaddress.ip_network(subnet, strict=True)
    private_ranges = tuple(ipaddress.ip_network(value) for value in
                           ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16'))
    if network.version != 4 or network.prefixlen != 24 or not any(
            network.subnet_of(block) for block in private_ranges):
        raise ValueError('Use a private IPv4 /24 network, for example 192.168.50.0/24.')
    if network.overlaps(ipaddress.ip_network('10.78.0.0/30')):
        raise ValueError('This network overlaps the reserved cascade network 10.78.0.0/30.')
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,31}', suffix):
        raise ValueError('Login suffix: 1-32 ASCII letters, digits, _ or -, starting with a letter; no @.')
    return network, suffix.upper()


def render_settings(data, network, suffix):
    # Public payload remains runnable with its default values for isolated tests.
    # Replace only its canonical network prefix, BEFORE inserting user domain/IP.
    prefix = str(network.network_address).rsplit('.', 1)[0] + '.'
    data = re.sub(r'(?<![\w.])10\.77\.0\.(?=\d|x)', lambda _: prefix, data)
    data = data.replace('REALM = "VPN"', f'REALM = "{suffix}"')
    data = data.replace("HUB = 'VPN'", f"HUB = '{suffix}'")
    return data.replace('@VPN', '@' + suffix)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--domain", required=True)
    parser.add_argument("--sstp-port", required=True, type=int)
    parser.add_argument("--admin-port", required=True, type=int)
    parser.add_argument("--public-ip", required=True)
    parser.add_argument("--ipv6", action="store_true")
    parser.add_argument("--vpn-subnet", default="10.77.0.0/24")
    parser.add_argument("--login-suffix", default="VPN")
    args = parser.parse_args()
    try:
        network, suffix = installation_settings(args.vpn_subnet, args.login_suffix)
    except ValueError as error:
        parser.error(str(error))
    if not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", args.domain):
        parser.error("invalid ASCII domain; use punycode for international names")
    if not all(1 <= port <= 65535 for port in (args.sstp_port, args.admin_port)):
        parser.error("port out of range")
    address = ipaddress.ip_address(args.public_ip)
    if address.version != 4 or not address.is_global:
        parser.error("public IPv4 address required")
    if args.destination.exists():
        parser.error("destination already exists")
    tokens = {
        "__VPN_DOMAIN__": args.domain,
        "__SSTP_PORT__": str(args.sstp_port),
        "__ADMIN_PORT__": str(args.admin_port),
        "__PUBLIC_IP__": str(address),
    }
    source = args.source.resolve(strict=True)
    args.destination.mkdir(mode=0o700, parents=True)
    for path in sorted(source.rglob("*")):
        if path.is_symlink():
            parser.error(f"symlink not permitted in payload: {path.relative_to(source)}")
        if not path.is_file():
            continue
        relative = path.relative_to(source)
        target = args.destination / relative
        target.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        data = path.read_text(encoding="utf-8").replace("\r\n", "\n")
        data = render_settings(data, network, suffix)
        for token, value in tokens.items():
            data = data.replace(token, value)
        if re.search(r"__(?:VPN_DOMAIN|SSTP_PORT|ADMIN_PORT|PUBLIC_IP)__", data):
            parser.error(f"unresolved token: {relative}")
        if relative.as_posix() == "etc/sstp-accel/accel.conf" and args.ipv6:
            data = data.replace("bind=0.0.0.0\n", "bind=::\n")
        if relative.as_posix() == "etc/nginx/sites-available/sstp-manager" and not args.ipv6:
            data = "\n".join(line for line in data.splitlines() if "listen [::]:" not in line) + "\n"
        if relative.as_posix() == "etc/sysctl.d/90-sstp.conf" and args.ipv6:
            data += "net.ipv6.bindv6only=0\n"
        target.write_text(data, encoding="utf-8", newline="\n")
        executable = relative.parts[:3] == ("usr", "local", "sbin") or relative.parts[:4] == ("etc", "letsencrypt", "renewal-hooks", "deploy")
        target.chmod(0o755 if executable else 0o644)
    print(f"Rendered {len(list(args.destination.rglob('*')))} payload entries.")


if __name__ == "__main__":
    main()
