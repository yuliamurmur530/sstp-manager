#!/usr/bin/env bash
# Public installer core. Use install.sh for the self-contained distribution.
set -Eeuo pipefail
umask 077
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a
readonly ACCEL_COMMIT=048d31cb446879e0d1a1471b4ab99135a92bf289
readonly ACCEL_RELEASE=1.14.0
PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
INSTALL_STAGE=preflight
PRIVATE_WORK=
PAYLOAD_INSTALLED=0
BOOTSTRAP_STARTED=0

say() { printf '\n[%s] %s\n' "$INSTALL_STAGE" "$*"; }
die() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
on_exit() {
    local result=$?
    if (( result != 0 )); then
        printf '\nInstallation stopped at stage: %s (exit %s).\n' "$INSTALL_STAGE" "$result" >&2
        if (( PAYLOAD_INSTALLED )); then
            systemctl disable --now sstp-nft-reconcile.timer sstp-peer-reconcile.timer sstp-cascade.timer \
                sstp-manager-collector.service sstp-manager.service sstp-accel.service sstp-network.service 2>/dev/null || true
            printf 'Partial installation retained for inspection. See /etc/sstp-manager/INSTALLATION_INCOMPLETE.\n' >&2
        fi
        if (( BOOTSTRAP_STARTED )); then
            systemctl stop nginx.service 2>/dev/null || true
        fi
    fi
    if [[ -n "$PRIVATE_WORK" && "$PRIVATE_WORK" == /var/tmp/sstp-installer.* && -d "$PRIVATE_WORK" ]]; then
        rm -rf -- "$PRIVATE_WORK"
    fi
}
trap on_exit EXIT
trap 'exit 130' INT TERM

if [[ ${1:-} == --help ]]; then
    printf '%s\n' \
        'SSTP Manager clean-server installer' \
        'Run as root on Ubuntu 22.04/24.04 or Debian 12/13, using systemd.' \
        'Prompts: domain, SSTP TCP port (443), panel HTTPS port (7444), chosen panel password with confirmation.' \
        'DNS must point directly to this server. Inbound TCP 80 is required for certificates.' \
        'Continuing installation accepts the current Let’s Encrypt Subscriber Agreement:' \
        'https://letsencrypt.org/repository/' \
        'Creates an empty VPN user list and fresh provisioning keys; the administrator chooses the panel password.'
    exit 0
fi
[[ $# == 0 ]] || die 'No command-line parameters are accepted. Run with --help for instructions.'
[[ $EUID == 0 ]] || die 'Run this installer as root (sudo bash install.sh).'
[[ -f "$PACKAGE_DIR/payload/opt/sstp-manager/app.py" && -f "$PACKAGE_DIR/scripts/render.py" ]] || die 'Package is incomplete. Use the self-contained install.sh or the complete repository.'
[[ -f "$PACKAGE_DIR/scripts/ask_admin_password.py" ]] || die 'Password prompt helper is missing from the package.'
[[ -d /run/systemd/system ]] || die 'A full systemd host is required; a normal Docker container is not supported.'
[[ -r /etc/os-release ]] || die 'Cannot identify operating system.'
# shellcheck disable=SC1091
. /etc/os-release
case "$ID:$VERSION_ID" in
    ubuntu:22.04|ubuntu:24.04|debian:12|debian:13) ;;
    *) die 'Supported systems: Ubuntu 22.04/24.04 and Debian 12/13.' ;;
esac
[[ $(uname -m) == x86_64 || $(uname -m) == aarch64 ]] || die 'This package supports x86_64 and aarch64 hosts.'
exec 9>/run/lock/sstp-installer.lock
flock -n 9 || die 'Another copy of the installer is already running.'
[[ -r /dev/tty ]] || die 'An interactive SSH terminal is needed for the installation settings and hidden password entry.'

printf '%s\n' 'SSTP Manager — empty installation with local VPN accounts.' \
    'A public certificate will be requested automatically without an email address.' \
    'Continuing accepts the current Let’s Encrypt Subscriber Agreement:' \
    'https://letsencrypt.org/repository/'
read -r -p 'Домен (например, vpn.example.org): ' VPN_DOMAIN </dev/tty
VPN_DOMAIN=${VPN_DOMAIN,,}
VPN_DOMAIN=${VPN_DOMAIN%.}
read -r -p 'TCP-порт SSTP [443]: ' SSTP_PORT </dev/tty
SSTP_PORT=${SSTP_PORT:-443}
read -r -p 'HTTPS-порт админ-панели [7444]: ' ADMIN_PORT </dev/tty
ADMIN_PORT=${ADMIN_PORT:-7444}
[[ "$VPN_DOMAIN" =~ ^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$ && ${#VPN_DOMAIN} -le 253 ]] || die 'Enter a domain without scheme, path or port; international domains must use punycode.'
for selected_port in "$SSTP_PORT" "$ADMIN_PORT"; do
    [[ "$selected_port" =~ ^[0-9]{1,5}$ ]] || die 'Ports must be integers from 1 to 65535.'
    (( 10#$selected_port >= 1 && 10#$selected_port <= 65535 )) || die 'Port outside 1–65535.'
done
SSTP_PORT=$((10#$SSTP_PORT))
ADMIN_PORT=$((10#$ADMIN_PORT))
[[ "$SSTP_PORT" != "$ADMIN_PORT" ]] || die 'SSTP and administration need different TCP ports.'
for selected_port in "$SSTP_PORT" "$ADMIN_PORT"; do
    case "$selected_port" in 22|80|2001|5001) die "Port $selected_port is reserved for SSH, certificates or internal services." ;; esac
done

for owned_path in /opt/sstp-manager /opt/sstp-accel /etc/sstp-accel /etc/sstp-manager \
    /etc/sstp.nft /etc/sstp-egress-mode /var/lib/sstp-exit /var/www/sstp-acme \
    /etc/sstp-exit-provisioner.key /etc/sstp-exit-provisioner.key.pub /etc/sstp-exit-known_hosts \
    /etc/wireguard/sstp_exit.conf /etc/wireguard/sstp_exit.key \
    /etc/systemd/system/sstp-network.service /etc/systemd/system/sstp-manager.service \
    /etc/nginx/sites-available/sstp-manager /etc/nginx/sites-enabled/sstp-manager \
    /etc/nginx/sites-available/sstp-acme-bootstrap /etc/nginx/sites-enabled/sstp-acme-bootstrap \
    /etc/letsencrypt/renewal-hooks/deploy/sstp-reload /etc/sysctl.d/90-sstp.conf \
    /etc/modules-load.d/sstp.conf /etc/logrotate.d/sstp-accel; do
    [[ ! -e "$owned_path" && ! -L "$owned_path" ]] || die "Existing installation path: $owned_path. This installer never overwrites an installation."
done
for helper in "$PACKAGE_DIR"/payload/usr/local/sbin/*; do
    [[ ! -e "/usr/local/sbin/${helper##*/}" ]] || die "Existing helper: /usr/local/sbin/${helper##*/}"
done
for unit in "$PACKAGE_DIR"/payload/etc/systemd/system/*; do
    [[ ! -e "/etc/systemd/system/${unit##*/}" && ! -L "/etc/systemd/system/${unit##*/}" ]] || die "Existing unit: ${unit##*/}"
done
[[ ! -d "/etc/letsencrypt/live/$VPN_DOMAIN" && ! -f "/etc/letsencrypt/renewal/$VPN_DOMAIN.conf" ]] || die 'An existing certificate lineage uses this domain.'
if [[ -d /etc/nginx/sites-enabled && -n "$(find /etc/nginx/sites-enabled -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
    die 'An nginx site already exists. Use a clean server; existing websites will not be modified.'
fi
if [[ -d /etc/nginx/conf.d && -n "$(find /etc/nginx/conf.d -maxdepth 1 -type f -name '*.conf' -print -quit)" ]]; then
    die 'Existing nginx conf.d configuration found. Use a clean server.'
fi
for daemon in nginx apache2 caddy ufw firewalld docker nftables; do
    if systemctl is-active --quiet "$daemon.service"; then
        die "Existing active service $daemon conflicts with a clean installation."
    fi
done
if [[ $(systemctl is-enabled nftables.service 2>/dev/null || true) == enabled ]]; then
    die 'An existing nftables boot service is enabled. Use a clean server to preserve its firewall configuration.'
fi

say 'Checking dependencies, kernel and free ports.'
# Inspect existing firewall tools before package installation can start a default
# service. Never treat pre-existing runtime rules as installer-owned state.
if command -v nft >/dev/null && [[ -n "$(nft list ruleset)" ]]; then
    die 'Existing nftables rules found. Use a clean server; firewall policy will not be replaced.'
fi
for save_command in iptables-save ip6tables-save; do
    if command -v "$save_command" >/dev/null && "$save_command" | grep -Eq '^-A |^:[^ ]+ (DROP|REJECT) |^-P .+ (DROP|REJECT)$'; then
        die 'Existing iptables rules or restrictive policy found. Use a clean server.'
    fi
done
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl git python3 python3-venv \
    iproute2 nftables iptables kmod openssh-client dnsutils openssl util-linux
# The new package's generic service must not flush our table during a later boot.
# No nftables service was active/enabled before package installation (checked above).
systemctl disable --now nftables.service
for selected_port in 80 2001 5001 "$SSTP_PORT" "$ADMIN_PORT"; do
    [[ -z "$(ss -H -ltn "sport = :$selected_port")" ]] || die "TCP port $selected_port is already in use."
done
for service in ufw firewalld; do
    [[ $(systemctl is-enabled "$service.service" 2>/dev/null || true) != enabled ]] || die "$service is enabled and may override firewall rules after reboot."
done
[[ -z "$(nft list ruleset)" ]] || die 'The host already has nftables rules. Existing firewall policy will not be overwritten.'
for save_command in iptables-save ip6tables-save; do
    if "$save_command" | grep -Eq '^-A |^:[^ ]+ (DROP|REJECT) |^-P .+ (DROP|REJECT)$'; then
        die 'Existing iptables firewall rules conflict with this clean-server installer.'
    fi
done
for kernel_module in ppp_generic ppp_async ppp_mppe nf_tables nf_nat nf_conntrack wireguard; do
    modprobe "$kernel_module" || die "Kernel module $kernel_module is unavailable. Install the provider's full kernel or enable TUN/PPP support."
done
[[ -c /dev/ppp ]] || die '/dev/ppp is unavailable after loading PPP modules.'
python3 - <<'PY'
import os
try:
    descriptor = os.open('/dev/ppp', os.O_RDWR)
    os.close(descriptor)
except OSError as error:
    raise SystemExit(f'PPP device cannot be opened: {error}')
PY

PRIVATE_WORK=$(mktemp -d /var/tmp/sstp-installer.XXXXXXXX)
python3 "$PACKAGE_DIR/scripts/ask_admin_password.py" "$PRIVATE_WORK/admin-password"
PUBLIC_IP=$(curl -4fsS --proto '=https' --tlsv1.2 --connect-timeout 10 --max-time 20 https://api.ipify.org)
export VPN_DOMAIN SSTP_PORT ADMIN_PORT PUBLIC_IP
python3 - "$PRIVATE_WORK" <<'PY'
import ipaddress, json, os, socket, subprocess, sys
from pathlib import Path
work = Path(sys.argv[1])
domain = os.environ['VPN_DOMAIN']
public = ipaddress.ip_address(os.environ['PUBLIC_IP'].strip())
if public.version != 4 or not public.is_global:
    raise SystemExit('Could not determine a public IPv4 address.')
addresses = json.loads(subprocess.check_output(['ip','-j','address','show']))
local4 = {ipaddress.ip_address(a['local']) for i in addresses for a in i['addr_info'] if a['family']=='inet'}
local6 = {ipaddress.ip_address(a['local']) for i in addresses for a in i['addr_info'] if a['family']=='inet6' and a['scope']=='global' and not a.get('tentative',False) and not a.get('dadfailed',False)}
if public not in local4:
    raise SystemExit('Public IPv4 must be assigned directly to this server. Provider NAT is not supported by this package.')
def dns(record):
    response = subprocess.check_output(['dig','+time=4','+tries=2','+short',domain,record], text=True)
    result = set()
    for line in response.splitlines():
        try: result.add(ipaddress.ip_address(line))
        except ValueError: pass
    return result
records4, records6 = dns('A'), dns('AAAA')
if records4 != {public}:
    raise SystemExit(f'DNS A must point only to this server ({public}); received: {sorted(map(str,records4)) or "no A record"}. Disable DNS proxying and wait for propagation.')
if records6 - local6:
    raise SystemExit('DNS AAAA points to another or unavailable IPv6 address. Correct/remove AAAA before installing.')
try:
    probe = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
    probe.bind(('::',0)); probe.close()
    ipv6 = True
except OSError:
    ipv6 = False
if records6 and (not ipv6 or not json.loads(subprocess.check_output(['ip','-6','-j','route','show','default']))):
    raise SystemExit('DNS AAAA exists but usable IPv6 connectivity is unavailable.')
routes = json.loads(subprocess.check_output(['ip','-4','-j','route','show','table','all']))
reserved_networks = [ipaddress.ip_network('10.77.0.0/24'), ipaddress.ip_network('10.78.0.0/30')]
for route in routes:
    dst = route.get('dst','default')
    if dst == 'default': continue
    try: network = ipaddress.ip_network(dst,strict=False)
    except ValueError: continue
    if any(network.overlaps(owned) for owned in reserved_networks):
        raise SystemExit(f'Existing network {network} overlaps an installation subnet.')
rules = json.loads(subprocess.check_output(['ip','-4','-j','rule','show']))
if any(r.get('priority') in {10170,10171,10172,10173,10178} for r in rules):
    raise SystemExit('Reserved SSTP policy-routing priority already exists.')
(work/'ipv6').write_text('1' if ipv6 else '0')
ssh_ports = {22}
if Path('/usr/sbin/sshd').exists():
    result = subprocess.run(['/usr/sbin/sshd','-T'],capture_output=True,text=True)
    if result.returncode == 0:
        ssh_ports |= {int(line.split()[1]) for line in result.stdout.splitlines() if line.startswith('port ')}
selected = {int(os.environ['SSTP_PORT']), int(os.environ['ADMIN_PORT'])}
if selected & ssh_ports:
    raise SystemExit('A selected port is configured for SSH.')
reserved = sorted(ssh_ports | selected | {80,2001,5001})
(work/'reserved-ports.json').write_text(json.dumps(reserved)+'\n')
print(f'DNS verified: {domain} -> {public}. SSH ports: {sorted(ssh_ports)}')
PY
IPV6_ENABLED=$(<"$PRIVATE_WORK/ipv6")

INSTALL_STAGE=build
say "Building official Accel-PPP $ACCEL_RELEASE, commit $ACCEL_COMMIT."
apt-get install -y --no-install-recommends build-essential cmake libssl-dev libpcre2-dev \
    libnl-3-dev libnl-genl-3-dev libnl-route-3-dev linux-libc-dev wireguard-tools \
    logrotate certbot
git init -q "$PRIVATE_WORK/accel-source"
git -C "$PRIVATE_WORK/accel-source" remote add origin https://github.com/accel-ppp/accel-ppp.git
git -C "$PRIVATE_WORK/accel-source" -c advice.detachedHead=false fetch --depth 1 origin "$ACCEL_COMMIT"
git -C "$PRIVATE_WORK/accel-source" -c advice.detachedHead=false checkout --detach FETCH_HEAD
[[ $(git -C "$PRIVATE_WORK/accel-source" rev-parse HEAD) == "$ACCEL_COMMIT" ]] || die 'Upstream checkout does not match the pinned commit.'
cmake -S "$PRIVATE_WORK/accel-source" -B "$PRIVATE_WORK/accel-build" \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/opt/sstp-accel \
    -DCMAKE_INSTALL_LIBDIR=lib -DLIB_SUFFIX= -DRADIUS=FALSE -DSHAPER=FALSE \
    -DBUILD_IPOE_DRIVER=FALSE -DBUILD_VLAN_MON_DRIVER=FALSE -DBUILD_PPTP_DRIVER=FALSE \
    -DNETSNMP=FALSE -DLOG_PGSQL=FALSE
# Limit parallel build memory use on small VPS instances.
BUILD_JOBS=$(nproc)
(( BUILD_JOBS <= 2 )) || BUILD_JOBS=2
cmake --build "$PRIVATE_WORK/accel-build" --parallel "$BUILD_JOBS"
DESTDIR="$PRIVATE_WORK/compiled" cmake --install "$PRIVATE_WORK/accel-build"
# Upstream's example configuration contains unrelated protocols and is not used.
rm -f -- "$PRIVATE_WORK/compiled/opt/sstp-accel/etc/accel-ppp.conf.dist"
[[ -x "$PRIVATE_WORK/compiled/opt/sstp-accel/sbin/accel-pppd" ]] || die 'The compiled SSTP daemon was not produced.'
[[ -x "$PRIVATE_WORK/compiled/opt/sstp-accel/bin/accel-cmd" ]] || die 'The compiled control client was not produced.'

INSTALL_STAGE=configure
say 'Creating fresh credentials, empty user storage and service configuration.'
render_arguments=("$PACKAGE_DIR/payload" "$PRIVATE_WORK/rendered" --domain "$VPN_DOMAIN" \
    --sstp-port "$SSTP_PORT" --admin-port "$ADMIN_PORT" --public-ip "$PUBLIC_IP")
[[ "$IPV6_ENABLED" == 0 ]] || render_arguments+=(--ipv6)
python3 "$PACKAGE_DIR/scripts/render.py" "${render_arguments[@]}"
install -d -m 0700 /etc/sstp-manager /etc/sstp-accel /var/lib/sstp-exit /var/log/sstp-accel
printf 'Incomplete installation. Started %s; review service logs before retrying.\n' "$(date -u +%FT%TZ)" > /etc/sstp-manager/INSTALLATION_INCOMPLETE
PAYLOAD_INSTALLED=1
cp -a "$PRIVATE_WORK/compiled/opt/sstp-accel" /opt/sstp-accel
# Only our isolated prefix is copied; upstream system-wide defaults are excluded.
cp -a "$PRIVATE_WORK/rendered/." /
chmod 0700 /etc/sstp-manager /etc/sstp-accel /opt/sstp-manager /var/lib/sstp-exit /var/log/sstp-accel
chmod 0600 /etc/sstp-accel/accel.conf
install -m 0600 /dev/null /etc/sstp-accel/chap-secrets
printf 'direct\n' > /etc/sstp-egress-mode
install -m 0600 "$PRIVATE_WORK/reserved-ports.json" /etc/sstp-manager/reserved-ports.json
install -d -m 0700 /etc/wireguard
ssh-keygen -q -t ed25519 -N '' -C 'sstp-exit-provisioner' -f /etc/sstp-exit-provisioner.key
chmod 0600 /etc/sstp-exit-provisioner.key
chmod 0644 /etc/sstp-exit-provisioner.key.pub
install -m 0600 /dev/null /etc/sstp-exit-known_hosts
python3 - "$PRIVATE_WORK/admin-password" <<'PY'
import json, os, secrets, sys, time
from pathlib import Path
admin = Path('/opt/sstp-manager')
password = Path(sys.argv[1]).read_text(encoding='utf-8').removesuffix('\n')
for filename, value in {'.admin_password':password, '.secret_key':secrets.token_hex(48)}.items():
    target = admin/filename
    target.write_text(value+'\n', encoding='utf-8'); target.chmod(0o600)
empty = {'static-ips.json':{}, 'port-forwards.json':[], 'access-networks.json':[], 'routes.json':[],
         'network-settings.json':{'pool_start':'10.77.0.10','pool_end':'10.77.0.249','nat_enabled':True}}
for name, data in empty.items():
    path = admin/name
    path.write_text(json.dumps(data)+'\n'); path.chmod(0o600)
state = Path('/var/lib/sstp-exit/provision.json')
state.write_text(json.dumps({'job_id':'','stage':'idle','message':'Exit не настроен. Укажите IP нового сервера.','active':False,
                            'requested_ip':'','exit_ip':'','port':0,'updated_at':int(time.time())},ensure_ascii=False)+'\n')
state.chmod(0o600)
credentials = Path('/etc/sstp-manager/credentials.txt')
credentials.write_text(f"Админ-панель: https://{os.environ['VPN_DOMAIN']}:{os.environ['ADMIN_PORT']}/\n"
                       f"Пароль админ-панели: {password}\n"
                       "Вход в панель — только по этому паролю; отдельный логин не нужен.\n\n"
                       f"Сервер SSTP: {os.environ['VPN_DOMAIN']}\nПорт SSTP: {os.environ['SSTP_PORT']}\n"
                       "VPN-пользователей пока нет. Создайте первую запись в панели.\n"
                       "Каскад выключен; выход в интернет напрямую.\n"
                       "Публичный ключ для будущего exit: /etc/sstp-exit-provisioner.key.pub\n", encoding='utf-8')
credentials.chmod(0o600)
PY
rm -f -- "$PRIVATE_WORK/admin-password"
python3 -m venv /opt/sstp-manager/.venv
/opt/sstp-manager/.venv/bin/python -m pip install --disable-pip-version-check --no-cache-dir -r "$PACKAGE_DIR/requirements.txt"
/opt/sstp-manager/.venv/bin/python -m compileall -q /opt/sstp-manager/app.py /opt/sstp-manager/accel_backend.py /opt/sstp-manager/collector.py

INSTALL_STAGE=certificate
say 'Issuing a public certificate; inbound TCP 80 must be reachable through the provider firewall.'
apt-get install -y --no-install-recommends nginx
systemctl stop nginx.service
# The only default site allowed here is the one just created by this package install.
if [[ -L /etc/nginx/sites-enabled/default && $(readlink -f /etc/nginx/sites-enabled/default) == /etc/nginx/sites-available/default ]]; then
    unlink /etc/nginx/sites-enabled/default
fi
install -d -m 0755 /var/www/sstp-acme/.well-known/acme-challenge
cat > /etc/nginx/sites-available/sstp-acme-bootstrap <<EOF
server {
    listen 80;
    server_name $VPN_DOMAIN;
    location ^~ /.well-known/acme-challenge/ { root /var/www/sstp-acme; default_type text/plain; try_files \$uri =404; }
    location / { return 404; }
}
EOF
if [[ "$IPV6_ENABLED" == 1 ]]; then
    sed -i '/listen 80;/a\    listen [::]:80;' /etc/nginx/sites-available/sstp-acme-bootstrap
fi
chmod 0644 /etc/nginx/sites-available/sstp-acme-bootstrap
ln -s /etc/nginx/sites-available/sstp-acme-bootstrap /etc/nginx/sites-enabled/sstp-acme-bootstrap
nginx -t
systemctl enable --now nginx.service
BOOTSTRAP_STARTED=1
certbot certonly --webroot -w /var/www/sstp-acme -d "$VPN_DOMAIN" --cert-name "$VPN_DOMAIN" \
    --non-interactive --agree-tos --register-unsafely-without-email --key-type rsa --rsa-key-size 2048
openssl x509 -in "/etc/letsencrypt/live/$VPN_DOMAIN/fullchain.pem" -checkend 86400 -noout
unlink /etc/nginx/sites-enabled/sstp-acme-bootstrap
rm -f -- /etc/nginx/sites-available/sstp-acme-bootstrap
ln -s /etc/nginx/sites-available/sstp-manager /etc/nginx/sites-enabled/sstp-manager
nginx -t

INSTALL_STAGE=start
say 'Starting network rules, SSTP, panel, traffic collector and automatic certificate renewal.'
systemctl daemon-reload
systemctl mask wg-quick@sstp_exit.service
systemctl enable --now sstp-network.service sstp-accel.service sstp-manager.service sstp-manager-collector.service
systemctl disable --now sstp-cascade.timer
systemctl enable --now sstp-nft-reconcile.timer sstp-peer-reconcile.timer certbot.timer
systemctl reload nginx.service
BOOTSTRAP_STARTED=0

INSTALL_STAGE=verify
say 'Checking TLS certificates, local panel response, VPN listener and empty account state.'
python3 - <<'PY'
import http.client, json, os, socket, ssl, subprocess, time
from pathlib import Path
domain = os.environ['VPN_DOMAIN']
ports = [int(os.environ['SSTP_PORT']),int(os.environ['ADMIN_PORT'])]
context = ssl.create_default_context()
for port in ports:
    for attempt in range(30):
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=3) as raw:
                with context.wrap_socket(raw,server_hostname=domain) as secured:
                    if port == ports[1]:
                        secured.sendall(f'GET /login HTTP/1.1\r\nHost: {domain}:{port}\r\nConnection: close\r\n\r\n'.encode())
                        response = http.client.HTTPResponse(secured); response.begin()
                        if response.status != 200: raise RuntimeError(f'Panel HTTP {response.status}')
            break
        except (OSError,RuntimeError):
            if attempt == 29: raise
            time.sleep(1)
subprocess.run(['/opt/sstp-accel/bin/accel-cmd','-H','127.0.0.1','-p','2001','show','stat'],check=True,timeout=10)
assert not Path('/etc/sstp-accel/chap-secrets').read_text().strip(), 'VPN accounts unexpectedly exist'
assert Path('/etc/sstp-egress-mode').read_text().strip() == 'direct'
status = json.loads(subprocess.check_output(['/usr/local/sbin/sstp-cascade-exit','status'],timeout=20))
assert not status.get('enabled') and not status.get('exit_ip'), 'Cascade must start unconfigured'
PY
for checked_unit in sstp-network.service sstp-accel.service sstp-manager.service sstp-manager-collector.service nginx.service; do
    systemctl is-active --quiet "$checked_unit" || die "Service failed: $checked_unit"
done
rm -f -- /etc/sstp-manager/INSTALLATION_INCOMPLETE
INSTALL_STAGE=complete
say 'Установка завершена. Сохраните данные входа; не публикуйте этот вывод:'
cat /etc/sstp-manager/credentials.txt
printf '\n%s\n' \
    'No VPN users were imported. Create the first VPN account in the panel.' \
    'For an exit server, add the following public key to its root authorized_keys first.' \
    'Then enter its public IPv4 in the panel; Ubuntu/Debian root SSH on port 22 is required:'
cat /etc/sstp-exit-provisioner.key.pub
printf '\n%s\n' 'Credentials are stored root-only at /etc/sstp-manager/credentials.txt.' \
    'Certificate renewal is automatic. A renewed certificate reconnects active SSTP sessions once.'
