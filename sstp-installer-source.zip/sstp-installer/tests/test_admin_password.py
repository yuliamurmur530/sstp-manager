"""Chosen-password flow, with synthetic input and no terminal/network side effects."""
import importlib.util
import io
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('ask_admin_password', ROOT / 'scripts/ask_admin_password.py')
PASSWORD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PASSWORD)


class PasswordTests(unittest.TestCase):
    def test_printable_unicode_and_shell_characters_are_literal(self):
        for value in ('Synthetic-pass-42', 'Длинная тестовая фраза 42', '''NotExecuted$(date)!"'\\;#'''):
            with self.subTest(value=value):
                self.assertEqual(PASSWORD.validation_error(value), '')

    def test_invalid_passwords_are_rejected(self):
        for value in ('', 'short', 'x' * 129, ' Synthetic-pass-42', 'Synthetic-pass-42 ',
                      'Synthetic\npass-42', 'Synthetic\tpass-42', 'Synthetic\x1bpass-42', 'Synthetic\u200bpass-42'):
            with self.subTest(value=value):
                self.assertTrue(PASSWORD.validation_error(value))

    def test_confirmation_and_retries_do_not_echo_secret(self):
        chosen = 'Synthetic-pass-42'
        entries = iter(['short', chosen, 'Nonmatching-pass', chosen, chosen])
        terminal = io.StringIO()
        value = PASSWORD.choose_password(terminal, reader=lambda *args, **kwargs: next(entries))
        self.assertEqual(value, chosen)
        self.assertIn('не совпали', terminal.getvalue())
        self.assertNotIn(chosen, terminal.getvalue())
        self.assertNotIn('Nonmatching-pass', terminal.getvalue())

    def test_store_is_utf8_and_owner_only_on_unix(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'password-stage'
            value = 'Длинная тестовая фраза 42'
            PASSWORD.store_password(path, value)
            self.assertEqual(path.read_text(encoding='utf-8'), value + '\n')
            if os.name != 'nt':
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)

    def test_existing_secret_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'password-stage'
            path.write_text('keep', encoding='utf-8')
            with self.assertRaises(FileExistsError):
                PASSWORD.store_password(path, 'Synthetic-pass-42')
            self.assertEqual(path.read_text(encoding='utf-8'), 'keep')

    def test_failed_write_removes_partial_secret(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'password-stage'
            with patch.object(PASSWORD.os, 'fsync', side_effect=OSError('test failure')):
                with self.assertRaises(OSError):
                    PASSWORD.store_password(path, 'Synthetic-pass-42')
            self.assertFalse(path.exists())

    def test_no_tty_means_no_stdin_password_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'password-stage'
            with patch.object(PASSWORD.sys, 'argv', ['ask_admin_password.py', str(path)]), \
                 patch('builtins.open', side_effect=OSError('no tty')), \
                 patch.object(PASSWORD, 'choose_password') as choose, \
                 patch.object(PASSWORD.sys, 'stderr', io.StringIO()):
                self.assertEqual(PASSWORD.main(), 1)
                choose.assert_not_called()
            self.assertFalse(path.exists())


if __name__ == '__main__':
    unittest.main()
