"""Askpass execution contract; no SSH connections or real credentials."""
import io
import os
from pathlib import Path
import runpy
import sys
import types
import unittest
from unittest.mock import MagicMock, Mock, patch

try:
    import fcntl
except ImportError:
    sys.modules['fcntl'] = types.SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *a: None)

TARGET = Path(os.environ.get('SSTP_ASKPASS_TEST_CONTROLLER') or
              Path(__file__).resolve().parents[1] / 'payload/usr/local/sbin/sstp-cascade-exit')
SOURCE = runpy.run_path(str(TARGET), run_name='askpass_test')
G = SOURCE['main'].__globals__
JOB = '0123456789ab'


class AskpassTests(unittest.TestCase):
    def invoke(self, auth, prompt, secret='fixture-$-пароль-with-spaces', failure=None):
        path = MagicMock()
        path.__truediv__.return_value.read_text.return_value = secret
        loader = Mock(return_value=({'ssh_auth': auth}, path), side_effect=failure)
        out, err = io.StringIO(), io.StringIO()
        with patch.dict(G, {'require_root': lambda: None, 'disable_core_dumps': lambda: None,
                            'load_credentials': loader, 'run': Mock(side_effect=AssertionError('network forbidden'))}), \
             patch.dict(os.environ, {'SSTP_SSH_ASKPASS_JOB': JOB}), \
             patch.object(sys, 'stdout', out), patch.object(sys, 'stderr', err):
            result = G['main']([str(TARGET), prompt])
        return result, out.getvalue(), err.getvalue(), loader

    def test_password_is_exact_utf8_plus_newline(self):
        result, out, err, loader = self.invoke('password', "root@example.com's password:")
        self.assertEqual((result, out, err), (0, 'fixture-$-пароль-with-spaces\n', ''))
        loader.assert_called_once_with(JOB)

    def test_encrypted_key_passphrase(self):
        result, out, err, _ = self.invoke('key', 'Enter passphrase for key:', 'fixture phrase')
        self.assertEqual((result, out, err), (0, 'fixture phrase\n', ''))

    def test_wrong_prompts_and_saved_mode_fail_silently(self):
        for auth, prompt in [('saved', 'Password:'), ('password', 'Enter OTP:'),
                             ('key', 'Password:'), ('password', 'Enter passphrase:')]:
            with self.subTest(auth=auth, prompt=prompt):
                result, out, err, _ = self.invoke(auth, prompt)
                self.assertEqual((result, out, err), (1, '', ''))

    def test_missing_or_unsafe_credentials_fail_silently(self):
        result, out, err, _ = self.invoke('password', 'Password:', failure=ValueError('private-detail'))
        self.assertEqual((result, out, err), (1, '', ''))

    def test_askpass_program_not_on_temporary_run_mount(self):
        path = Path('/run/example-credentials') / JOB
        with patch.dict(G, {'KNOWN_HOSTS': Path('/example/known_hosts')}):
            args, env = G['supplied_ssh']('8.8.8.8', {'ssh_auth': 'password', 'ssh_port': 22}, path)
        self.assertEqual(env['SSH_ASKPASS'], os.path.realpath(TARGET))
        self.assertNotEqual(env['SSH_ASKPASS'], str(path / 'askpass'))
        self.assertEqual(env['SSTP_SSH_ASKPASS_JOB'], JOB)
        self.assertEqual(env['SSH_ASKPASS_REQUIRE'], 'force')


if __name__ == '__main__':
    unittest.main()
