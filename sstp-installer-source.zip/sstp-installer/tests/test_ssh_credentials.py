"""Isolated credential handling tests. All SSH, systemd and VPN actions are mocked."""
import contextlib
import io
import json
import os
from pathlib import Path
import runpy
import stat
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

try:
    import fcntl
except ImportError:
    sys.modules['fcntl'] = types.SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *a: None)
CONTROLLER = Path(__file__).resolve().parents[1] / 'payload/usr/local/sbin/sstp-cascade-exit'
SOURCE = runpy.run_path(str(CONTROLLER), run_name='test_controller')
G = SOURCE['start'].__globals__
JOB = '0123456789ab'
ADDRESS = '8.8.8.8'
PASSWORD = 'fixture-$password-"-with-quotes'
PASSPHRASE = 'fixture-encrypted-key-passphrase'
PRIVATE = '-----BEGIN ' + 'OPENSSH PRIVATE KEY-----\nYWJjZGVm\n-----END ' + 'OPENSSH PRIVATE KEY-----\n'
PUBLIC = 'ssh-ed25519 ' + 'A' * 60
OK = subprocess.CompletedProcess([], 0, '', '')


class CredentialControllerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='sstp-credentials-test-')
        self.root = Path(self.temporary.name)
        self.check_path_original = G['check_private_path']
        self.patch = patch.dict(G, {
            'STATE_DIR': self.root / 'state', 'STATE_FILE': self.root / 'state/provision.json',
            'PORTS_FILE': self.root / 'state/ssh-ports.json',
            'CREDENTIAL_ROOT': self.root / 'credentials', 'WG_CONF': self.root / 'wg.conf',
            'LOCK_FILE': self.root / 'provision.lock',
            'SSH_KEY': self.root / 'shared-key', 'KNOWN_HOSTS': self.root / 'known-hosts',
            'require_root': lambda: None, 'check_private_path': lambda *a, **kw: None,
            'operation_lock': lambda **kw: contextlib.nullcontext(),
            'ensure_local_key': lambda: None,
            'run': Mock(side_effect=AssertionError('unexpected system command')),
        })
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.temporary.cleanup()

    def options(self, auth='password'):
        return G['validate_credentials']({
            'ssh_auth': auth, 'ssh_port': 2222,
            'ssh_password': PASSWORD if auth == 'password' else '',
            'ssh_private_key': PRIVATE if auth == 'key' else '',
            'ssh_key_passphrase': PASSPHRASE if auth == 'key' else '',
        })

    def status(self):
        return {'exit_ip': '', 'healthy': False, 'mode': 'direct', 'available': False, 'direct_ip': '9.9.9.9'}

    def test_validation_limits_and_selected_fields(self):
        self.assertEqual(self.options()['ssh_port'], 2222)
        self.assertEqual(self.options('key')['ssh_private_key'], PRIVATE)
        for invalid in (
            {'ssh_auth': []}, {'ssh_port': True}, {'ssh_port': '22\n'}, {'ssh_port': 0},
            {'ssh_port': 65536}, {'ssh_auth': 'password', 'ssh_password': ''},
            {'ssh_auth': 'password', 'ssh_password': 'a\x1bsecret'},
            {'ssh_auth': 'password', 'ssh_password': 'a' * 4097},
            {'ssh_auth': 'saved', 'ssh_password': PASSWORD},
            {'ssh_auth': 'key', 'ssh_private_key': 'bad key'},
            {'ssh_auth': 'key', 'ssh_private_key': PRIVATE, 'ssh_password': PASSWORD},
        ):
            with self.subTest(invalid_type=list(invalid)):
                with self.assertRaises(G['ProvisionError']):
                    G['validate_credentials'](invalid)

    def test_root_and_private_path_checks(self):
        with patch.object(os, 'geteuid', return_value=1000, create=True):
            with self.assertRaises(G['ProvisionError']):
                SOURCE['require_root']()
        for mode, uid in ((stat.S_IFLNK | 0o600, 0), (stat.S_IFREG | 0o644, 0), (stat.S_IFREG | 0o600, 1000)):
            fake = Mock()
            fake.lstat.return_value = types.SimpleNamespace(st_mode=mode, st_uid=uid)
            with self.assertRaises(G['ProvisionError']):
                self.check_path_original(fake)

    @unittest.skipUnless(os.name == 'posix' and getattr(os, 'geteuid', lambda: -1)() == 0,
                         'Actual root ownership/modes require a Linux root test process')
    def test_linux_root_credential_permissions(self):
        with patch.dict(G, {'require_root': SOURCE['require_root'],
                            'check_private_path': self.check_path_original}):
            path = G['stage_credentials'](JOB, self.options('key'))
            try:
                for directory in (G['CREDENTIAL_ROOT'], path):
                    self.assertEqual(directory.stat().st_uid, 0)
                    self.assertEqual(stat.S_IMODE(directory.stat().st_mode), 0o700)
                for filename in ('auth.json', 'secret', 'private-key'):
                    self.assertEqual((path / filename).stat().st_uid, 0)
                    self.assertEqual(stat.S_IMODE((path / filename).stat().st_mode), 0o600)
                self.assertEqual(stat.S_IMODE((path / 'askpass').stat().st_mode), 0o700)
            finally:
                G['cleanup_credentials'](JOB)
            self.assertFalse(path.exists())

    def test_key_and_password_stay_out_of_command_environment_and_state(self):
        for auth in ('password', 'key'):
            options = self.options(auth)
            path = G['stage_credentials'](JOB, options)
            metadata = (path / 'auth.json').read_text()
            self.assertEqual(set(json.loads(metadata)), {'ssh_auth', 'ssh_port'})
            args, environment = G['supplied_ssh'](ADDRESS, options, path)
            exposed = json.dumps([args, environment, G['read_json'](), metadata])
            for secret in (PASSWORD, PASSPHRASE, PRIVATE):
                self.assertNotIn(secret, exposed)
            self.assertEqual(environment['SSH_ASKPASS_REQUIRE'], 'force')
            self.assertIn('StrictHostKeyChecking=accept-new', args)
            if auth == 'password':
                self.assertIn('PubkeyAuthentication=no', args)
            else:
                self.assertIn(str(path / 'private-key'), args)
                self.assertEqual((path / 'secret').read_text(), PASSPHRASE)
            G['cleanup_credentials'](JOB)
            self.assertFalse(path.exists())

    def test_bootstrap_uses_only_public_key_then_saved_key_and_cleans(self):
        options = self.options('key')
        path = G['stage_credentials'](JOB, options)
        G['update_state'](JOB, 'queued', 'queued')
        commands = []
        def command(args, **kwargs):
            commands.append((args, kwargs))
            if args[0] == 'ssh-keygen': return subprocess.CompletedProcess(args, 0, PUBLIC + '\n', '')
            if kwargs.get('input_text') == G['BOOTSTRAP_PUBLIC_KEY']:
                return subprocess.CompletedProcess(args, 0, 'BOOTSTRAP_READY\n', '')
            return subprocess.CompletedProcess(args, 0, 'ubuntu\n', '')
        with patch.dict(G, {'run': command}):
            G['authenticate_job'](ADDRESS, JOB)
        self.assertEqual(len(commands), 3)
        self.assertIn(str(path / 'private-key'), commands[1][0])
        self.assertIn(str(G['SSH_KEY']), commands[2][0])
        self.assertNotIn('env', commands[2][1])
        for secret in (PASSWORD, PASSPHRASE, PRIVATE):
            self.assertNotIn(secret, json.dumps(commands))
            self.assertNotIn(secret, json.dumps(G['read_json']()))
        self.assertEqual(json.loads(G['PORTS_FILE'].read_text()), {ADDRESS: 2222})
        self.assertFalse(path.exists())
        self.assertEqual(G['ssh_base'](ADDRESS)[2], '2222')

    def test_bootstrap_error_does_not_reflect_server_secrets_or_control_codes(self):
        G['stage_credentials'](JOB, self.options())
        G['update_state'](JOB, 'queued', 'queued')
        def command(args, **kwargs):
            if args[0] == 'ssh-keygen': return subprocess.CompletedProcess(args, 0, PUBLIC + '\n', '')
            return subprocess.CompletedProcess(args, 255, '', 'Permission denied ' + PASSWORD + '\x1b[2J')
        with patch.dict(G, {'run': command}):
            with self.assertRaises(G['ProvisionError']) as caught:
                G['authenticate_job'](ADDRESS, JOB)
        self.assertNotIn(PASSWORD, str(caught.exception))
        self.assertNotIn('\x1b', str(caught.exception))
        self.assertFalse(G['PORTS_FILE'].exists())

    def test_saved_auth_requires_no_bootstrap(self):
        G['stage_credentials'](JOB, self.options('saved'))
        commands = []
        def command(args, **kwargs):
            commands.append(args)
            return subprocess.CompletedProcess(args, 0, 'debian\n', '')
        with patch.dict(G, {'run': command}):
            G['authenticate_job'](ADDRESS, JOB)
        self.assertEqual(len(commands), 1)
        self.assertEqual(commands[0][0], 'ssh')
        self.assertIn(str(G['SSH_KEY']), commands[0])

    def test_enqueue_is_nonblocking_and_registers_cleanup(self):
        forbidden = Mock(side_effect=AssertionError('must not provision during enqueue'))
        launch = Mock(return_value=OK)
        with patch.dict(G, {'status_payload': self.status, 'run': launch, 'do_provision': forbidden, 'authenticate_job': forbidden}):
            result = G['start'](ADDRESS, self.options())
        args = launch.call_args.args[0]
        self.assertIn('--no-block', args)
        self.assertTrue(any('ExecStopPost=' in item and '_cleanup-credentials' in item for item in args))
        self.assertIn('--property=RuntimeDirectoryMode=0700', args)
        self.assertIn('--property=RuntimeDirectoryPreserve=no', args)
        self.assertIn('--property=LimitCORE=0', args)
        self.assertNotIn(PASSWORD, json.dumps(args))
        self.assertNotIn(PASSWORD, json.dumps(G['read_json']()))
        self.assertTrue((G['CREDENTIAL_ROOT'] / result['job_id']).exists())
        forbidden.assert_not_called()

    def test_main_disables_core_before_reading_credentials(self):
        events = []
        with patch.dict(G, {
            'disable_core_dumps': lambda: events.append('no-core'),
            'read_credentials_input': lambda: events.append('input') or self.options(),
            'start': Mock(return_value={'success': True}),
        }), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(G['main'](['controller', 'start', ADDRESS]), 0)
        self.assertEqual(events, ['no-core', 'input'])

    def test_launch_rejection_cleans_but_uncertain_timeout_keeps_credentials(self):
        with patch.dict(G, {'status_payload': self.status, 'run': Mock(return_value=subprocess.CompletedProcess([], 1, '', 'Bus refused'))}):
            with self.assertRaises(G['ProvisionError']):
                G['start'](ADDRESS, self.options())
        self.assertEqual(list(G['CREDENTIAL_ROOT'].iterdir()), [])
        with patch.dict(G, {'status_payload': self.status, 'run': Mock(side_effect=subprocess.TimeoutExpired('systemd-run', 8))}):
            result = G['start'](ADDRESS, self.options())
        self.assertFalse(result['launch_confirmed'])
        self.assertTrue((G['CREDENTIAL_ROOT'] / result['job_id']).exists())

    def test_busy_job_not_clobbered_by_healthy_endpoint_fastpath(self):
        G['update_state'](JOB, 'checking_ssh', 'busy')
        original = G['read_json']()
        with patch.dict(G, {'status_payload': lambda: {'exit_ip': ADDRESS, 'healthy': True, 'direct_ip': '9.9.9.9'}}):
            with self.assertRaises(G['ProvisionError']):
                G['start'](ADDRESS, self.options())
        self.assertEqual(G['read_json'](), original)
        self.assertFalse(G['CREDENTIAL_ROOT'].exists())

    def test_auth_failure_does_not_reapply_local_network_or_install(self):
        G['update_state'](JOB, 'queued', 'queued')
        forbidden = Mock(side_effect=AssertionError('network/setup must not change on auth rejection'))
        with patch.dict(G, {
            'endpoint_from_config': lambda: ('', 0), 'read_mode': lambda: 'direct',
            'authenticate_job': Mock(side_effect=G['ProvisionError']('SSH rejected')),
            'restore_target': forbidden, 'activate_cascade': forbidden, 'activate_direct': forbidden,
            'remote_run': forbidden, 'configure_target': forbidden,
        }):
            with self.assertRaises(G['ProvisionError']):
                G['do_provision'](ADDRESS, JOB)
        forbidden.assert_not_called()

    def test_worker_failure_finally_removes_transient_secret(self):
        path = G['stage_credentials'](JOB, self.options('key'))
        with patch.dict(G, {'do_provision': Mock(side_effect=G['ProvisionError']('fixture worker failed'))}), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(G['main'](['controller', '_run', ADDRESS, JOB]), 1)
        self.assertFalse(path.exists())

    def test_stale_worker_cannot_overwrite_current_job_or_change_network(self):
        current_job = 'abcdef012345'
        G['update_state'](current_job, 'queued', 'current job')
        original = G['read_json']()
        forbidden = Mock(side_effect=AssertionError('stale worker must not change network'))
        with patch.dict(G, {'activate_direct': forbidden, 'activate_cascade': forbidden}), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(G['main'](['controller', '_run', ADDRESS, JOB]), 1)
            self.assertEqual(G['main'](['controller', '_mode', 'off', JOB]), 1)
            with self.assertRaises(G['ProvisionError']):
                G['set_mode']('off')
        forbidden.assert_not_called()
        self.assertEqual(G['read_json'](), original)

    def test_cleanup_rejects_traversal_and_unknown_directory_content(self):
        with self.assertRaises(G['ProvisionError']): G['cleanup_credentials']('../outside')
        path = G['stage_credentials'](JOB, self.options())
        (path / 'unexpected').write_text('preserve')
        with self.assertRaises(G['ProvisionError']): G['cleanup_credentials'](JOB)
        self.assertTrue((path / 'unexpected').exists())

    def test_stale_secret_cleanup_requires_known_stopped_unit_without_job(self):
        path = G['stage_credentials'](JOB, self.options())
        os.utime(path, (1, 1))
        for output, code in [('LoadState=loaded\nActiveState=active\nJob=\n', 0),
                             ('LoadState=loaded\nActiveState=inactive\nJob=1\n', 0), ('', 1)]:
            with patch.dict(G, {'run': Mock(return_value=subprocess.CompletedProcess([], code, output, ''))}):
                G['reap_stale_credentials']()
            self.assertTrue(path.exists())
        with patch.dict(G, {'run': Mock(return_value=subprocess.CompletedProcess([], 0, 'LoadState=not-found\nActiveState=inactive\nJob=\n', ''))}):
            G['reap_stale_credentials']()
        self.assertFalse(path.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)

