"""Custom installation settings: render and pure logic only; no server changes."""
import ast
from contextlib import ExitStack
import importlib.util
import ipaddress
import os
from pathlib import Path
import re
import runpy
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from test_panel import install_windows_fcntl

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('settings_renderer', ROOT / 'scripts/render.py')
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)
BASH = os.environ.get('SSTP_TEST_BASH') or shutil.which('bash')


class SettingsValidationTests(unittest.TestCase):
    def test_private_networks_and_suffix_normalization(self):
        for subnet in ('10.77.0.0/24', '192.168.50.0/24', '172.20.5.0/24'):
            network, suffix = renderer.installation_settings(subnet, 'Office_2')
            self.assertEqual(str(network), subnet)
            self.assertEqual(suffix, 'OFFICE_2')

    def test_invalid_subnet_and_cascade_overlap(self):
        for subnet in ('10.78.0.0/24', '192.168.50.1/24', '192.168.50.0/25',
                       '192.168.0.0/16', str(ipaddress.ip_network('8.8.8.8/24', strict=False)), '127.0.0.0/24', '169.254.1.0/24',
                       '100.64.1.0/24', '::/24', 'bad', '10.77.0.0/24;false'):
            with self.subTest(subnet=subnet), self.assertRaises(ValueError):
                renderer.installation_settings(subnet, 'VPN')

    def test_suffix_cannot_inject_config_shell_or_python(self):
        for suffix in ('', '@VPN', '1VPN', 'A' * 33, 'ВПН', 'A B', 'A;false',
                       'A\nB', 'A"', "A'", 'A$(id)', 'A/../B', 'A\\B', 'VPN\n'):
            with self.subTest(suffix=suffix), self.assertRaises(ValueError):
                renderer.installation_settings('10.77.0.0/24', suffix)

    def test_host_offsets_are_preserved(self):
        network, suffix = renderer.installation_settings('172.20.5.0/24', 'OFFICE')
        source = '10.77.0.0/24 10.77.0.1 10.77.0.10 10.77.0.249 10.77.0.250 10.77.0.253 10.77.0.254 10.77.0.x'
        self.assertEqual(renderer.render_settings(source, network, suffix), source.replace('10.77.0.', '172.20.5.'))


class CustomRenderTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        install_windows_fcntl(self.stack)
        self.scratch = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.destination = self.scratch / 'rendered'

    def render(self, subnet='192.168.50.0/24', suffix='office', domain='vpn.example.com'):
        result = subprocess.run([sys.executable, '-B', str(ROOT / 'scripts/render.py'),
                                 str(ROOT / 'payload'), str(self.destination), '--domain', domain,
                                 '--sstp-port', '443', '--admin-port', '7444', '--public-ip', '1.1.1.1',
                                 '--vpn-subnet', subnet, '--login-suffix', suffix],
                                text=True, capture_output=True, timeout=20)
        return result

    def content(self, relative):
        return (self.destination / relative).read_text(encoding='utf-8')

    def test_entire_rendered_tree_has_no_old_subnet_or_suffix(self):
        result = self.render()
        self.assertEqual(result.returncode, 0, result.stderr)
        for path in self.destination.rglob('*'):
            if path.is_file():
                data = path.read_text(encoding='utf-8')
                self.assertNotIn('10.77.0.', data, str(path))
                self.assertNotIn('@VPN', data, str(path))
                if path.suffix == '.py' or data.startswith('#!/usr/bin/env python3'):
                    ast.parse(data, filename=str(path))
        self.assertIn('gw-ip-address=192.168.50.1', self.content('etc/sstp-accel/accel.conf'))
        app = self.content('opt/sstp-manager/app.py')
        self.assertIn("HUB = 'OFFICE'", app)
        self.assertIn('192.168.50.x', app)
        self.assertIn('@OFFICE', app)
        for helper in ('sstp-route-reconcile', 'sstp-nft-reconcile', 'sstp-nft-apply', 'sstp-cascade-exit', 'sstp-cascade-apply'):
            self.assertIn('192.168.50.0/24', self.content('usr/local/sbin/' + helper), helper)
        cascade = self.content('usr/local/sbin/sstp-cascade-exit')
        self.assertIn('192.168.50.253/32', cascade)
        self.assertIn('192.168.50.254/32', cascade)
        self.assertIn("WG_NETWORK = '10.78.0.0/30'", cascade)

    def test_selected_realm_builds_and_strips_real_login(self):
        self.assertEqual(self.render().returncode, 0)
        with patch('subprocess.run', side_effect=AssertionError('No system commands allowed')):
            backend = runpy.run_path(str(self.destination / 'opt/sstp-manager/accel_backend.py'))
            self.assertEqual(backend['_login_username']('admin'), 'admin@OFFICE')
            self.assertEqual(backend['_display_username']('admin@office'), 'admin')
            with self.assertRaises(backend['BackendError']):
                backend['_login_username']('admin@VPN')

    def test_custom_routes_accept_selected_subnet_not_old_subnet(self):
        self.assertEqual(self.render().returncode, 0)
        with patch('subprocess.run', side_effect=AssertionError('No system commands allowed')):
            helper = runpy.run_path(str(self.destination / 'usr/local/sbin/sstp-route-reconcile'))
            config = [{'cidr': '10.20.1.0/24', 'user': 'router'}]
            sessions = [{'state': 'active', 'ifname': 'sstp0', 'ip': '192.168.50.10'}]
            desired = helper['desired_routes'](config, {'router': '192.168.50.10'}, sessions)
            self.assertEqual(desired, {'10.20.1.0/24': ('192.168.50.10', 'sstp0')})
            with self.assertRaises(ValueError):
                helper['desired_routes'](config, {'router': '10.77.0.10'}, sessions)

    def test_domain_that_contains_default_prefix_is_not_rewritten(self):
        result = self.render(domain='10.77.0.example.org')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('server_name 10.77.0.example.org;', self.content('etc/nginx/sites-available/sstp-manager'))

    def test_invalid_settings_do_not_create_destination(self):
        result = self.render(subnet='10.78.0.0/24')
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(self.destination.exists())

    @unittest.skipUnless(BASH, 'Bash required')
    def test_custom_shell_helpers_have_valid_syntax(self):
        self.assertEqual(self.render(suffix='TEAM_2-A').returncode, 0)
        for path in self.destination.rglob('*'):
            if path.is_file() and path.read_text(encoding='utf-8').startswith('#!/usr/bin/env bash'):
                result = subprocess.run([BASH, '-n', path.as_posix()], capture_output=True, text=True, timeout=10)
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_installer_wires_selected_settings_into_state_and_summary(self):
        core = (ROOT / 'installer.sh').read_text(encoding='utf-8')
        self.assertIn('--vpn-subnet "$VPN_SUBNET" --login-suffix "$LOGIN_SUFFIX"', core)
        self.assertIn("ipaddress.ip_network(os.environ['VPN_SUBNET'])", core)
        self.assertIn("'pool_start':str(network[10]),'pool_end':str(network[249])", core)
        self.assertIn("user@{os.environ['LOGIN_SUFFIX']}", core)
        self.assertIn('VPN_SUBNET=${VPN_SUBNET:-10.77.0.0/24}', core)
        self.assertIn('LOGIN_SUFFIX=${LOGIN_SUFFIX:-VPN}', core)
