import hashlib
import importlib.util
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("make_install_command", ROOT / "tools" / "make_install_command.py")
command_tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(command_tool)
RAW_URL = "https://raw.githubusercontent.com/example/sstp/main/install.sh"
RELEASE_URL = "https://github.com/example/sstp/releases/download/v1.0/install.sh"


def bash_path():
    explicit = os.environ.get("SSTP_TEST_BASH")
    if explicit:
        return explicit
    if os.name != "nt":
        return shutil.which("bash")
    candidate = Path("C:/Program Files/Git/bin/bash.exe")
    return str(candidate) if candidate.is_file() else None


def unix_path(path):
    path = Path(path).resolve()
    if os.name == "nt":
        return "/" + path.drive.rstrip(":").lower() + path.as_posix()[2:]
    return str(path)


class CommandGenerationTests(unittest.TestCase):
    def test_output_is_one_shell_command_with_separate_data_arguments(self):
        digest = "A" * 64
        rendered = command_tool.make_command(RAW_URL, digest)
        self.assertNotIn("\n", rendered)
        parsed = shlex.split(rendered)
        self.assertEqual(parsed[:2], ["bash", "-c"])
        self.assertEqual(parsed[3:], ["sstp-download", RAW_URL, digest.lower()])
        self.assertNotIn(RAW_URL, parsed[2])
        self.assertIn('bash "$payload";', parsed[2])
        self.assertIn("[[ $EUID -eq 0 ]]", parsed[2])
        self.assertIn("(: </dev/tty)", parsed[2])
        self.assertNotIn("| bash", parsed[2])
        self.assertNotIn("|bash", parsed[2])

    def test_url_quoting_keeps_apostrophe_in_single_argument(self):
        url = "https://raw.githubusercontent.com/example/sstp/refs/tags/v'1/install.sh"
        self.assertEqual(shlex.split(command_tool.make_command(url))[-2], url)
        self.assertEqual(command_tool.validate_url(RELEASE_URL), RELEASE_URL)

    def test_rejects_invalid_or_ambiguous_urls(self):
        values = [
            "http://raw.githubusercontent.com/example/sstp/main/install.sh",
            "https://name:secret@example.org/install.sh",
            RAW_URL + "?token=secret", RAW_URL + "#fragment", RAW_URL + "\n",
            "https://raw.githubusercontent.com:443/example/sstp/main/install.sh",
            "https://raw.githubusercontent.com/example/sstp/main/a b/install.sh",
            "https://raw.githubusercontent.com/example/sstp/main/%0a/install.sh",
            "https://raw.githubusercontent.com/example/sstp/../install.sh",
            "https://github.com/example/sstp/blob/main/install.sh",
            "https://unrelated.example.org/install.sh", "file:///tmp/install.sh",
        ]
        for value in values:
            with self.subTest(url=value), self.assertRaises(ValueError):
                command_tool.make_command(value)

    def test_rejects_invalid_digest(self):
        for value in ["123", "G" * 64, "1" * 63, "1" * 64 + "\n"]:
            with self.subTest(digest=value), self.assertRaises(ValueError):
                command_tool.make_command(RAW_URL, value)

    def test_https_only_both_downloaders_and_bounded_download_time(self):
        script = command_tool.wrapper_script()
        self.assertIn("--proto '=https' --proto-redir '=https'", script)
        self.assertIn("--max-time 120", script)
        self.assertIn("timeout 120 wget --https-only", script)
        self.assertIn("apt-get install -y --no-install-recommends ca-certificates curl", script)

    def test_compact_is_single_line_with_quoted_positional_url(self):
        url = "https://raw.githubusercontent.com/example/sstp/refs/tags/v'1/install.sh"
        command = command_tool.make_command(url, compact=True)
        parts = shlex.split(command)
        self.assertNotIn("\n", command)
        self.assertEqual(parts[:2], ["bash", "-c"])
        self.assertEqual(parts[3:], ["sstp-download", url])
        self.assertNotIn(url, parts[2])
        self.assertIn('test -s "$d/install.sh"', parts[2])
        self.assertNotIn("| bash", parts[2])
        self.assertLess(len(command), 900)

    def test_compact_supports_optional_digest(self):
        parts = shlex.split(command_tool.make_command(RAW_URL, "A" * 64, compact=True))
        self.assertEqual(parts[-1], "a" * 64)
        self.assertIn("sha256sum --check --status", parts[2])
        self.assertNotIn("sha256sum", command_tool.compact_script())


@unittest.skipUnless(bash_path(), "Bash unavailable; set SSTP_TEST_BASH for shell integration tests")
class DownloadWrapperTests(unittest.TestCase):
    def setUp(self):
        self.bash = bash_path()
        self.temporary = tempfile.TemporaryDirectory(prefix="sstp launcher test ")
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.bin = self.directory / "fake bin"
        self.bin.mkdir()
        self.fixture = self.directory / "safe fixture.sh"
        self.fixture.write_text("#!/bin/bash\nprintf 'PAYLOAD_MARKER\\n'\n", encoding="utf-8")
        self.env = os.environ.copy()
        self.env.update({
            "PATH": unix_path(self.bin) + ":/usr/bin:/bin",
            "SSTP_MOCKBIN": unix_path(self.bin),
            "SSTP_FIXTURE": unix_path(self.fixture),
            "SSTP_DISPATCH": unix_path(self.directory / "dispatch"),
            "SSTP_ARGS": unix_path(self.directory / "arguments"),
            "SSTP_TEMP_RECORD": unix_path(self.directory / "download-path"),
            "SSTP_FETCHER": "curl",
            "SSTP_FAIL": "0",
            "SSTP_PAYLOAD_EXIT": "0",
        })
        self.mock("mktemp", """dir=$(/usr/bin/mktemp -d --suffix=' with spaces' /tmp/sstp-download.XXXXXXXX)
printf '%s' "$dir" > "$SSTP_TEMP_RECORD"
printf '%s\\n' "$dir"
""")
        self.mock("curl", """printf '%s\\n' "$@" > "$SSTP_ARGS"
out=
while (( $# )); do
  if [[ $1 == --output || $1 == -o ]]; then out=$2; shift 2; else shift; fi
done
if [[ $SSTP_FAIL == 1 ]]; then printf partial > "$out"; exit 22; fi
cp "$SSTP_FIXTURE" "$out"
""")
        self.mock("wget", """printf '%s\\n' "$@" > "$SSTP_ARGS"
for value in "$@"; do if [[ $value == --output-document=* ]]; then out=${value#*=}; fi; done
if [[ $SSTP_FAIL == 1 ]]; then printf partial > "$out"; exit 8; fi
cp "$SSTP_FIXTURE" "$out"
""")
        self.mock("bash", """printf '%s\\n' "$1" > "$SSTP_DISPATCH"
cat "$1" >> "$SSTP_DISPATCH"
exit "$SSTP_PAYLOAD_EXIT"
""")
        self.mock("apt-get", "echo 'Unexpected package installation in test' >&2; exit 91\n")

    def mock(self, name, text):
        path = self.bin / name
        path.write_text("#!/bin/bash\nset -euo pipefail\n" + text, encoding="utf-8", newline="\n")
        path.chmod(0o755)

    def invoke(self, *, url=RAW_URL, digest="", fetcher="curl", failure=False, payload_exit=0, compact=False):
        script = command_tool.compact_script(bool(digest)) if compact else command_tool.wrapper_script()
        # Test only download/dispatch in an unprivileged noninteractive harness.
        # Published output still contains both actual root and terminal guards.
        script = script.replace("[[ $EUID -eq 0 ]]", "true")
        script = script.replace("{ [[ -r /dev/tty ]] && (: </dev/tty); }", "{ true; }")
        script = script.replace(": </dev/tty;", ":;")
        # Git Bash translates inherited Windows PATH. Set the test path inside
        # the shell and refuse to run if a real downloader would be selected.
        prefix = 'export PATH="$SSTP_MOCKBIN:/usr/bin:/bin"; for tool in curl wget mktemp bash apt-get; do [[ $(builtin command -v "$tool") == "$SSTP_MOCKBIN/$tool" ]] || { echo "Mock tool unavailable: $tool" >&2; exit 98; }; done; '
        prefix += "command() { if [[ ${1:-} == -v && ${2:-} == curl && $SSTP_FETCHER == wget ]]; then return 1; fi; builtin command \"$@\"; }; "
        self.env.update({"SSTP_FETCHER":fetcher, "SSTP_FAIL":"1" if failure else "0", "SSTP_PAYLOAD_EXIT":str(payload_exit)})
        # Feed shell source on stdin so the Git Bash Windows launcher cannot
        # reinterpret an apostrophe in a raw Windows positional argument.
        test_source = "set -- " + shlex.join([url, digest]) + "\n" + prefix + script
        result = subprocess.run([self.bash, "-s"], input=test_source, env=self.env, capture_output=True, text=True, timeout=20)
        self.assertTrue((self.directory / "download-path").exists(), result.stdout + result.stderr)
        temporary_path = (self.directory / "download-path").read_text()
        exists = subprocess.run([self.bash, "-c", 'test -e "$1"', "check", temporary_path], capture_output=True)
        self.assertNotEqual(exists.returncode, 0, "Download directory was not cleaned up")
        return result

    def test_successful_curl_download_checksum_and_quoted_url(self):
        url = "https://raw.githubusercontent.com/example/sstp/refs/tags/v'1/install.sh"
        digest = hashlib.sha256(self.fixture.read_bytes()).hexdigest()
        result = self.invoke(url=url, digest=digest)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("PAYLOAD_MARKER", (self.directory / "dispatch").read_text())
        args = (self.directory / "arguments").read_text().splitlines()
        self.assertEqual(args[-1], url)
        self.assertIn("--fail", args)

    def test_http_error_never_executes_partial_download(self):
        result = self.invoke(failure=True)
        self.assertEqual(result.returncode, 22, result.stderr)
        self.assertFalse((self.directory / "dispatch").exists())

    def test_wget_fallback(self):
        result = self.invoke(fetcher="wget")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue((self.directory / "dispatch").exists())
        self.assertIn("--https-only", (self.directory / "arguments").read_text().splitlines())

    def test_wget_error_never_executes_partial_download(self):
        result = self.invoke(fetcher="wget", failure=True)
        self.assertEqual(result.returncode, 8, result.stderr)
        self.assertFalse((self.directory / "dispatch").exists())

    def test_checksum_mismatch_never_executes_payload(self):
        result = self.invoke(digest="0" * 64)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.directory / "dispatch").exists())
        self.assertIn("SHA256 mismatch", result.stderr)

    def test_payload_exit_code_is_preserved_through_cleanup(self):
        result = self.invoke(payload_exit=37)
        self.assertEqual(result.returncode, 37, result.stderr)

    def test_compact_bash_syntax(self):
        for checksum in ["", "b" * 64]:
            command = command_tool.make_command(RAW_URL, checksum, compact=True)
            result = subprocess.run([self.bash, "-n"], input=command, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_compact_success_checksum_quoted_url_and_cleanup(self):
        url = "https://raw.githubusercontent.com/example/sstp/refs/tags/v'1/install.sh"
        digest = hashlib.sha256(self.fixture.read_bytes()).hexdigest()
        result = self.invoke(url=url, digest=digest, compact=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("PAYLOAD_MARKER", (self.directory / "dispatch").read_text())
        self.assertEqual((self.directory / "arguments").read_text().splitlines()[-1], url)

    def test_compact_partial_download_is_never_executed(self):
        result = self.invoke(failure=True, compact=True)
        self.assertEqual(result.returncode, 22, result.stderr)
        self.assertFalse((self.directory / "dispatch").exists())

    def test_compact_empty_download_is_never_executed(self):
        self.fixture.write_bytes(b"")
        result = self.invoke(compact=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.directory / "dispatch").exists())

    def test_compact_checksum_mismatch_is_never_executed(self):
        result = self.invoke(digest="0" * 64, compact=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.directory / "dispatch").exists())

    def test_compact_payload_exit_code_survives_cleanup(self):
        result = self.invoke(payload_exit=37, compact=True)
        self.assertEqual(result.returncode, 37, result.stderr)


if __name__ == "__main__":
    unittest.main()
