"""Render-only and static installation contract checks; never run installer.sh."""
import configparser
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
PAYLOAD = ROOT / "payload"


class RenderChecks(unittest.TestCase):
    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory(prefix="sstp-render-test-")
        self.addCleanup(self.scratch.cleanup)
        self.destination = Path(self.scratch.name) / "rendered"

    def render(self, **options):
        values = {"domain": "vpn.example.com", "sstp-port": "9443", "admin-port": "9444", "public-ip": "1.1.1.1"}
        ipv6 = options.pop("ipv6", False)
        values.update(options)
        command = [sys.executable, "-B", str(ROOT / "scripts/render.py"), str(PAYLOAD), str(self.destination)]
        for name, value in values.items():
            command.extend(["--" + name, str(value)])
        if ipv6:
            command.append("--ipv6")
        return subprocess.run(command, capture_output=True, text=True, timeout=30)

    def test_ipv4_render_substitutes_domain_ports_and_disables_ipv6_listener(self):
        result = self.render()
        self.assertEqual(result.returncode, 0, result.stderr)
        config = (self.destination / "etc/sstp-accel/accel.conf").read_text(encoding="utf-8")
        nginx = (self.destination / "etc/nginx/sites-available/sstp-manager").read_text(encoding="utf-8")
        self.assertIn("bind=0.0.0.0\n", config)
        self.assertIn("port=9443\n", config)
        self.assertIn("/live/vpn.example.com/fullchain.pem", config)
        self.assertIn("9444 ssl", nginx)
        self.assertNotIn("listen [::]:", nginx)
        for path in self.destination.rglob("*"):
            if path.is_file():
                self.assertIsNone(re.search(r"__(?:VPN_DOMAIN|SSTP_PORT|ADMIN_PORT|PUBLIC_IP)__", path.read_text(encoding="utf-8")), str(path.relative_to(self.destination)))

    def test_ipv6_render_preserves_dual_stack_configuration(self):
        result = self.render(ipv6=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        config = (self.destination / "etc/sstp-accel/accel.conf").read_text(encoding="utf-8")
        nginx = (self.destination / "etc/nginx/sites-available/sstp-manager").read_text(encoding="utf-8")
        sysctl = (self.destination / "etc/sysctl.d/90-sstp.conf").read_text(encoding="utf-8")
        self.assertIn("bind=::\n", config)
        self.assertIn("listen [::]:9444 ssl", nginx)
        self.assertIn("net.ipv6.bindv6only=0", sysctl)

    def test_domain_token_cannot_inject_shell_or_config(self):
        for domain in ("example.com;false", "example.com\nport=22", "https://example.com", "../example.com", "example.com:9443"):
            with self.subTest(domain=domain):
                result = self.render(domain=domain)
                self.assertNotEqual(result.returncode, 0)
                self.assertFalse(self.destination.exists())

    def test_invalid_port_and_nonpublic_address_do_not_create_files(self):
        for values in ({"sstp-port": "0"}, {"admin-port": "65536"}, {"public-ip": "127.0.0.1"}, {"public-ip": "::1"}):
            with self.subTest(values=values):
                result = self.render(**values)
                self.assertNotEqual(result.returncode, 0)
                self.assertFalse(self.destination.exists())

    def test_existing_destination_is_not_overwritten(self):
        self.destination.mkdir()
        sentinel = self.destination / "keep.txt"
        sentinel.write_text("existing content", encoding="utf-8")
        result = self.render()
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(sentinel.read_text(encoding="utf-8"), "existing content")


class InstallationContractChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = (ROOT / "installer.sh").read_text(encoding="utf-8")
        cls.accel = configparser.ConfigParser(allow_no_value=True, interpolation=None)
        cls.accel.read_string((PAYLOAD / "etc/sstp-accel/accel.conf").read_text(encoding="utf-8"))

    def test_authentication_is_local_and_session_is_replaced(self):
        modules = self.accel["modules"]
        self.assertIn("sstp", modules)
        self.assertIn("chap-secrets", modules)
        self.assertNotIn("radius", modules)
        self.assertEqual(self.accel["common"]["single-session"], "replace")
        self.assertEqual(self.accel["common"]["single-session-ignore-case"], "1")
        self.assertEqual(self.accel["chap-secrets"]["chap-secrets"], "/etc/sstp-accel/chap-secrets")

    def test_sstp_certificate_and_ppp_profile_are_present(self):
        self.assertEqual(self.accel["sstp"]["accept"], "ssl")
        self.assertEqual(set(self.accel["sstp"]["ssl-protocol"].split(",")), {"tls1.2", "tls1.3"})
        self.assertEqual(self.accel["ppp"]["mtu"], "1400")
        self.assertEqual(self.accel["ppp"]["mru"], "1400")
        self.assertEqual(self.accel["ppp"]["ipv6"], "deny")
        self.assertEqual(self.accel["cli"]["tcp"], "127.0.0.1:2001")

    def test_fresh_install_initializes_empty_users_and_direct_mode(self):
        self.assertIn("install -m 0600 /dev/null /etc/sstp-accel/chap-secrets", self.core)
        self.assertIn("printf 'direct\\n' > /etc/sstp-egress-mode", self.core)
        self.assertRegex(self.core, r"['\"]static-ips\.json['\"]\s*:\s*\{\}")
        self.assertIn("systemctl mask wg-quick@sstp_exit.service", self.core)
        self.assertIn("systemctl disable --now sstp-cascade.timer", self.core)
        self.assertNotRegex(self.core, r"systemctl enable[^\n]*sstp-cascade\.timer")

    def test_firewall_boot_order_precedes_vpn_accepting_users(self):
        server = configparser.ConfigParser(interpolation=None)
        server.read_string((PAYLOAD / "etc/systemd/system/sstp-accel.service").read_text(encoding="utf-8"))
        self.assertIn("sstp-network.service", server["Unit"]["Requires"].split())
        self.assertIn("sstp-network.service", server["Unit"]["After"].split())
        network = (PAYLOAD / "etc/systemd/system/sstp-network.service").read_text(encoding="utf-8")
        self.assertIn("SSTP_ROUTE_SKIP=1", network)
        self.assertIn("sstp-nft-apply", network)

    def test_interactive_contract_has_domain_ports_and_private_password_prompt(self):
        prompts = re.findall(r"^read -r -p .*? ([A-Z_]+) </dev/tty$", self.core, re.M)
        self.assertEqual(prompts, ["VPN_DOMAIN", "SSTP_PORT", "ADMIN_PORT"])
        self.assertIn('[[ "$SSTP_PORT" != "$ADMIN_PORT" ]]', self.core)
        self.assertIn('python3 "$PACKAGE_DIR/scripts/ask_admin_password.py" "$PRIVATE_WORK/admin-password"', self.core)
        self.assertIn('password = Path(sys.argv[1]).read_text(encoding=\'utf-8\')', self.core)
        self.assertNotIn('password = secrets.token_urlsafe', self.core)
        self.assertNotRegex(self.core, r'export[^\n]*PASSWORD')


if __name__ == "__main__":
    unittest.main()
