"""UDP port selection regression: all commands are shell functions, no network."""
import os
from pathlib import Path
import re
import shutil
import subprocess
import unittest

TARGET = Path(os.environ.get('SSTP_PORT_TEST_CONTROLLER') or
              Path(__file__).resolve().parents[1] / 'payload/usr/local/sbin/sstp-cascade-exit')
BASH = os.environ.get('SSTP_TEST_BASH') or shutil.which('bash')
text = TARGET.read_text(encoding='utf-8')
BLOCK = re.search(r'# BEGIN UDP PORT SELECTION\n(.*?)# END UDP PORT SELECTION', text, re.S).group(1)
HARNESS = r'''
set -euo pipefail
export PATH=/usr/bin:/bin:$PATH
wg() { [[ ${FAIL_WG:-0} != 1 ]] || return 1; printf '%s\n' "${WG_ROWS:-}"; }
ss() {
  [[ ${FAIL_SS:-0} != 1 ]] || return 1
  [[ $# = 3 && $1 = -H && $2 = -lun && $3 = 'sport = :'* ]] || exit 90
  local requested=${3##*:}
  if [[ ${ALL_BUSY:-0} = 1 || " ${SS_BUSY:-} " = *" $requested "* ]]; then
    printf 'UNCONN 0 0 [::]:%s [::]:*\n' "$requested"
  fi
}
'''


@unittest.skipUnless(BASH, 'Bash required')
class ExitPortTests(unittest.TestCase):
    def choose(self, **values):
        env = os.environ.copy()
        for name in ('FAIL_WG', 'FAIL_SS', 'WG_ROWS', 'SS_BUSY', 'ALL_BUSY'):
            env.pop(name, None)
        env.update(values)
        return subprocess.run([BASH, '-s'], input=HARNESS + BLOCK + "printf 'SELECTED=%s\\n' \"$PORT\"\n",
                              text=True, capture_output=True, env=env, timeout=20)

    def test_skip_udp_listener(self):
        result = self.choose(SS_BUSY='51860')
        self.assertEqual((result.returncode, result.stdout.strip()), (0, 'SELECTED=51861'))

    def test_skip_wireguard_port_even_without_listener(self):
        result = self.choose(WG_ROWS='existing\t51860\nother\t51861')
        self.assertEqual((result.returncode, result.stdout.strip()), (0, 'SELECTED=51862'))

    def test_first_port_when_free(self):
        result = self.choose()
        self.assertEqual((result.returncode, result.stdout.strip()), (0, 'SELECTED=51860'))

    def test_fail_closed_when_socket_inspection_fails(self):
        result = self.choose(FAIL_SS='1')
        self.assertEqual(result.returncode, 25)
        self.assertNotIn('SELECTED=', result.stdout)

    def test_fail_closed_when_wireguard_inspection_fails(self):
        result = self.choose(FAIL_WG='1')
        self.assertEqual(result.returncode, 25)
        self.assertNotIn('SELECTED=', result.stdout)

    def test_no_free_port(self):
        result = self.choose(ALL_BUSY='1')
        self.assertEqual(result.returncode, 25)
        self.assertNotIn('SELECTED=', result.stdout)


if __name__ == '__main__':
    unittest.main()
