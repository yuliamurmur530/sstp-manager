"""Dependency bootstrap regression tests; apt is always a mock, no host changes."""
import importlib.util
import os
from pathlib import Path
import re
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('release_builder_dependencies', ROOT / 'tools/build_release.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
BLOCK = re.search(r'# BEGIN BOOTSTRAP DEPENDENCIES\n(.*?)# END BOOTSTRAP DEPENDENCIES', builder.WRAPPER, re.S).group(1)
BASH = os.environ.get('SSTP_TEST_BASH') or shutil.which('bash')
# Only host identity is substituted; package selection and mode guards are real.
MOCK_BLOCK = BLOCK.replace('$EUID', '${TEST_UID:-0}').replace(
    '[[ -r /etc/os-release ]]', 'true').replace('. /etc/os-release', ': "${ID:=debian}" "${VERSION_ID:=12}"')
HARNESS = r'''
set -euo pipefail
export PATH=/usr/bin:/bin:$PATH
installed=0
command() {
  [[ $1 == -v ]] || return 91
  if [[ $2 == "${MISSING_TOOL:-none}" && ( $installed == 0 || ${STILL_MISSING:-0} == 1 ) ]]; then return 1; fi
  return 0
}
apt-get() {
  printf 'APT %s\n' "$*"
  [[ ${FAIL_APT:-0} != 1 ]] || return 42
  installed=1
}
'''


@unittest.skipUnless(BASH, 'Bash required')
class BootstrapTests(unittest.TestCase):
    def invoke(self, mode='', **settings):
        env = os.environ.copy()
        env.update(ID='debian', VERSION_ID='12', TEST_UID='0', MISSING_TOOL='none', FAIL_APT='0', STILL_MISSING='0')
        env.update(settings)
        return subprocess.run([BASH, '-c', HARNESS + MOCK_BLOCK + "\nprintf 'CONTINUED\\n'\n", 'test', *([mode] if mode else [])],
                              capture_output=True, text=True, env=env, timeout=20)

    def test_existing_tools_need_no_package_installation(self):
        result = self.invoke()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertNotIn('APT ', result.stdout)

    def test_missing_tools_are_installed_before_extraction(self):
        for command in ('flock', 'awk', 'gzip', 'tar', 'readlink'):
            with self.subTest(command=command):
                result = self.invoke(MISSING_TOOL=command)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn('install -y --no-install-recommends coreutils gawk tar gzip util-linux findutils grep sed', result.stdout)
                self.assertIn('CONTINUED', result.stdout)

    def test_read_only_modes_never_install_packages(self):
        for mode in ('--check', '--extract'):
            with self.subTest(mode=mode):
                result = self.invoke(mode, MISSING_TOOL='tar')
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn('APT ', result.stdout)
                self.assertNotIn('CONTINUED', result.stdout)

    def test_nonroot_never_installs_packages(self):
        result = self.invoke(MISSING_TOOL='flock', TEST_UID='1000')
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn('APT ', result.stdout)

    def test_archive_check_does_not_require_linux_installation_tools(self):
        result = self.invoke('--check', MISSING_TOOL='flock')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertNotIn('APT ', result.stdout)

    def test_unsupported_os_never_installs_packages(self):
        result = self.invoke(MISSING_TOOL='flock', ID='other')
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn('APT ', result.stdout)

    def test_package_failure_stops_bootstrap(self):
        result = self.invoke(MISSING_TOOL='flock', FAIL_APT='1')
        self.assertEqual(result.returncode, 42)
        self.assertNotIn('CONTINUED', result.stdout)

    def test_command_rechecked_after_installation(self):
        result = self.invoke(MISSING_TOOL='flock', STILL_MISSING='1')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('still unavailable', result.stderr)


class DependencyCoverageTests(unittest.TestCase):
    def test_main_server_installs_ping_and_sysctl(self):
        core = (ROOT / 'installer.sh').read_text(encoding='utf-8')
        self.assertIn('iproute2 iputils-ping', core)
        self.assertIn('openssl util-linux procps', core)
        self.assertLess(core.index('install -y --no-install-recommends util-linux'), core.index('flock -n 9'))

    def test_exit_installs_network_tools_and_ca_bundle_when_missing(self):
        controller = (ROOT / 'payload/usr/local/sbin/sstp-cascade-exit').read_text(encoding='utf-8')
        for tool in ('ip', 'ss', 'sysctl'):
            self.assertIn(f'command -v {tool} >/dev/null || missing=1', controller)
        self.assertIn('python3-minimal iproute2 procps', controller)
        self.assertIn('[[ -s /etc/ssl/certs/ca-certificates.crt ]] || missing=1', controller)
