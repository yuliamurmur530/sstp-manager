"""AST-isolated public route tests: no app initialization or server access.

The private key below is intentionally a synthetic envelope. The controller,
not the HTTP form parser, validates actual cryptographic key material.
"""
import ast
from contextlib import contextmanager
from datetime import datetime
from functools import wraps
import io
import ipaddress
import json
import logging
import os
from pathlib import Path
import re
import secrets
import shlex
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from flask import Flask, request, redirect, url_for, session, flash, jsonify, render_template_string
from werkzeug.exceptions import RequestEntityTooLarge


APP_SOURCE = Path(__file__).resolve().parents[1] / "payload/opt/sstp-manager/app.py"
KEY_BODY = "dGVzdC1vbmx5LXN5bnRoZXRpYy1rZXktbWF0ZXJpYWwtbm90LXJlYWw="
PRIVATE_KEY = "-----BEGIN " + "OPENSSH PRIVATE KEY-----\n" + KEY_BODY + "\n-----END OPENSSH PRIVATE KEY-----\n"
PASSWORD = "  Example-password with spaces  "
PASSPHRASE = "  Example-key passphrase  "
REAL_RUN = subprocess.run
NODE = os.environ.get("SSTP_NODE") or shutil.which("node")


def isolated_route(source, app, logger):
    """Execute selected declarations only; skip every original import/init/read."""
    parsed = ast.parse(source)
    declarations = {node.name: node for node in parsed.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    required = {"update_cascade_exit", "login_required", "csrf_required"}
    while True:
        referenced = {node.id for name in required for node in ast.walk(declarations[name]) if isinstance(node, ast.Name)}
        expanded = required | (referenced & declarations.keys())
        if expanded == required:
            break
        required = expanded
    namespace = {
        "__name__": "isolated_cascade_route", "app": app, "logger": logger,
        "request": request, "redirect": redirect, "url_for": url_for,
        "session": session, "flash": flash, "jsonify": jsonify, "wraps": wraps,
        "contextmanager": contextmanager, "datetime": datetime, "io": io,
        "ipaddress": ipaddress, "json": json, "logging": logging, "os": os,
        "Path": Path, "re": re, "secrets": secrets, "shlex": shlex,
        "subprocess": subprocess, "tempfile": tempfile,
        "RequestEntityTooLarge": RequestEntityTooLarge,
    }
    for node in parsed.body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    namespace[target.id] = value
    namespace.update(app=app, logger=logger)
    selected = [node for node in parsed.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.name in required]
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(APP_SOURCE), "exec"), namespace)
    return namespace


class CascadeCredentialRouteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = APP_SOURCE.read_text(encoding="utf-8")

    def setUp(self):
        self.app = Flask("cascade_credential_test")
        self.app.config.update(TESTING=True, SECRET_KEY=secrets.token_hex(32), MAX_CONTENT_LENGTH=1024 * 1024)
        self.app.add_url_rule("/", "index", lambda: "index")
        self.app.add_url_rule("/login", "login", lambda: "login")
        self.log_output = io.StringIO()
        self.logger = logging.getLogger("cascade-credentials-test-" + secrets.token_hex(4))
        self.logger.setLevel(logging.DEBUG)
        self.handler = logging.StreamHandler(self.log_output)
        self.logger.addHandler(self.handler)
        self.logger.propagate = False
        self.addCleanup(self.logger.removeHandler, self.handler)
        self.namespace = isolated_route(self.source, self.app, self.logger)
        self.client = self.app.test_client()
        self.start = patch.object(subprocess, "run", return_value=subprocess.CompletedProcess(
            [], 0, json.dumps({"success": True, "started": True, "job_id": "example-job", "message": "Preparation started"}), ""))
        self.run = self.start.start()
        self.addCleanup(self.start.stop)
        with self.client.session_transaction() as data:
            data["logged_in"] = True
            data["csrf_token"] = "example-csrf"

    def post(self, **extra):
        data = {"csrf": "example-csrf", "exit_ip": "1.1.1.1", "ssh_auth": "password", "ssh_password": PASSWORD, "ssh_port": "22"}
        data.update(extra)
        return self.client.post("/cascade/exit", data=data, headers={"Accept": "application/json", "X-Requested-With": "XMLHttpRequest"})

    def sent(self):
        self.run.assert_called_once()
        args, options = self.run.call_args
        self.assertTrue(args and isinstance(args[0], list))
        self.assertIn("input", options, "Credentials must travel on stdin")
        payload = options["input"]
        if isinstance(payload, bytes):
            payload = payload.decode("utf-8")
        self.assertIsInstance(payload, str)
        self.assertNotIn(PASSWORD, repr(args))
        self.assertNotIn(PASSPHRASE, repr(args))
        self.assertNotIn(KEY_BODY, repr(args))
        for option in ("env", "cwd"):
            self.assertNotIn(PASSWORD, repr(options.get(option)))
            self.assertNotIn(KEY_BODY, repr(options.get(option)))
        return json.loads(payload)

    def assert_hidden(self, response, *values):
        def strings(value):
            if isinstance(value, str):
                return value
            if isinstance(value, dict):
                return "\n".join(strings(item) for item in value.values())
            if isinstance(value, list):
                return "\n".join(strings(item) for item in value)
            return ""

        with self.client.session_transaction() as data:
            flashes = repr(data.get("_flashes", []))
        inspected = response.get_data(as_text=True) + strings(response.get_json(silent=True)) + self.log_output.getvalue() + flashes
        for value in values:
            if value:
                self.assertNotIn(value, inspected)

    def assert_rejected(self, **extra):
        self.run.reset_mock()
        response = self.post(**extra)
        self.assertIn(response.status_code, (400, 413), response.get_data(as_text=True))
        self.run.assert_not_called()
        return response

    def test_password_mode_uses_json_stdin_and_custom_port(self):
        response = self.post(ssh_port="2222")
        self.assertIn(response.status_code, (200, 202))
        sent = self.sent()
        self.assertEqual(sent["ssh_auth"], "password")
        self.assertEqual(sent["ssh_password"], PASSWORD)
        self.assertEqual(sent["ssh_port"], 2222)
        for name in ("ssh_private_key", "ssh_key_passphrase"):
            self.assertFalse(sent.get(name))

    def test_posted_username_cannot_override_root_only_contract(self):
        response = self.post(ssh_user="other-user", ssh_username="other-user")
        self.assertIn(response.status_code, (200, 202))
        sent = self.sent()
        self.assertNotIn("ssh_user", sent)
        self.assertNotIn("ssh_username", sent)
        self.assertNotIn("other-user", repr(self.run.call_args))

    def test_password_preserves_whitespace_and_omits_key_material(self):
        response = self.post(ssh_auth="password", ssh_password=PASSWORD, ssh_private_key=PRIVATE_KEY, ssh_key_passphrase=PASSPHRASE)
        self.assertIn(response.status_code, (200, 202))
        sent = self.sent()
        self.assertEqual(sent["ssh_auth"], "password")
        self.assertEqual(sent["ssh_password"], PASSWORD)
        self.assertFalse(sent.get("ssh_private_key"))
        self.assertFalse(sent.get("ssh_key_passphrase"))
        self.assert_hidden(response, PASSWORD, PASSPHRASE, KEY_BODY)

    def test_saved_mode_is_rejected_even_with_other_credentials(self):
        response = self.assert_rejected(ssh_auth="saved", ssh_password=PASSWORD, ssh_private_key=PRIVATE_KEY, ssh_key_passphrase=PASSPHRASE)
        self.assert_hidden(response, PASSWORD, PASSPHRASE, KEY_BODY)

    def test_missing_auth_defaults_to_password_not_saved_access(self):
        response = self.client.post("/cascade/exit", data={
            "csrf": "example-csrf", "exit_ip": "1.1.1.1", "ssh_port": "22",
        }, headers={"Accept": "application/json"})
        self.assertEqual(response.status_code, 400)
        self.run.assert_not_called()
        response = self.client.post("/cascade/exit", data={
            "csrf": "example-csrf", "exit_ip": "1.1.1.1", "ssh_port": "22", "ssh_password": PASSWORD,
        }, headers={"Accept": "application/json"})
        self.assertIn(response.status_code, (200, 202))
        self.assertEqual(self.sent()["ssh_auth"], "password")

    def test_private_key_text_optional_passphrase_and_no_password(self):
        response = self.post(ssh_auth="key", ssh_private_key=PRIVATE_KEY, ssh_key_passphrase=PASSPHRASE, ssh_password=PASSWORD)
        self.assertIn(response.status_code, (200, 202))
        sent = self.sent()
        self.assertEqual(sent["ssh_auth"], "key")
        self.assertEqual(sent["ssh_private_key"].strip(), PRIVATE_KEY.strip())
        self.assertEqual(sent["ssh_key_passphrase"], PASSPHRASE)
        self.assertFalse(sent.get("ssh_password"))
        self.assert_hidden(response, PASSWORD, PASSPHRASE, KEY_BODY)

    def test_private_key_upload_is_read_into_stdin_not_file_argument(self):
        response = self.post(ssh_auth="key", ssh_key_file=(io.BytesIO(PRIVATE_KEY.encode()), "example-key.pem"))
        self.assertIn(response.status_code, (200, 202))
        sent = self.sent()
        self.assertEqual(sent["ssh_private_key"].strip(), PRIVATE_KEY.strip())
        self.assertFalse(sent.get("ssh_key_passphrase"))
        self.assertNotIn("example-key.pem", repr(self.run.call_args.args))
        self.assert_hidden(response, KEY_BODY)

    def test_invalid_modes_and_ports_do_not_start_controller(self):
        for mode in ("saved", "", "unknown", "root-password", "key;false"):
            with self.subTest(mode=mode):
                self.assert_rejected(ssh_auth=mode)
        for port in ("0", "65536", "-1", "22;false", "22.5", "invalid", ""):
            with self.subTest(port=port):
                self.assert_rejected(ssh_port=port)

    def test_missing_password_or_private_key_is_rejected(self):
        self.assert_rejected(ssh_auth="password", ssh_password="")
        self.assert_rejected(ssh_auth="key", ssh_private_key="")

    def test_public_key_is_not_a_private_key(self):
        self.assert_rejected(ssh_auth="key", ssh_private_key="ssh-ed25519 " + "A" * 70 + " example")

    def test_key_text_and_uploaded_file_are_mutually_exclusive(self):
        self.assert_rejected(ssh_auth="key", ssh_private_key=PRIVATE_KEY, ssh_key_file=(io.BytesIO(PRIVATE_KEY.encode()), "example-key.pem"))

    def test_uploaded_key_must_be_utf8(self):
        self.assert_rejected(ssh_auth="key", ssh_key_file=(io.BytesIO(b"\xff\xfe\x80"), "example-key.pem"))

    def test_private_key_size_limit_covers_text_and_file(self):
        oversized = "-----BEGIN " + "OPENSSH PRIVATE KEY-----\n" + "A" * (32 * 1024) + "\n-----END OPENSSH PRIVATE KEY-----\n"
        self.assert_rejected(ssh_auth="key", ssh_private_key=oversized)
        self.assert_rejected(ssh_auth="key", ssh_key_file=(io.BytesIO(oversized.encode()), "example-key.pem"))

    def test_password_and_passphrase_limits_are_utf8_byte_limits(self):
        for secret in ("A" * 4097, "\u0436" * 2049):
            with self.subTest(kind="password", size=len(secret.encode())):
                self.assert_rejected(ssh_auth="password", ssh_password=secret)
            with self.subTest(kind="passphrase", size=len(secret.encode())):
                self.assert_rejected(ssh_auth="key", ssh_private_key=PRIVATE_KEY, ssh_key_passphrase=secret)

    def test_password_exactly_4096_utf8_bytes_is_accepted(self):
        password = "\u0436" * 2048
        response = self.post(ssh_auth="password", ssh_password=password)
        self.assertIn(response.status_code, (200, 202))
        self.assertEqual(self.sent()["ssh_password"], password)
        self.assert_hidden(response, password)

    def test_credential_control_characters_are_rejected(self):
        for character in ("\x00", "\r", "\n"):
            with self.subTest(character=repr(character)):
                self.assert_rejected(ssh_auth="password", ssh_password="Example" + character + "password")
                self.assert_rejected(ssh_auth="key", ssh_private_key=PRIVATE_KEY, ssh_key_passphrase="Example" + character + "passphrase")

    def test_login_and_csrf_remain_required(self):
        with self.client.session_transaction() as data:
            data.clear()
        response = self.post(ssh_auth="password", ssh_password=PASSWORD)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response.location)
        self.run.assert_not_called()
        with self.client.session_transaction() as data:
            data["logged_in"] = True
            data["csrf_token"] = "correct-csrf"
        response = self.post(csrf="wrong-csrf", ssh_auth="password", ssh_password=PASSWORD)
        self.assertIn(response.status_code, (302, 400, 403))
        self.run.assert_not_called()
        self.assert_hidden(response, PASSWORD)

    def test_timeout_does_not_expose_stdin_or_exception_output(self):
        self.run.side_effect = subprocess.TimeoutExpired(["controller"], 20, output=PASSWORD, stderr=KEY_BODY)
        response = self.post(ssh_auth="password", ssh_password=PASSWORD)
        self.assertEqual(response.status_code, 504)
        self.assert_hidden(response, PASSWORD, KEY_BODY)

    def test_backend_rejection_cannot_reflect_or_log_credentials(self):
        self.run.return_value = subprocess.CompletedProcess([], 1, json.dumps({"success": False, "error": PASSWORD + KEY_BODY + PASSPHRASE}), "")
        response = self.post(ssh_auth="key", ssh_private_key=PRIVATE_KEY, ssh_key_passphrase=PASSPHRASE, ssh_password=PASSWORD)
        self.assertIn(response.status_code, (400, 409, 503))
        self.assert_hidden(response, PASSWORD, KEY_BODY, PASSPHRASE)

    def test_backend_success_message_cannot_reflect_credentials(self):
        self.run.return_value = subprocess.CompletedProcess([], 0, json.dumps({"success": True, "started": True, "message": PASSWORD}), "")
        response = self.post(ssh_auth="password", ssh_password=PASSWORD)
        self.assertIn(response.status_code, (200, 202, 409))
        self.assert_hidden(response, PASSWORD)

    def test_json_escaped_secret_cannot_bypass_reply_redaction(self):
        password = ' Example "quoted" \\ password '
        self.run.return_value = subprocess.CompletedProcess([], 0, json.dumps({"success": True, "started": True, "message": password}), "")
        response = self.post(ssh_auth="password", ssh_password=password)
        self.assertIn(response.status_code, (200, 202, 409))
        self.assert_hidden(response, password)

    def test_nonselected_secret_is_not_reflected_from_unexpected_reply(self):
        self.run.return_value = subprocess.CompletedProcess([], 1, json.dumps({"success": False, "error": PASSWORD}), "")
        response = self.post(ssh_auth="key", ssh_private_key=PRIVATE_KEY, ssh_password=PASSWORD)
        self.assertIn(response.status_code, (400, 409, 503))
        self.assert_hidden(response, PASSWORD)

    def test_form_contains_auth_modes_root_key_file_and_passphrase(self):
        parsed = ast.parse(self.source)
        template = next(ast.literal_eval(node.value) for node in parsed.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "INDEX_TPL" for target in node.targets))
        form = re.search(r'<form\b[^>]*id=["\']cascade-exit-form["\'][^>]*>.*?</form>', template, re.S)
        self.assertIsNotNone(form)
        html = form.group(0)
        for field in ("ssh_auth", "ssh_port", "ssh_password", "ssh_private_key", "ssh_key_file", "ssh_key_passphrase"):
            self.assertRegex(html, r'\bname=["\']' + field + r'["\']')
        for mode in ("password", "key"):
            self.assertRegex(html, r'<option\b[^>]*value=["\']' + mode + r'["\']')
        self.assertNotRegex(html, r'<option\b[^>]*value=["\']saved["\']')
        self.assertEqual(re.findall(r'<option\b[^>]*value=["\']([^"\']+)["\']', html), ["password", "key"])
        self.assertIn("\u0417\u0430\u043a\u0440\u044b\u0442\u044b\u0439 SSH-\u043a\u043b\u044e\u0447", html)
        self.assertIn("root", html)
        self.assertRegex(html, r'<input\b(?=[^>]*\bname=["\']ssh_key_file["\'])(?=[^>]*\btype=["\']file["\'])[^>]*>')
        self.assertRegex(html, r'<input\b(?=[^>]*\bname=["\']ssh_key_passphrase["\'])(?=[^>]*\btype=["\']password["\'])[^>]*>')
        self.assert_hidden(self.post(ssh_auth="password", ssh_password=""), PASSWORD, KEY_BODY, PASSPHRASE)

    @unittest.skipUnless(NODE, "Node.js required for inline JavaScript syntax validation")
    def test_rendered_credentials_javascript_parses(self):
        template = self.namespace["INDEX_TPL"]
        cascade = {"available": False, "status_available": True, "enabled": False, "direct_ip": "", "exit_ip": "", "port": 0, "healthy": False,
                   "job": {"active": False, "stage": "idle", "message": ""}}
        context = {"users": [], "month": "2000-01", "total_dl": "0 B", "total_ul": "0 B", "total_all": "0 B",
                   "collected_at": "", "traffic_note": "", "status_error": "", "csrf_token": "example-csrf", "static_ips": {},
                   "port_forwards": [], "access_networks": [], "routes": [], "suggested_ip": "10.77.0.10", "suggested_port": 2100,
                   "vpn_network": "10.77.0.0/24", "vpn_gateway": "10.77.0.1", "cascade_exit": cascade,
                   "network_settings": {"pool_start": "10.77.0.10", "pool_end": "10.77.0.249", "nat_enabled": True}}
        with self.app.test_request_context("/"):
            html = render_template_string(template, **context)
        scripts = re.findall(r"<script\b[^>]*>(.*?)</script\s*>", html, re.S | re.I)
        self.assertTrue(scripts)
        for index, script in enumerate(scripts):
            with self.subTest(script=index):
                result = REAL_RUN([NODE, "--check", "-"], input=script, text=True, encoding="utf-8", capture_output=True, timeout=20)
                self.assertEqual(result.returncode, 0, result.stderr)
        for field in ("ssh_auth", "ssh_port", "ssh_password", "ssh_private_key", "ssh_key_file", "ssh_key_passphrase"):
            self.assertIn('name="' + field + '"', html)
        self.run.assert_not_called()


    def test_request_limit_applies_before_form_parsing(self):
        from flask.wrappers import Request
        with patch.object(Request, "_load_form_data", side_effect=AssertionError("Oversized body parsed")):
            response = self.client.post("/cascade/exit", data=b"x" * (96 * 1024 + 1), content_type="application/x-www-form-urlencoded")
        self.assertEqual(response.status_code, 413)
        self.assertEqual(response.headers.get("Cache-Control"), "no-store")
        self.run.assert_not_called()

    def test_success_validation_and_timeout_are_not_cacheable(self):
        response = self.post()
        self.assertEqual(response.headers.get("Cache-Control"), "no-store")
        response = self.post(ssh_password="")
        self.assertEqual(response.headers.get("Cache-Control"), "no-store")
        self.run.side_effect = subprocess.TimeoutExpired(["controller"], 20, output=PASSWORD)
        response = self.post()
        self.assertEqual(response.status_code, 504)
        self.assertEqual(response.headers.get("Cache-Control"), "no-store")
        self.assert_hidden(response, PASSWORD)

    @unittest.skipUnless(NODE, "Node.js required for isolated credential UI behavior")
    def test_auth_switch_clears_inactive_secrets_and_uploads(self):
        # Execute only pure credential UI helpers with a minimal DOM, never a browser/network.
        template = self.namespace["INDEX_TPL"]
        match = re.search(r"var cascadeSubmitting=false;.*?(?=var cascadePollTimer=)", template, re.S)
        self.assertIsNotNone(match)
        harness = r"""
const assert=require('node:assert/strict');
const elements={
  ssh_auth:{value:'password',addEventListener(){}},
  ssh_password:{value:'password-sentinel',required:true,disabled:false},
  ssh_private_key:{value:'key-sentinel',disabled:true},
  ssh_key_passphrase:{value:'passphrase-sentinel',disabled:true},
  ssh_key_file:{value:'upload-sentinel',disabled:true,files:[]}
};
const groups={
  'cascade-password-fields':{hidden:false,querySelectorAll(){return [elements.ssh_password]}},
  'cascade-key-fields':{hidden:true,querySelectorAll(){return [elements.ssh_private_key,elements.ssh_key_passphrase,elements.ssh_key_file]}},
  'cascade-auth-error':{hidden:true,textContent:''}
};
var cascadeExitForm={elements:{namedItem(name){return elements[name]}},reportValidity(){return true}};
const document={getElementById(name){return groups[name]}};
const window={addEventListener(){}};
"""
        checks = r"""
assert.equal(elements.ssh_auth.value,'password');
assert.equal(groups['cascade-password-fields'].hidden,false);
assert.equal(elements.ssh_password.disabled,false);
assert.equal(elements.ssh_password.required,true);
assert.equal(elements.ssh_private_key.value,'');
assert.equal(elements.ssh_key_file.value,'');
elements.ssh_auth.value='key';
syncCascadeAuth();
assert.equal(elements.ssh_password.value,'');
assert.equal(elements.ssh_password.disabled,true);
assert.equal(elements.ssh_password.required,false);
assert.equal(groups['cascade-key-fields'].hidden,false);
assert.equal(elements.ssh_private_key.disabled,false);
assert.equal(validateCascadeCredentials(),false);
elements.ssh_private_key.value='synthetic-envelope';
assert.equal(validateCascadeCredentials(),true);
elements.ssh_key_file.files=[{size:100}];
assert.equal(validateCascadeCredentials(),false);
elements.ssh_private_key.value='';
elements.ssh_key_file.files=[{size:32769}];
assert.equal(validateCascadeCredentials(),false);
elements.ssh_key_file.files=[{size:100}];
assert.equal(validateCascadeCredentials(),true);
elements.ssh_key_passphrase.value='passphrase-sentinel';
elements.ssh_key_file.value='upload-sentinel';
clearCascadeSecrets();
for(const name of ['ssh_password','ssh_private_key','ssh_key_passphrase','ssh_key_file'])assert.equal(elements[name].value,'');
"""
        result = REAL_RUN([NODE, "-"], input=harness + match.group(0) + checks, text=True, encoding="utf-8", capture_output=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        submit = re.search(r"if\(cascadeExitForm\)cascadeExitForm.addEventListener\('submit'.*?(?=var cascadeModeForm=)", template, re.S).group(0)
        self.assertLess(submit.index("new FormData(cascadeExitForm)"), submit.index("clearCascadeSecrets()"))
        self.assertLess(submit.index("clearCascadeSecrets()"), submit.index("fetch("))
        self.assertIn("body:formData", submit)
        self.assertIn("cascadeSubmitting||!validateCascadeCredentials()", submit)
        self.run.assert_not_called()


if __name__ == "__main__":
    unittest.main()


