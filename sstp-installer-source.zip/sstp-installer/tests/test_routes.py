"""Pure desired-route checks; no route is added to the host."""
from contextlib import ExitStack
from pathlib import Path
import runpy
import unittest
from unittest.mock import patch

from test_panel import install_windows_fcntl


ROOT = Path(__file__).resolve().parents[1]


class RouteTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        install_windows_fcntl(self.stack)
        self.module = runpy.run_path(str(ROOT / "payload/usr/local/sbin/sstp-route-reconcile"))
        self.desired = self.module["desired_routes"]
        self.config = [{"cidr": "10.20.1.15/24", "user": "router", "label": "Example LAN", "id": "example"}]
        self.static = {"router": "10.77.0.10"}
        self.active = [{"state": "active", "ifname": "sstp0", "ip": "10.77.0.10"}]

    def test_active_client_route_is_normalized(self):
        self.assertEqual(self.desired(self.config, self.static, self.active), {"10.20.1.0/24": ("10.77.0.10", "sstp0")})

    def test_disconnected_client_has_no_desired_route(self):
        self.assertEqual(self.desired(self.config, self.static, []), {})
        self.active[0]["state"] = "starting"
        self.assertEqual(self.desired(self.config, self.static, self.active), {})

    def test_other_interface_is_not_owned_client(self):
        for iface in ("wg0", "eth0", "sstp0;false", "sstp-other"):
            with self.subTest(iface=iface):
                self.active[0]["ifname"] = iface
                self.assertEqual(self.desired(self.config, self.static, self.active), {})

    def test_invalid_destination_cannot_change_default_or_vpn_route(self):
        for destination in ("0.0.0.0/0", "10.77.0.0/24", "8.8.8.8/32", "::/0", "bad value"):
            with self.subTest(destination=destination), self.assertRaises(ValueError):
                self.desired([{**self.config[0], "cidr": destination}], self.static, self.active)

    def test_next_hop_must_be_inside_vpn(self):
        with self.assertRaises(ValueError):
            self.desired(self.config, {"router": "10.79.0.10"}, self.active)

    def test_missing_static_user_is_rejected(self):
        with self.assertRaises(KeyError):
            self.desired(self.config, {}, self.active)

    def test_helper_is_idle_on_import(self):
        with patch("subprocess.run", side_effect=AssertionError("unexpected network mutation")):
            runpy.run_path(str(ROOT / "payload/usr/local/sbin/sstp-route-reconcile"))


if __name__ == "__main__":
    unittest.main()
