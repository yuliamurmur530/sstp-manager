"""Read-only, command-mocked checks for the public cascade controller."""
import contextlib
import io
import json
import os
import pathlib
import runpy
import shutil
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

ROOT = pathlib.Path(__file__).resolve().parents[1]
CONTROLLER = ROOT / 'payload/usr/local/sbin/sstp-cascade-exit'
try:
    import fcntl  # noqa: F401 -- use the real module when available
except ImportError:
    sys.modules.setdefault('fcntl', types.SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *a: None))
SOURCE = runpy.run_path(str(CONTROLLER), run_name='cascade_test_module')
# runpy returns a copy of the function globals, so patch the actual global namespace.
G = SOURCE['run'].__globals__
OK = subprocess.CompletedProcess([], 0, '', '')
JOB = '0123456789ab'
ADDRESS = '1.1.1.1'
PUBLIC = 'A' * 43 + '='


class CascadeChecks(unittest.TestCase):
    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory(prefix='cascade-test-')
        root = pathlib.Path(self.scratch.name)
        self.patch = patch.dict(G, {
            'STATE_DIR': root, 'STATE_FILE': root / 'provision.json',
            'WG_CONF': root / 'wg.conf', 'MODE_FILE': root / 'mode',
            'WG_DIR': root, 'WG_KEY': root / 'wg.key',
            'CREDENTIAL_ROOT': root / 'credentials', 'PORTS_FILE': root / 'ssh-ports.json',
            'require_root': lambda: None, 'check_private_path': lambda *a, **kw: None,
            'authenticate_job': lambda *a: None,
            'run': Mock(return_value=OK),
            'operation_lock': lambda **kw: contextlib.nullcontext(),
        })
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.scratch.cleanup()

    def test_progress_history_and_failure_timestamp(self):
        G['update_state'](JOB, 'queued', 'queue')
        G['update_state'](JOB, 'installing', 'packages')
        G['update_state'](JOB, 'configuring_tunnel', 'firewall')
        G['update_state'](JOB, 'error', 'failed')
        state = G['read_json']()
        self.assertEqual(state['failed_stage'], 'configuring_tunnel')
        self.assertFalse(state['active'])
        self.assertGreaterEqual(state['finished_at'], state['started_at'])
        self.assertEqual([v['stage'] for v in state['history']], ['queued', 'installing', 'configuring_tunnel', 'error'])
        G['update_state']('f' * 12, 'queued', 'new')
        self.assertNotIn('failed_stage', G['read_json']())

    def test_invalid_private_ip_rejected(self):
        for value in ('127.0.0.1', '10.0.0.1', '169.254.169.254', '::1', 'invalid', '192.0.2.3'):
            with self.assertRaises(G['ProvisionError']):
                G['public_ipv4'](value)
        self.assertEqual(G['public_ipv4'](ADDRESS), ADDRESS)

    def test_remote_failure_rolls_back_before_local_restore(self):
        events = []
        G['update_state'](JOB, 'queued', 'queue')
        with patch.dict(G, {
            'endpoint_from_config': lambda: ('', 0), 'read_mode': lambda: 'direct',
            'ensure_local_key': lambda: None, 'target_public_key': lambda: ('local-private-fixture', PUBLIC),
            'remote_run': lambda a, script, *args, **kw: (events.append('remote_rollback') or OK) if script == G['REMOTE_ROLLBACK'] else subprocess.CompletedProcess([], 0, 'ubuntu\n', ''),
            'prepare_remote': Mock(side_effect=G['ProvisionError']('remote failed halfway')),
            'restore_target': lambda value: events.append('restore_local'),
            'activate_direct': lambda **kw: events.append('direct'),
        }):
            with self.assertRaisesRegex(G['ProvisionError'], 'halfway'):
                G['do_provision'](ADDRESS, JOB)
        self.assertEqual(events, ['remote_rollback', 'restore_local', 'direct'])
        self.assertFalse(G['read_json']()['active'])

    def test_same_exit_rollback_precedes_old_handshake(self):
        events = []
        G['update_state'](JOB, 'queued', 'queue')
        G['WG_CONF'].write_bytes(b'old configuration')
        with patch.dict(G, {
            'endpoint_from_config': lambda: (ADDRESS, 51860), 'read_mode': lambda: 'cascade',
            'ensure_local_key': lambda: None, 'target_public_key': lambda: ('local-private-fixture', PUBLIC),
            'remote_run': lambda a, script, *args, **kw: (events.append('remote_rollback') or OK) if script == G['REMOTE_ROLLBACK'] else subprocess.CompletedProcess([], 0, 'ubuntu\n', ''),
            'prepare_remote': Mock(side_effect=G['ProvisionError']('partial setup')),
            'restore_target': lambda value: events.append('restore_local'),
            'activate_cascade': lambda **kw: events.append('verify_old_cascade'),
        }):
            with self.assertRaises(G['ProvisionError']):
                G['do_provision'](ADDRESS, JOB)
        self.assertEqual(events, ['remote_rollback', 'restore_local', 'verify_old_cascade'])

    def test_failed_enable_returns_direct_even_before_routing(self):
        fallback = Mock()
        with patch.dict(G, {
            'endpoint_from_config': lambda: (ADDRESS, 51860),
            'wait_for_handshake': Mock(side_effect=G['ProvisionError']('no handshake')),
            'activate_direct': fallback,
        }):
            with self.assertRaisesRegex(G['ProvisionError'], 'no handshake'):
                G['activate_cascade']()
        fallback.assert_called_once_with(verify=False)

    def test_failed_direct_firewall_still_disables_tunnel(self):
        commands = []
        def command(args, **kw):
            commands.append(args)
            if args == [G['NFT_APPLY']]:
                raise G['ProvisionError']('firewall failure')
            return OK
        with patch.dict(G, {'run': command, 'write_mode': Mock(), 'direct_public_ipv4': lambda: ADDRESS}):
            with self.assertRaisesRegex(G['ProvisionError'], 'firewall failure'):
                G['activate_direct'](verify=False)
        self.assertIn(['systemctl', 'mask', 'wg-quick@sstp_exit.service'], commands)
        self.assertIn(['systemctl', 'disable', '--now', 'wg-quick@sstp_exit.service'], commands)

    def test_restore_config_does_not_start_disabled_exit(self):
        G['restore_target'](b'previous')
        self.assertEqual(G['WG_CONF'].read_bytes(), b'previous')
        self.assertFalse(any('start' in c.args[0] or 'enable' in c.args[0] for c in G['run'].call_args_list))

    def test_synchronous_mode_failure_clears_busy_state(self):
        with patch.dict(G, {'activate_direct': Mock(side_effect=G['ProvisionError']('direct failed'))}):
            with self.assertRaisesRegex(G['ProvisionError'], 'direct failed'):
                G['set_mode']('off')
        state = G['read_json']()
        self.assertFalse(state['active'])
        self.assertEqual(state['failed_stage'], 'switching_mode')
        G['update_state'](state['job_id'], 'error', 'repeated reporting')
        self.assertEqual(G['read_json']()['failed_stage'], 'switching_mode')

    def test_launcher_timeout_keeps_potential_worker_tracked(self):
        with patch.dict(G, {
            'status_payload': lambda: {'direct_ip': '9.9.9.9', 'exit_ip': '', 'healthy': False},
            'ensure_local_key': lambda: None,
            'run': Mock(side_effect=subprocess.TimeoutExpired('systemd-run', 8)),
        }):
            result = G['start'](ADDRESS)
        state = G['read_json']()
        self.assertTrue(state['active'])
        self.assertEqual(state['stage'], 'queued')
        self.assertFalse(result['launch_confirmed'])
        self.assertFalse(state['launch_confirmed'])
        self.assertNotIn('finished_at', state)
        self.assertNotIn('failed_stage', state)
        self.assertRegex(state['worker_unit'], r'^sstp-exit-provision-[a-f0-9]{12}$')

    def test_both_launchers_enqueue_without_invoking_workers(self):
        forbidden = Mock(side_effect=AssertionError('worker/network must never run in an enqueue test'))
        current = {'direct_ip': '9.9.9.9', 'exit_ip': '', 'healthy': False,
                   'mode': 'direct', 'available': True, 'enabled': False}
        with patch.dict(G, {
            'status_payload': lambda: current, 'ensure_local_key': lambda: None,
            'do_provision': forbidden, 'set_mode': forbidden, 'remote_run': forbidden,
            'prepare_remote': forbidden, 'activate_direct': forbidden, 'activate_cascade': forbidden,
        }):
            for name, argument, worker in [('start', ADDRESS, '_run'), ('start_mode', 'on', '_mode')]:
                with self.subTest(launcher=name):
                    G['write_json']({})
                    G['run'].reset_mock()
                    result = G[name](argument)
                    self.assertTrue(result['started'])
                    self.assertTrue(result['launch_confirmed'])
                    call = G['run'].call_args
                    self.assertIn('--no-block', call.args[0])
                    self.assertIn('--property=Type=oneshot', call.args[0])
                    self.assertIn(worker, call.args[0])
                    self.assertEqual(call.kwargs['timeout'], 8)
                    self.assertFalse(call.kwargs['check'])
                    self.assertTrue(G['read_json']()['active'])
        forbidden.assert_not_called()

    def test_enqueue_rejection_retains_bounded_actual_reason(self):
        G['update_state'](JOB, 'queued', 'queue')
        reason = 'Failed to connect to bus: Access denied\n' + 'detail ' * 200
        with patch.dict(G, {'run': Mock(return_value=subprocess.CompletedProcess([], 1, '', reason))}):
            with self.assertRaisesRegex(G['ProvisionError'], 'Failed to connect to bus: Access denied'):
                G['enqueue_job'](['systemd-run', '--no-block'], JOB, 'accepted')
        state = G['read_json']()
        self.assertEqual(state['failed_stage'], 'queued')
        self.assertFalse(state['active'])
        self.assertLessEqual(len(state['message']), 300)
        self.assertNotIn('\n', state['message'])

    def test_worker_error_wins_over_launcher_result_or_timeout(self):
        for outcome in ('refused', 'timeout', 'accepted'):
            with self.subTest(outcome=outcome):
                G['write_json']({})
                G['update_state'](JOB, 'queued', 'queue')
                snapshot = {}
                def launcher(args, **kw):
                    G['update_state'](JOB, 'checking_ssh', 'checking')
                    G['update_state'](JOB, 'error', 'SSH authentication denied; authorize the public key')
                    snapshot.update(G['read_json']())
                    if outcome == 'timeout':
                        raise subprocess.TimeoutExpired(args, 8)
                    return subprocess.CompletedProcess(args, 1 if outcome == 'refused' else 0, '', 'Job failed')
                with patch.dict(G, {'run': launcher}):
                    with self.assertRaisesRegex(G['ProvisionError'], 'SSH authentication denied'):
                        G['enqueue_job'](['systemd-run', '--no-block'], JOB, 'accepted')
                self.assertEqual(G['read_json'](), snapshot)
                self.assertEqual(G['read_json']()['failed_stage'], 'checking_ssh')

    def test_worker_success_is_not_replaced_by_launcher_failure(self):
        G['update_state'](JOB, 'queued', 'queue')
        def launcher(args, **kw):
            G['update_state'](JOB, 'success', 'Worker completed successfully')
            return subprocess.CompletedProcess(args, 1, '', 'Transport response lost')
        with patch.dict(G, {'run': launcher}):
            result = G['enqueue_job'](['systemd-run', '--no-block'], JOB, 'accepted')
        self.assertTrue(result['success'])
        self.assertFalse(result['started'])
        self.assertEqual(result['message'], 'Worker completed successfully')
        self.assertEqual(G['read_json']()['stage'], 'success')

    def test_progress_is_not_overwritten_when_enqueue_confirmation_times_out(self):
        G['update_state'](JOB, 'queued', 'queue')
        snapshot = {}
        def launcher(args, **kw):
            G['update_state'](JOB, 'installing', 'Real worker package progress')
            snapshot.update(G['read_json']())
            raise subprocess.TimeoutExpired(args, 8)
        with patch.dict(G, {'run': launcher}):
            result = G['enqueue_job'](['systemd-run', '--no-block'], JOB, 'accepted')
        self.assertEqual(G['read_json'](), snapshot)
        self.assertTrue(result['launch_confirmed'])
        self.assertEqual(result['message'], 'Real worker package progress')

    def test_stale_worker_recovers_direct_but_live_worker_not_touched(self):
        G['write_json']({'job_id': JOB, 'stage': 'installing', 'active': True, 'updated_at': 1,
                         'worker_unit': 'sstp-exit-provision-' + JOB})
        direct = Mock()
        with patch.dict(G, {'activate_direct': direct, 'run': Mock(return_value=subprocess.CompletedProcess([], 0, 'LoadState=loaded\nActiveState=inactive\nJob=\n', ''))}):
            G['recover_interrupted_job']()
        direct.assert_called_once_with(verify=False)
        self.assertFalse(G['read_json']()['active'])
        G['write_json']({'job_id': JOB, 'stage': 'installing', 'active': True, 'updated_at': 1,
                         'worker_unit': 'sstp-exit-provision-' + JOB})
        direct.reset_mock()
        with patch.dict(G, {'activate_direct': direct, 'run': Mock(return_value=subprocess.CompletedProcess([], 0, 'LoadState=loaded\nActiveState=activating\nJob=1\n', ''))}):
            G['recover_interrupted_job']()
        direct.assert_not_called()

    def test_pending_or_unknown_unit_does_not_cancel_worker(self):
        G['write_json']({'job_id': JOB, 'stage': 'queued', 'active': True, 'updated_at': 1,
                         'worker_unit': 'sstp-exit-provision-' + JOB})
        original = G['read_json']()
        direct = Mock()
        for output in ('LoadState=loaded\nActiveState=inactive\nJob=135\n',
                       'LoadState=loaded\nActiveState=inactive\n',
                       'ActiveState=inactive\nJob=\n'):
            with patch.dict(G, {'activate_direct': direct, 'run': Mock(return_value=subprocess.CompletedProcess([], 0, output, ''))}):
                G['recover_interrupted_job']()
        for error in (OSError('bus unavailable'), subprocess.TimeoutExpired('systemctl', 5)):
            with patch.dict(G, {'activate_direct': direct, 'run': Mock(side_effect=error)}):
                G['recover_interrupted_job']()
        direct.assert_not_called()
        self.assertEqual(G['read_json'](), original)

    def test_status_bus_failure_does_not_cancel_an_uncertain_worker(self):
        G['write_json']({'job_id': JOB, 'stage': 'queued', 'active': True, 'updated_at': 1,
                         'worker_unit': 'sstp-exit-provision-' + JOB, 'launch_confirmed': False})
        snapshot = G['read_json']()
        direct = Mock()
        with patch.dict(G, {
            'activate_direct': direct,
            'run': Mock(return_value=subprocess.CompletedProcess([], 1, '', 'Failed to connect to bus')),
        }):
            G['recover_interrupted_job']()
        direct.assert_not_called()
        self.assertEqual(G['read_json'](), snapshot)

    def test_streamed_remote_milestones(self):
        class FakeProcess:
            stdin = io.StringIO()
            stdout = io.StringIO('SSTP_STAGE installing packages\nSSTP_STAGE configuring_tunnel firewall\nSSTP_MANAGER_EXIT ' + PUBLIC + ' 51860 eth0\n')
            def poll(self): return 0
            def wait(self, **kw): return 0
        with patch.object(subprocess, 'Popen', return_value=FakeProcess()):
            output = G['prepare_remote'](ADDRESS, PUBLIC, JOB)
        self.assertIn('SSTP_MANAGER_EXIT', output)
        state = G['read_json']()
        self.assertEqual(state['stage'], 'configuring_tunnel')
        self.assertEqual([h['stage'] for h in state['history']], ['installing', 'configuring_tunnel'])

    def test_previous_cleanup_failure_preserves_successful_exit(self):
        scripts = []
        G['update_state'](JOB, 'queued', 'queue')
        def remote(address, script, *args, **kw):
            scripts.append(script)
            if script == G['REMOTE_CLEANUP']:
                raise G['ProvisionError']('old VPS unreachable')
            return subprocess.CompletedProcess([], 0, 'ubuntu\n', '')
        with patch.dict(G, {
            'endpoint_from_config': lambda: ('9.9.9.9', 51860), 'read_mode': lambda: 'direct',
            'ensure_local_key': lambda: None, 'target_public_key': lambda: ('local-private-fixture', PUBLIC),
            'remote_run': remote, 'prepare_remote': lambda *a: 'SSTP_MANAGER_EXIT ' + PUBLIC + ' 51860 eth0\n',
            'configure_target': Mock(), 'wait_for_handshake': Mock(),
            'activate_cascade': Mock(), 'persist_interface_name': Mock(),
        }):
            G['do_provision'](ADDRESS, JOB)
        self.assertEqual(G['read_json']()['stage'], 'success')
        self.assertEqual(G['read_json']()['cleanup_pending_ip'], '9.9.9.9')
        self.assertNotIn(G['REMOTE_ROLLBACK'], scripts)

    def test_embedded_bash_syntax(self):
        executable = os.environ.get('SSTP_TEST_BASH') or shutil.which('bash')
        if not executable: self.skipTest('Bash unavailable')
        bash = pathlib.Path(executable)
        for name in ('REMOTE_SETUP', 'REMOTE_ROLLBACK', 'REMOTE_COMMIT', 'REMOTE_CLEANUP'):
            result = subprocess.run([str(bash), '-n'], input=G[name], text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, name + ': ' + result.stderr)
        for name in ('sstp-cascade-apply', 'sstp-cascade-reconcile'):
            result = subprocess.run([str(bash), '-n'], input=(CONTROLLER.parent / name).read_text(), text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, name + ': ' + result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
