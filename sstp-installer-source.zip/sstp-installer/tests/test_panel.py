"""Isolated application tests. No server, key, network, or system command is used."""
import builtins
from contextlib import ExitStack
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
APP_DIR = ROOT / "payload/opt/sstp-manager"
REAL_SUBPROCESS_RUN = subprocess.run
NODE = os.environ.get("SSTP_NODE") or shutil.which("node")


def install_windows_fcntl(stack):
    if os.name == "nt":
        module = types.ModuleType("fcntl")
        module.LOCK_EX, module.LOCK_UN, module.LOCK_NB = 2, 8, 4
        module.flock = lambda *args: None
        stack.enter_context(patch.dict(sys.modules, {"fcntl": module}))


class PanelTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.temp = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        install_windows_fcntl(self.stack)
        # Windows has no fchmod or directory fsync; only those OS mechanics are
        # adapted here. Linux runs with actual flock/fchmod/fsync behavior.
        if os.name == "nt":
            self.stack.enter_context(patch.object(os, "fchmod", lambda *args: None, create=True))
            original_open = os.open
            dummy = self.temp / "fsync-test"
            dummy.touch()

            def portable_open(path, flags, *args, **kwargs):
                if isinstance(path, (str, bytes, os.PathLike)) and os.path.isdir(path):
                    return original_open(dummy, os.O_RDWR)
                return original_open(path, flags, *args, **kwargs)

            self.stack.enter_context(patch.object(os, "open", portable_open))
        (self.temp / ".secret_key").write_text(secrets.token_hex(32), encoding="utf-8")
        self.backend = types.ModuleType("accel_backend")
        self.backend.__file__ = str(APP_DIR / "accel_backend.py")
        self.stack.enter_context(patch.dict(sys.modules, {"accel_backend": self.backend}))
        exec(compile((APP_DIR / "accel_backend.py").read_text(encoding="utf-8"), self.backend.__file__, "exec"), self.backend.__dict__)
        self.backend.ADMIN_DIR = str(self.temp)
        self.backend.STATIC_IP_FILE = str(self.temp / "static-ips.json")
        self.backend.CHAP_SECRETS_FILE = str(self.temp / "chap-secrets")
        self.backend.CHAP_LOCK_FILE = str(self.temp / "chap.lock")
        self.cli = self.stack.enter_context(patch.object(self.backend, "_run_cli", return_value=""))
        source = (APP_DIR / "app.py").read_text(encoding="utf-8")
        source = source.replace("ADMIN_DIR = '/opt/sstp-manager'", "ADMIN_DIR = " + repr(str(self.temp)))
        for name, value in {"__VPN_DOMAIN__": "vpn.example.com", "__ADMIN_PORT__": "9444", "__SSTP_PORT__": "9443", "__PUBLIC_IP__": "203.0.113.10"}.items():
            source = source.replace(name, value)
        self.panel = types.ModuleType("sstp_test_panel")
        self.panel.__file__ = str(APP_DIR / "app.py")
        self.stack.enter_context(patch.dict(sys.modules, {"sstp_test_panel": self.panel}))
        real_open = builtins.open

        def isolated_open(path, *args, **kwargs):
            if isinstance(path, (str, os.PathLike)) and str(path) == "/etc/sstp-manager/reserved-ports.json":
                raise FileNotFoundError(path)
            return real_open(path, *args, **kwargs)

        with patch.object(builtins, "open", isolated_open):
            exec(compile(source, self.panel.__file__, "exec"), self.panel.__dict__)
        self.panel.VPNCMD_LOCK_FILE = str(self.temp / "command.lock")
        self.panel.app.config.update(TESTING=True, SERVER_NAME="vpn.example.com", SESSION_COOKIE_SECURE=False)
        self.client = self.panel.app.test_client()
        self.commands = self.stack.enter_context(patch.object(subprocess, "run", side_effect=AssertionError("Unexpected system command in isolated test")))

    def login_session(self):
        with self.client.session_transaction() as session:
            session["logged_in"] = True
            session["csrf_token"] = "test-csrf-token"

    def write_json(self, name, value):
        (self.temp / name).write_text(json.dumps(value), encoding="utf-8")

    def test_user_lifecycle_uses_fresh_empty_local_database(self):
        self.write_json("static-ips.json", {"alice": "10.77.0.10"})
        self.assertIn(self.backend.SUCCESS, self.backend.compat_command(["UserList"]))
        self.backend.compat_command(["UserCreate", "alice"])
        self.backend.compat_command(["UserPasswordSet", "alice", "/PASSWORD:Example-pass-42"])
        chap = Path(self.backend.CHAP_SECRETS_FILE).read_text(encoding="utf-8")
        self.assertEqual(chap.split(), ["alice@VPN", "*", "Example-pass-42", "10.77.0.10"])
        self.assertIn("alice", self.backend.compat_command(["UserList"]))
        with self.assertRaises(self.backend.BackendError):
            self.backend.compat_command(["UserCreate", "alice"])
        self.backend.compat_command(["UserDelete", "alice"])
        self.assertEqual(Path(self.backend.CHAP_SECRETS_FILE).read_text(encoding="utf-8"), "")
        self.cli.assert_called_with("terminate match username alice@VPN hard", 10)

    def test_realm_round_trip(self):
        self.assertEqual(self.backend._display_username("alice@VPN"), "alice")
        self.assertEqual(self.backend._display_username("alice@vpn"), "alice")
        self.assertEqual(self.backend._login_username("alice@VPN"), "alice@VPN")

    def test_case_duplicate_and_unsafe_password_do_not_modify_database(self):
        self.write_json("static-ips.json", {"alice": "10.77.0.10", "ALICE": "10.77.0.11"})
        self.backend.compat_command(["UserCreate", "alice"])
        original = Path(self.backend.CHAP_SECRETS_FILE).read_bytes()
        with self.assertRaises(self.backend.BackendError):
            self.backend.compat_command(["UserCreate", "ALICE"])
        for password in ("short", "pass word 123", 'bad"quote123', "bad#mark123", "bad\\slash123"):
            with self.subTest(password=password), self.assertRaises(self.backend.BackendError):
                self.backend.compat_command(["UserPasswordSet", "alice", "/PASSWORD:" + password])
            self.assertEqual(Path(self.backend.CHAP_SECRETS_FILE).read_bytes(), original)

    def test_post_create_normalizes_realm_and_writes_static_identity(self):
        self.login_session()
        with patch.object(self.panel, "collect_status_snapshot", return_value={}), patch.object(self.panel, "save_status_snapshot"):
            response = self.client.post("/add", data={"csrf": "test-csrf-token", "username": "alice@VPN", "password": "Example-pass-42", "ip": "10.77.0.10"})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.panel.load_static_ips(), {"alice": "10.77.0.10"})
        self.assertEqual(Path(self.backend.CHAP_SECRETS_FILE).read_text(encoding="utf-8").split()[0], "alice@VPN")
        self.commands.assert_not_called()

    def test_ip_allocation_duplicates_reserved_and_pool(self):
        self.assertEqual(self.panel.next_available_static_ip({}), "10.77.0.10")
        mappings = {"alice": "10.77.0.10"}
        self.assertEqual(self.panel.next_available_static_ip(mappings), "10.77.0.11")
        with self.assertRaises(ValueError):
            self.panel.validate_static_ip("10.77.0.10", "bob", mappings)
        self.assertEqual(self.panel.validate_static_ip("10.77.0.10", "alice", mappings), "10.77.0.10")
        for ip in ("10.77.0.1", "10.77.0.250", "10.77.0.253", "10.77.0.254", "10.79.0.10"):
            with self.subTest(ip=ip), self.assertRaises(ValueError):
                self.panel.validate_static_ip(ip, "bob", {})

    def test_port_suggestion_skips_selected_service_ports(self):
        self.assertIn(9443, self.panel.RESERVED_PUBLIC_PORTS)
        self.assertIn(9444, self.panel.RESERVED_PUBLIC_PORTS)
        self.panel.DEFAULT_PUBLIC_PORT_START = 9443
        self.assertEqual(self.panel.next_available_public_port([]), 9445)
        self.assertEqual(self.panel.next_available_public_port([{"public_port": 9445}]), 9446)

    def test_global_traffic_reset_preserves_monthly_counters(self):
        data = self.panel._empty_traffic()
        data["users"] = {"alice": {"dl": 1000, "ul": 300, "legacy_total": 0}}
        self.panel.save_traffic(data)
        self.panel.reset_traffic_view_baseline()
        self.assertEqual(self.panel.load_traffic()["users"], data["users"])
        baseline = self.panel.load_traffic_view(data["month"])
        self.assertEqual(self.panel._traffic_since_view_baseline(data["users"]["alice"], baseline["users"]["alice"]), {"dl": 0, "ul": 0, "legacy_total": 0})

    def test_user_traffic_reset_does_not_reset_other_user(self):
        data = self.panel._empty_traffic()
        data["users"] = {"alice": {"dl": 100, "ul": 30, "legacy_total": 0}, "bob": {"dl": 250, "ul": 50, "legacy_total": 0}}
        self.panel.save_traffic(data)
        self.panel.reset_user_traffic_view_baseline("alice")
        baseline = self.panel.load_traffic_view(data["month"])
        self.assertIn("alice", baseline["users"])
        self.assertNotIn("bob", baseline["users"])
        self.assertEqual(self.panel.load_traffic()["users"], data["users"])

    def test_new_accounting_month_starts_empty(self):
        data = self.panel._empty_traffic("2000-01")
        data["users"] = {"alice": {"dl": 999, "ul": 42}}
        normalized = self.panel._normalise_traffic(data)
        self.assertEqual(normalized["users"], {})
        self.assertNotEqual(normalized["month"], "2000-01")

    def test_protected_api_requires_login(self):
        for url in ("/", "/api/status", "/api/cascade/status", "/api/forwards/status", "/backup", "/logs"):
            with self.subTest(url=url):
                response = self.client.get(url)
                self.assertEqual(response.status_code, 302)
                self.assertIn("/login", response.location)

    def test_chosen_unicode_admin_password_authenticates(self):
        value = 'Длинная тестовая фраза 42'
        (self.temp / '.admin_password').write_text(value + '\n', encoding='utf-8')
        with self.client.session_transaction() as session:
            session['captcha_answer'] = 42
        response = self.client.post('/login', data={'password': value, 'captcha': '42'})
        self.assertEqual(response.status_code, 302)
        with self.client.session_transaction() as session:
            self.assertTrue(session['logged_in'])

    def test_wrong_admin_password_is_rejected(self):
        (self.temp / '.admin_password').write_text('Synthetic-pass-42\n', encoding='utf-8')
        with self.client.session_transaction() as session:
            session['captcha_answer'] = 42
        response = self.client.post('/login', data={'password': 'Incorrect-pass-42', 'captcha': '42'})
        self.assertEqual(response.status_code, 200)
        with self.client.session_transaction() as session:
            self.assertFalse(session.get('logged_in'))

    def test_mutations_require_csrf_and_do_not_create_user(self):
        self.login_session()
        response = self.client.post("/add", data={"username": "alice", "password": "Example-pass-42", "ip": "10.77.0.10"})
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Path(self.backend.CHAP_SECRETS_FILE).exists())
        for url in ("/cascade/exit", "/cascade/mode", "/settings/network", "/routes/add", "/forwards/add"):
            with self.subTest(url=url):
                # Use a real body so the cascade upload-size guard does not
                # reject missing Content-Length before CSRF is exercised.
                response = self.client.post(url, data={"csrf": "incorrect-csrf"})
                self.assertIn(response.status_code, (302, 400, 403))
        self.commands.assert_not_called()

    def render_empty_dashboard(self):
        self.login_session()
        snapshot = {"users": [], "month": "2000-01", "total_dl": "0 B", "total_ul": "0 B", "total_all": "0 B", "collected_at": "", "traffic_note": ""}
        cascade = {"available": False, "status_available": True, "enabled": False, "direct_ip": "", "exit_ip": "", "port": 0, "healthy": False, "job": {"active": False, "stage": "idle", "message": ""}}
        with patch.object(self.panel, "load_status_snapshot", return_value=snapshot), patch.object(self.panel, "load_cascade_exit_status", return_value=cascade):
            response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        return response.get_data(as_text=True)

    def test_empty_dashboard_is_rendered_with_cascade_progress(self):
        html = self.render_empty_dashboard()
        self.assertIn("SSTP MANAGER", html)
        self.assertIn('id="cascade-exit-ip"', html)
        self.assertIn('id="cascade-progress-track"', html)
        self.assertIn('id="cascade-steps"', html)
        self.assertIn('data-current-ip=""', html)
        self.assertNotIn("__VPN_DOMAIN__", html)
        self.commands.assert_not_called()

    @unittest.skipUnless(NODE, "Node.js is needed to parse rendered inline JavaScript")
    def test_rendered_inline_javascript_parses(self):
        html = self.render_empty_dashboard()
        scripts = re.findall(r"<script\b[^>]*>(.*?)</script\s*>", html, re.I | re.S)
        self.assertTrue(scripts, "Dashboard must contain its inline interaction script")
        for index, source in enumerate(scripts):
            with self.subTest(script=index):
                result = REAL_SUBPROCESS_RUN([NODE, "--check", "-"], input=source, text=True,
                                             encoding="utf-8", capture_output=True, timeout=20)
                self.assertEqual(result.returncode, 0, result.stderr)
        self.commands.assert_not_called()


if __name__ == "__main__":
    unittest.main()
